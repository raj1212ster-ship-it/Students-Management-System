import { useState } from 'react'
import { BookOpen, Bell, Construction, Search, ChevronRight, Menu } from 'lucide-react'
import LoginPage from './components/LoginPage'
import Sidebar from './components/Sidebar'
import BranchDashboard from './components/BranchDashboard'
import RegistrationWizard from './components/RegistrationWizard'
import type { RecentRegistration } from './components/RegistrationWizard'
import ManagementDashboard from './components/ManagementDashboard'
import TraineeProfile from './components/TraineeProfile'
import Documentation from './components/Documentation'
import PricingPage from './components/PricingPage'
import MgmtSearchTrainee from './components/MgmtSearchTrainee'
import MgmtAnalytics from './components/MgmtAnalytics'
import RecentRegistrations from './components/RecentRegistrations'
import BatchManagement from './components/BatchManagement'
import DocumentsPage from './components/DocumentsPage'
import ReportsPage from './components/ReportsPage'
import AIChatBot from './components/AIChatBot'

type Role = 'branch' | 'management'
type Screen =
  | 'dashboard'
  | 'register'
  | 'search'
  | 'batch'
  | 'verification'
  | 'recent-registrations'
  | 'documents'
  | 'reports'
  | 'mgmt-dashboard'
  | 'trainee-flow'
  | 'analytics'
  | 'documentation'
  | 'trainee-profile'
  | 'pricing'

/** Animated carousel background — low-opacity gradient orbs */
/** Animated glow orbs — match reference image palette (blue / lavender / peach / orange) */
function CarouselBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
      {/* YSF Blue glow — top-left (matches reference left area) */}
      <div className="carousel-orb-1 absolute rounded-full" style={{
        width: 780, height: 780,
        top: -220, left: -180,
        background: 'radial-gradient(circle at 40% 40%, rgba(150,196,240,0.90) 0%, rgba(120,172,228,0.55) 40%, transparent 70%)',
        filter: 'blur(4px)',
      }} />
      {/* Lavender/periwinkle glow — center */}
      <div className="carousel-orb-2 absolute rounded-full" style={{
        width: 620, height: 620,
        top: '10%', left: '38%',
        background: 'radial-gradient(circle at 50% 50%, rgba(180,168,228,0.75) 0%, rgba(196,184,220,0.40) 48%, transparent 70%)',
        filter: 'blur(6px)',
      }} />
      {/* Peach/rose glow — bottom-right (matches reference right gradient) */}
      <div className="carousel-orb-3 absolute rounded-full" style={{
        width: 680, height: 680,
        bottom: -200, right: -140,
        background: 'radial-gradient(circle at 55% 55%, rgba(236,196,188,0.85) 0%, rgba(224,180,172,0.50) 45%, transparent 70%)',
        filter: 'blur(4px)',
      }} />
      {/* Orange accent glow — mid-left (YSF orange warmth) */}
      <div className="carousel-orb-4 absolute rounded-full" style={{
        width: 400, height: 400,
        bottom: '12%', left: '4%',
        background: 'radial-gradient(circle at 45% 45%, rgba(249,179,120,0.60) 0%, rgba(249,155,80,0.30) 50%, transparent 70%)',
        filter: 'blur(8px)',
      }} />
    </div>
  )
}

const SCREEN_TITLES: Record<string, string> = {
  dashboard: 'Branch Dashboard',
  register: 'Register Trainee',
  search: 'Search Trainee',
  batch: 'Batch Management',
  verification: 'Verification Queue',
  'recent-registrations': 'Verification Queue',
  documents: 'Documents',
  reports: 'Reports',
  'mgmt-dashboard': 'Executive Dashboard',
  'trainee-flow': 'Trainee Flow View',
  analytics: 'Analytics & Reports',
  documentation: 'User Manuals',
  'trainee-profile': 'Trainee Profile',
  pricing: 'Packages & Pricing',
}

function Topbar({ role, screen, onNavigate, onMenuOpen }: { role: Role; screen: Screen; onNavigate: (s: Screen) => void; onMenuOpen: () => void }) {
  const pageTitle = SCREEN_TITLES[screen] || 'Dashboard'
  return (
    <header
      className="h-14 flex items-center gap-3 px-4 md:px-6"
      style={{
        background: 'rgba(255,255,255,0.82)',
        backdropFilter: 'blur(20px) saturate(140%)',
        WebkitBackdropFilter: 'blur(20px) saturate(140%)',
        borderBottom: '1px solid rgba(255,255,255,0.72)',
        boxShadow: '0 1px 0 rgba(255,255,255,0.90), 0 4px 20px rgba(21,101,192,0.10)',
        position: 'sticky',
        top: 0,
        zIndex: 30,
      }}
    >
      {/* Hamburger — mobile only */}
      <button
        className="md:hidden flex items-center justify-center w-8 h-8 rounded-lg flex-shrink-0"
        style={{ background: 'var(--muted)', border: '1px solid var(--border)', color: 'var(--foreground)' }}
        onClick={onMenuOpen}
      >
        <Menu size={16} />
      </button>

      {/* Left — Breadcrumb + page title */}
      <div className="flex items-center gap-2 mr-auto">
        <span className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: 'Exo 2, sans-serif' }}>
          {role === 'branch' ? 'Branch' : 'Management'}
        </span>
        <ChevronRight size={12} style={{ color: 'var(--muted-foreground)' }} />
        <span className="text-sm font-semibold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
          {pageTitle}
        </span>
      </div>

      {/* Right — Search + actions + user */}
      <div className="flex items-center gap-2">
        {/* Search */}
        <div
          className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl"
          style={{ background: 'var(--muted)', border: '1px solid var(--border)', width: 240 }}
        >
          <Search size={13} style={{ color: 'var(--muted-foreground)', flexShrink: 0 }} />
          <input
            type="text"
            placeholder="Search trainees, schemes…"
            className="flex-1 bg-transparent outline-none text-xs"
            style={{ fontFamily: 'Exo 2, sans-serif', color: 'var(--foreground)' }}
          />
        </div>

        <button
          onClick={() => onNavigate('documentation')}
          className="hidden lg:flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-xl font-medium transition-all"
          style={{ background: 'var(--muted)', border: '1px solid var(--border)', color: 'var(--muted-foreground)' }}
        >
          <BookOpen size={13} /> Manual
        </button>

        <button
          className="relative w-8 h-8 rounded-xl flex items-center justify-center transition-all"
          style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}
        >
          <Bell size={15} style={{ color: 'var(--muted-foreground)' }} />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full" style={{ background: 'var(--ysf-red)' }} />
        </button>

        <div
          className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl cursor-pointer"
          style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}
        >
          <div
            className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
            style={{ background: role === 'branch' ? 'var(--ysf-orange)' : '#7c3aed' }}
          >
            {role === 'branch' ? 'PS' : 'RK'}
          </div>
          <div className="hidden sm:block">
            <div className="text-xs font-semibold leading-tight" style={{ color: 'var(--foreground)' }}>
              {role === 'branch' ? 'Priya Sharma' : 'Rajesh Kumar'}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}

function Placeholder({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-center h-80">
      <div className="text-center px-12 py-10 rounded-2xl card">
        <div className="mb-4 flex justify-center" style={{ color: 'var(--muted-foreground)' }}><Construction size={48} /></div>
        <div className="text-xl font-bold mb-2" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{title}</div>
        <div className="text-sm" style={{ color: 'var(--muted-foreground)' }}>This screen is part of the full SES implementation.</div>
      </div>
    </div>
  )
}

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [role, setRole] = useState<Role>('branch')
  const [screen, setScreen] = useState<Screen>('dashboard')
  const [traineeCode, setTraineeCode] = useState('TRN001234')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [sidebarMobileOpen, setSidebarMobileOpen] = useState(false)
  const [recentRegistrations, setRecentRegistrations] = useState<RecentRegistration[]>([])

  const handleRegistrationComplete = (reg: RecentRegistration) => {
    setRecentRegistrations(prev => [reg, ...prev])
  }
  const handleUpdateRegistration = (updated: RecentRegistration) => {
    setRecentRegistrations(prev => prev.map(r => r.id === updated.id ? updated : r))
  }

  const handleApproveRegistration = (id: string) => {
    setRecentRegistrations(prev => prev.map(r => {
      if (r.id !== id) return r
      const abbrev = (r.company || 'GEN').replace(/[^A-Za-z]/g, '').slice(0, 4).toUpperCase() || 'GEN'
      const scheme = (r.scheme || 'SKL').split(' ')[0].toUpperCase().slice(0, 6)
      const year   = new Date().getFullYear()
      const seq    = String(Math.floor(Math.random() * 90000) + 10000)
      const fixedCode = `${abbrev}/${scheme}/${year}/${seq}`
      return { ...r, status: 'approved', fixedCode, tempCode: '' }
    }))
  }
  const handleRejectRegistration = (id: string) => {
    setRecentRegistrations(prev => prev.map(r =>
      r.id === id ? { ...r, status: 'rejected' } : r
    ))
  }

  const handleLogin = (r: Role) => {
    setRole(r)
    setLoggedIn(true)
    setScreen(r === 'branch' ? 'dashboard' : 'mgmt-dashboard')
  }

  const handleLogout = () => {
    setLoggedIn(false)
    setScreen('dashboard')
  }

  const navigate = (s: string) => setScreen(s as Screen)

  const handleViewTrainee = (code: string) => {
    setTraineeCode(code)
    setScreen('trainee-profile')
  }

  if (!loggedIn) {
    return (
      <>
        {/* MARKER-MAKE-KIT-INVOKED */}
        {/* MARKER-MAKE-KIT-DISCOVERY-READ */}
        <CarouselBackground />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <LoginPage onLogin={handleLogin} />
        </div>
      </>
    )
  }

  return (
    <>
    <CarouselBackground />
    <AIChatBot />
    <div className="min-h-screen" style={{ background: 'transparent', position: 'relative', zIndex: 1 }}>
      {/* Mobile overlay backdrop */}
      {sidebarMobileOpen && (
        <div
          className="fixed inset-0 md:hidden"
          style={{ background: 'rgba(13,43,94,0.35)', backdropFilter: 'blur(4px)', zIndex: 19 }}
          onClick={() => setSidebarMobileOpen(false)}
        />
      )}

      <Sidebar
        active={screen}
        onNavigate={s => { navigate(s); setSidebarMobileOpen(false) }}
        role={role}
        onLogout={handleLogout}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(c => !c)}
        mobileOpen={sidebarMobileOpen}
        onMobileClose={() => setSidebarMobileOpen(false)}
      />

      <div
        className="flex flex-col content-shifted"
        style={{
          marginLeft: sidebarCollapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)',
          transition: 'margin-left 0.22s ease',
        }}
      >
        <Topbar role={role} screen={screen} onNavigate={navigate} onMenuOpen={() => setSidebarMobileOpen(true)} />

        <main className="flex-1 p-4 md:p-6 overflow-y-auto" style={{ minHeight: 'calc(100vh - 56px)', background: 'transparent' }}>
          {screen === 'dashboard' && role === 'branch' && (
            <BranchDashboard onNavigate={navigate} />
          )}
          {screen === 'register' && (
            <RegistrationWizard onNavigate={navigate} onComplete={handleRegistrationComplete} />
          )}
          {(screen === 'verification' || screen === 'recent-registrations') && role === 'branch' && (
            <RecentRegistrations
              registrations={recentRegistrations}
              onUpdateRegistration={handleUpdateRegistration}
              onApprove={handleApproveRegistration}
              onReject={handleRejectRegistration}
              onNavigate={navigate}
            />
          )}
          {screen === 'mgmt-dashboard' && role === 'management' && (
            <ManagementDashboard onViewTrainee={handleViewTrainee} />
          )}
          {screen === 'trainee-profile' && (
            <TraineeProfile code={traineeCode} onBack={() => navigate(role === 'management' ? 'mgmt-dashboard' : 'dashboard')} />
          )}
          {screen === 'documentation' && (
            <Documentation />
          )}
          {screen === 'pricing' && (
            <div className="-m-6">
              <PricingPage />
            </div>
          )}
          {screen === 'trainee-flow' && (
            <div className="max-w-2xl mx-auto">
              <h1 className="text-2xl font-bold text-slate-800 mb-6">Trainee Flow Chart</h1>
              <div className="glass-card p-6 space-y-2">
                {[
                  { step: 'START', color: '#1565C0', type: 'circle' },
                  { step: 'Trainee Registers at Center', color: '#2563eb', type: 'box' },
                  { step: 'Personal Info Captured', color: '#2563eb', type: 'box' },
                  { step: 'Documents Uploaded', color: '#2563eb', type: 'box' },
                  { step: 'Application Submitted', color: '#0ea5e9', type: 'box' },
                  { step: 'Document Verification', color: '#F97316', type: 'diamond' },
                  { step: 'Approved → Batch Allocation', color: '#16a34a', type: 'box' },
                  { step: 'Training Started', color: '#16a34a', type: 'box' },
                  { step: 'Attendance Tracked', color: '#16a34a', type: 'box' },
                  { step: 'Assessment Conducted', color: '#16a34a', type: 'box' },
                  { step: 'Certificate Issued', color: '#7c3aed', type: 'box' },
                  { step: 'Placement', color: '#7c3aed', type: 'box' },
                  { step: 'END', color: '#1565C0', type: 'circle' },
                ].map((s, i, arr) => (
                  <div key={s.step} className="flex flex-col items-center">
                    <div
                      className="px-5 py-3 text-white text-sm font-semibold text-center"
                      style={{
                        background: s.color,
                        borderRadius: s.type === 'circle' ? 999 : s.type === 'diamond' ? 0 : 10,
                        minWidth: 260,
                        clipPath: s.type === 'diamond' ? 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)' : undefined,
                        paddingTop: s.type === 'diamond' ? 24 : undefined,
                        paddingBottom: s.type === 'diamond' ? 24 : undefined,
                        boxShadow: `0 4px 16px ${s.color}44`,
                      }}
                    >
                      {s.step}
                    </div>
                    {i < arr.length - 1 && (
                      <div className="w-px h-5" style={{ background: 'rgba(21,101,192,0.25)' }} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          {screen === 'search' && role === 'management' && (
            <MgmtSearchTrainee onViewTrainee={handleViewTrainee} />
          )}
          {screen === 'analytics' && role === 'management' && (
            <MgmtAnalytics />
          )}
          {screen === 'batch' && role === 'branch' && (
            <BatchManagement onNavigate={navigate} />
          )}
          {screen === 'documents' && (
            <DocumentsPage />
          )}
          {screen === 'reports' && (
            <ReportsPage />
          )}
          {((screen === 'search' && role === 'branch')
            || (screen === 'analytics' && role === 'branch')
          ) && (
            <Placeholder title={screen.charAt(0).toUpperCase() + screen.slice(1).replace(/-/g, ' ')} />
          )}
        </main>
      </div>
    </div>
    </>
  )
}

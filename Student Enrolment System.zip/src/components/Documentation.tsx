import { useState } from 'react'
import { BookMarked, Zap, Target, CheckCircle, Smartphone, Users, Bell, AlertTriangle, Lock, BarChart3, ClipboardList, Search, Eye, FileText, Download } from 'lucide-react'

const SECTIONS = [
  { id: 'cover', label: 'Cover Page', page: 1 },
  { id: 'toc', label: 'Table of Contents', page: 2 },
  { id: 'overview', label: '1. Product Overview', page: 3 },
  { id: 'ux-goals', label: '2. UX Goals & Principles', page: 5 },
  { id: 'user-roles', label: '3. User Roles & Access', page: 7 },
  { id: 'ia', label: '4. Information Architecture', page: 9 },
  { id: 'nav-map', label: '5. Navigation Map', page: 11 },
  { id: 'user-journey', label: '6. User Journey', page: 13 },
  { id: 'reg-flow', label: '7. Registration Flow', page: 16 },
  { id: 'validation', label: '8. Validation Rules', page: 20 },
  { id: 'error', label: '9. Error Handling', page: 22 },
  { id: 'success', label: '10. Success States', page: 24 },
  { id: 'wireframes', label: '11. Wireframes — Dashboard', page: 25 },
  { id: 'profile360', label: '12. Trainee 360° Profile', page: 28 },
  { id: 'docmgmt', label: '13. Document Management', page: 30 },
  { id: 'verification', label: '14. Verification Workflow', page: 32 },
  { id: 'batch', label: '15. Batch Allocation', page: 34 },
  { id: 'reports', label: '16. Reports', page: 36 },
  { id: 'analytics', label: '17. Analytics', page: 38 },
  { id: 'mobile', label: '18. Mobile UX', page: 40 },
  { id: 'design-system', label: '19. Design System', page: 42 },
  { id: 'accessibility', label: '20. Accessibility', page: 44 },
  { id: 'credentials', label: '21. User Credentials', page: 45 },
  { id: 'admin-login', label: '22. Admin Login Manual', page: 47 },
  { id: 'future', label: '23. Future Enhancements', page: 49 },
  { id: 'glossary', label: '24. Glossary', page: 51 },
]

function DocPage({ title, subtitle, pageNum, children }: { title?: string; subtitle?: string; pageNum: number; children: React.ReactNode }) {
  return (
    <div className="mb-12 last:mb-0">
      <div className="rounded-2xl overflow-hidden" style={{ background: '#fff', border: '1px solid #e2e8f0', minHeight: 600 }}>
        {title && (
          <div className="px-10 py-6 border-b" style={{ borderColor: '#f1f5f9', background: '#f8fafc' }}>
            <div className="text-xs text-slate-400 mb-1">Page {pageNum}</div>
            <h2 className="text-2xl font-bold text-slate-800" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{title}</h2>
            {subtitle && <p className="text-slate-500 text-sm mt-1">{subtitle}</p>}
          </div>
        )}
        <div className="px-10 py-8">{children}</div>
      </div>
    </div>
  )
}

function H3({ children }: { children: React.ReactNode }) {
  return <h3 className="font-bold text-slate-800 text-base mb-3 mt-6" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{children}</h3>
}

function P({ children }: { children: React.ReactNode }) {
  return <p className="text-slate-600 text-sm leading-relaxed mb-3">{children}</p>
}

function UL({ items }: { items: string[] }) {
  return (
    <ul className="space-y-1.5 mb-4">
      {items.map((i, idx) => (
        <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
          <span className="mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: '#2563eb' }} />
          {i}
        </li>
      ))}
    </ul>
  )
}

function InfoBox({ color, children }: { color: string; children: React.ReactNode }) {
  const styles: Record<string, { bg: string; border: string; text: string }> = {
    blue: { bg: '#eff6ff', border: '#bfdbfe', text: '#1e40af' },
    amber: { bg: '#fffbeb', border: '#fde68a', text: '#92400e' },
    green: { bg: '#f0fdf4', border: '#bbf7d0', text: '#065f46' },
    purple: { bg: '#f5f3ff', border: '#ddd6fe', text: '#4c1d95' },
  }
  const s = styles[color] || styles.blue
  return (
    <div className="rounded-xl p-4 mb-4 text-sm" style={{ background: s.bg, border: `1px solid ${s.border}`, color: s.text }}>
      {children}
    </div>
  )
}

function Table({ headers, rows }: { headers: string[]; rows: string[][] }) {
  return (
    <div className="rounded-xl overflow-hidden mb-5" style={{ border: '1px solid #e2e8f0' }}>
      <table className="w-full text-sm">
        <thead>
          <tr style={{ background: '#f8fafc' }}>
            {headers.map(h => (
              <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wide">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} className="border-t" style={{ borderColor: '#f1f5f9' }}>
              {row.map((cell, j) => (
                <td key={j} className="px-4 py-3 text-slate-600 text-xs">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function Documentation() {
  const [activeSection, setActiveSection] = useState('cover')

  return (
    <div className="flex gap-5 items-start">
      {/* Sidebar TOC */}
      <div className="w-64 flex-shrink-0 sticky top-6">
        <div className="rounded-xl overflow-hidden" style={{ background: '#fff', border: '1px solid #e2e8f0' }}>
          <div className="px-4 py-3 border-b" style={{ borderColor: '#f1f5f9', background: '#0f2744' }}>
            <div className="text-white font-bold text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}><BookMarked size={14} style={{display:'inline',marginRight:6}} /> Table of Contents</div>
            <div className="text-blue-300 text-xs mt-0.5">51 Pages · 24 Sections</div>
          </div>
          <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 160px)' }}>
            {SECTIONS.map(s => (
              <button
                key={s.id}
                onClick={() => {
                  setActiveSection(s.id)
                  document.getElementById(s.id)?.scrollIntoView({ behavior: 'smooth', block: 'start' })
                }}
                className="w-full px-4 py-2.5 text-left border-b flex items-start gap-2 transition-all hover:bg-blue-50"
                style={{ borderColor: '#f8fafc', background: activeSection === s.id ? '#eff6ff' : 'transparent' }}
              >
                <span className="text-xs text-slate-400 mt-0.5 font-mono w-6 flex-shrink-0">{s.page}</span>
                <span className="text-xs text-slate-600 leading-tight" style={{ fontFamily: 'Rajdhani, sans-serif', color: activeSection === s.id ? '#1e3a5f' : undefined, fontWeight: activeSection === s.id ? 600 : 400 }}>{s.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 min-w-0">

        {/* COVER */}
        <div id="cover">
          <DocPage pageNum={1}>
            <div className="text-center py-12" style={{ background: 'linear-gradient(135deg, #0f2744 0%, #1e3a5f 100%)', borderRadius: 16, margin: -32 }}>
              <div className="py-16 px-10">
                <div className="text-blue-300 text-xs tracking-widest uppercase mb-6">Government of India · National Skill Development Corporation</div>
                <div className="w-20 h-20 rounded-2xl mx-auto flex items-center justify-center text-3xl font-bold mb-8" style={{ background: '#f59e0b', color: '#0f2744' }}>SES</div>
                <h1 className="text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Student Enrollment System</h1>
                <h2 className="text-xl text-blue-300 mb-8" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Web Portal — User Manual & UX Documentation</h2>
                <div className="grid grid-cols-2 gap-4 max-w-md mx-auto mb-10">
                  <div className="rounded-xl p-4 text-left" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="text-blue-300 text-xs mb-1">Document</div>
                    <div className="text-white text-sm font-semibold">SES Web User Manual</div>
                  </div>
                  <div className="rounded-xl p-4 text-left" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="text-blue-300 text-xs mb-1">Version</div>
                    <div className="text-white text-sm font-semibold">v3.2.1 · Aug 2024</div>
                  </div>
                  <div className="rounded-xl p-4 text-left" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="text-blue-300 text-xs mb-1">Prepared By</div>
                    <div className="text-white text-sm font-semibold">NSDC UX Team</div>
                  </div>
                  <div className="rounded-xl p-4 text-left" style={{ background: 'rgba(255,255,255,0.08)' }}>
                    <div className="text-blue-300 text-xs mb-1">Classification</div>
                    <div className="text-white text-sm font-semibold">Internal · Restricted</div>
                  </div>
                </div>
                <div className="text-blue-400 text-sm">Covers: Branch User Manual · Admin Login Manual · Senior Management Guide</div>
              </div>
            </div>
          </DocPage>
        </div>

        {/* TOC */}
        <div id="toc">
          <DocPage title="Table of Contents" pageNum={2}>
            <div className="grid grid-cols-2 gap-x-8 gap-y-1">
              {SECTIONS.map(s => (
                <div key={s.id} className="flex items-center justify-between py-1.5 border-b" style={{ borderColor: '#f8fafc' }}>
                  <span className="text-sm text-slate-600">{s.label}</span>
                  <span className="text-xs text-slate-400 font-mono ml-4">{s.page}</span>
                </div>
              ))}
            </div>
          </DocPage>
        </div>

        {/* SECTION 1: OVERVIEW */}
        <div id="overview">
          <DocPage title="1. Product Overview" subtitle="Introduction to the Student Enrollment System" pageNum={3}>
            <P>The <strong>Student Enrollment System (SES)</strong> is a comprehensive web-based digital platform developed for the National Skill Development Corporation (NSDC) to streamline the enrollment, training, verification, and placement tracking of trainees across all affiliated training centers in India.</P>
            <P>SES replaces paper-based enrollment processes with an efficient, Aadhaar-integrated digital workflow that ensures data accuracy, transparency, and real-time visibility to all stakeholders including branch users, verifiers, trainers, and senior management.</P>

            <H3>1.1 Scope of the System</H3>
            <UL items={[
              'Trainee Registration via a 5-step enrollment wizard',
              'Document upload and management with OCR-ready metadata',
              'Multi-level verification workflow (Document → Approval → Allocation)',
              'Batch management and trainee-to-batch assignment',
              'Attendance and performance tracking',
              'Certificate and offer letter management',
              'Placement tracking and employer mapping',
              'Executive dashboards and analytics for senior management',
              'Role-based access control for 3 user categories',
            ]} />

            <H3>1.2 Key Stakeholders</H3>
            <Table
              headers={['Stakeholder', 'Role', 'Primary Task']}
              rows={[
                ['Branch User', 'Training Center Staff', 'Register trainees, upload documents, manage records'],
                ['Verifier', 'Document Verification Officer', 'Review and approve submitted documents'],
                ['Senior Management', 'GM / COO / Director', 'Monitor KPIs, view analytics, access trainee profiles'],
                ['Trainer', 'Course Trainer', 'Mark attendance, submit assessments'],
                ['System Admin', 'IT Administrator', 'User management, system configuration'],
              ]}
            />

            <H3>1.3 Technology Overview</H3>
            <InfoBox color="blue">
              <strong>Platform:</strong> Web Application (React + Node.js) · Responsive — Desktop & Mobile<br />
              <strong>Integration:</strong> Aadhaar API, PAN Verification, NSQF Registry, Bank Account Validation<br />
              <strong>Supported Browsers:</strong> Chrome 90+, Firefox 85+, Edge 90+, Safari 14+<br />
              <strong>Authentication:</strong> Username + Password + Session Token · Role-Based Access Control
            </InfoBox>
          </DocPage>
        </div>

        {/* SECTION 2: UX GOALS */}
        <div id="ux-goals">
          <DocPage title="2. UX Goals & Design Principles" subtitle="The philosophy behind the SES design" pageNum={5}>
            <H3>2.1 Primary UX Objectives</H3>
            <P>The SES portal is designed with a "10th-grade student can use it" principle — meaning every interaction should be intuitive enough that a first-time user with basic digital literacy can complete any task without training or assistance.</P>

            <div className="grid grid-cols-2 gap-4 mb-6">
              {[
                { Icon: Zap, title: 'Speed', desc: 'Any task completable in under 5 clicks. Auto-save prevents data loss.' },
                { Icon: Target, title: 'Clarity', desc: 'One primary action per screen. No ambiguity about what to do next.' },
                { Icon: CheckCircle, title: 'Validation', desc: 'Real-time field validation prevents errors before they propagate.' },
                { Icon: Smartphone, title: 'Responsive', desc: 'Full functionality on mobile, tablet, and desktop devices.' },
                { Icon: Users, title: 'Accessible', desc: 'WCAG 2.1 AA compliant. Screen reader and keyboard navigation support.' },
                { Icon: Bell, title: 'Feedback', desc: 'Every action confirms success or explains errors clearly.' },
              ].map(g => (
                <div key={g.title} className="rounded-xl p-4 flex gap-3" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                  <span className="text-2xl"><g.Icon size={20} /></span>
                  <div>
                    <div className="font-semibold text-slate-800 text-sm mb-1" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{g.title}</div>
                    <div className="text-xs text-slate-500">{g.desc}</div>
                  </div>
                </div>
              ))}
            </div>

            <H3>2.2 Design Principles</H3>
            <UL items={[
              'Progressive Disclosure: Show only what the user needs at each step; reveal complexity gradually',
              'Error Prevention First: Smart validation prevents invalid inputs before submission',
              'Consistent Patterns: All forms follow the same layout, validation, and button placement patterns',
              'Status Transparency: Every record shows its current status clearly with color-coded badges',
              'Recoverability: Users can go back and edit any step before final submission',
              'Bilingual Support: All UI elements support English and regional language toggle',
            ]} />
          </DocPage>
        </div>

        {/* SECTION 3: USER ROLES */}
        <div id="user-roles">
          <DocPage title="3. User Roles & Access Control" subtitle="Defined roles, permissions, and credential structure" pageNum={7}>
            <H3>3.1 Role Hierarchy</H3>
            <P>SES implements a three-tier role hierarchy ensuring appropriate data access and operational boundaries:</P>

            <div className="space-y-3 mb-6">
              {[
                { role: 'Senior Management', level: 'Tier 1 — Read-Only Analytics', color: '#7c3aed', perms: ['View all trainee profiles', 'Access analytics dashboards', 'Download reports', 'View documents and agreements', 'Cannot edit or register'] },
                { role: 'Branch User', level: 'Tier 2 — Operational', color: '#2563eb', perms: ['Register new trainees', 'Upload documents', 'Assign trainees to batches', 'View own center records only', 'Cannot access other centers'] },
                { role: 'Verifier', level: 'Tier 2 — Verification', color: '#0891b2', perms: ['Review submitted applications', 'Approve or reject documents', 'Request additional documents', 'Cannot modify personal data'] },
              ].map(r => (
                <div key={r.role} className="rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0' }}>
                  <div className="px-4 py-3 flex items-center justify-between" style={{ background: `${r.color}15` }}>
                    <div>
                      <div className="font-bold text-sm" style={{ color: r.color, fontFamily: 'Rajdhani, sans-serif' }}>{r.role}</div>
                      <div className="text-xs text-slate-500">{r.level}</div>
                    </div>
                    <div className="w-2 h-2 rounded-full" style={{ background: r.color }} />
                  </div>
                  <div className="px-4 py-3">
                    <div className="flex flex-wrap gap-2">
                      {r.perms.map(p => (
                        <span key={p} className="text-xs px-2.5 py-1 rounded-full" style={{ background: '#f1f5f9', color: '#475569' }}>{p}</span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <H3>3.2 Login Credentials Reference</H3>
            <InfoBox color="amber">
              <strong><AlertTriangle size={14} style={{display:'inline',marginRight:4}} /> Security Notice:</strong> The credentials listed below are for prototype/demo purposes only. In production, all passwords must be changed on first login, comply with the organization's password policy (minimum 8 characters, mixed case, at least one number and special character), and must not be shared.
            </InfoBox>
            <Table
              headers={['User Type', 'Username', 'Password', 'Access Level', 'Center / Region']}
              rows={[
                ['Branch User', 'branch_hyd01', 'Hyd@2024', 'Branch — Operational', 'Hyderabad Training Center'],
                ['Branch User', 'branch_mum02', 'Mum@2024', 'Branch — Operational', 'Mumbai Training Center'],
                ['Branch User', 'branch_del03', 'Del@2024', 'Branch — Operational', 'Delhi Training Center'],
                ['Senior Manager', 'mgmt_admin', 'Mgmt@2024', 'Management — Read-Only', 'All Regions'],
                ['GM South Region', 'gm_south', 'GM@South24', 'Management — Read-Only', 'South Zone'],
                ['COO', 'ceo_ops', 'CEO@Ops24', 'Management — Full View', 'Pan-India'],
              ]}
            />
          </DocPage>
        </div>

        {/* SECTION 4: IA */}
        <div id="ia">
          <DocPage title="4. Information Architecture" subtitle="Site structure and content organization" pageNum={9}>
            <H3>4.1 Navigation Structure — Branch User Portal</H3>
            <div className="rounded-xl p-5 mb-5" style={{ background: '#f8fafc', border: '1px solid #e2e8f0', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
              <div className="text-slate-800 space-y-1">
                <div><Lock size={14} style={{display:'inline',marginRight:4}} /> Login</div>
                <div className="ml-4">└── Branch Dashboard</div>
                <div className="ml-8">├── Register Trainee [Wizard]</div>
                <div className="ml-12">├── Step 1: Personal Information</div>
                <div className="ml-12">├── Step 2: Education</div>
                <div className="ml-12">├── Step 3: Documents</div>
                <div className="ml-12">├── Step 4: Review</div>
                <div className="ml-12">└── Step 5: Submit → Success</div>
                <div className="ml-8">├── Search Trainee</div>
                <div className="ml-12">└── Trainee Detail View</div>
                <div className="ml-8">├── Batch Management</div>
                <div className="ml-12">├── Create Batch</div>
                <div className="ml-12">└── Assign Trainees</div>
                <div className="ml-8">├── Verification Queue</div>
                <div className="ml-8">├── Documents</div>
                <div className="ml-8">└── Reports</div>
              </div>
            </div>

            <H3>4.2 Navigation Structure — Management Portal</H3>
            <div className="rounded-xl p-5" style={{ background: '#f8fafc', border: '1px solid #e2e8f0', fontFamily: 'JetBrains Mono, monospace', fontSize: 12 }}>
              <div className="text-slate-800 space-y-1">
                <div><Lock size={14} style={{display:'inline',marginRight:4}} /> Management Login</div>
                <div className="ml-4">└── Executive Dashboard</div>
                <div className="ml-8">├── KPI Overview</div>
                <div className="ml-8">├── Trainee Registry → 360° Profile</div>
                <div className="ml-8">├── Analytics & Charts</div>
                <div className="ml-8">├── Branch-wise Reports</div>
                <div className="ml-8">└── User Manuals</div>
              </div>
            </div>
          </DocPage>
        </div>

        {/* SECTION 5-6: NAV MAP + USER JOURNEY */}
        <div id="nav-map">
          <DocPage title="5. Navigation Map" subtitle="Screen-to-screen flow reference" pageNum={11}>
            <H3>5.1 Key Flows</H3>
            <div className="grid grid-cols-3 gap-4">
              {[
                { title: 'Registration Flow', steps: ['Login', 'Dashboard', 'Register Trainee', 'Step 1: Personal', 'Step 2: Education', 'Step 3: Documents', 'Step 4: Review', 'Submit', 'Success Screen', 'Batch Allocation'] },
                { title: 'Verification Flow', steps: ['Login', 'Dashboard', 'Verification Queue', 'Application Review', 'Document Check', 'Approve / Reject', 'Notification Sent'] },
                { title: 'Management Flow', steps: ['Login (Mgmt)', 'Executive Dashboard', 'KPI Overview', 'Trainee Registry', 'Search / Filter', '360° Profile View', 'Agreement / Docs', 'Download Report'] },
              ].map(f => (
                <div key={f.title} className="rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0' }}>
                  <div className="px-4 py-3 font-semibold text-sm" style={{ background: '#1e3a5f', color: '#fff', fontFamily: 'Rajdhani, sans-serif' }}>{f.title}</div>
                  <div className="p-4">
                    {f.steps.map((s, i) => (
                      <div key={s} className="flex items-center gap-2 mb-2">
                        <div className="w-5 h-5 rounded-full text-xs flex items-center justify-center font-bold flex-shrink-0" style={{ background: '#eff6ff', color: '#2563eb' }}>{i + 1}</div>
                        <span className="text-xs text-slate-600">{s}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </DocPage>
        </div>

        <div id="user-journey">
          <DocPage title="6. User Journey Maps" subtitle="Step-by-step emotional and task journeys" pageNum={13}>
            <H3>6.1 Branch User Journey — Registering a New Trainee</H3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs min-w-[600px]">
                <thead>
                  <tr style={{ background: '#0f2744', color: '#fff' }}>
                    {['Stage', 'User Action', 'System Response', 'Emotion', 'Pain Point'].map(h => (
                      <th key={h} className="px-3 py-3 text-left font-semibold">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {[
                    ['Login', 'Enters username + password', 'Authenticates, shows dashboard', 'Confident', 'Forgot password?'],
                    ['Dashboard', 'Clicks "Register Trainee"', 'Opens wizard at Step 1', 'Ready', 'Too many menu options?'],
                    ['Step 1', 'Fills personal details', 'Real-time validation, auto-save', 'Focused', 'Aadhaar format confusion'],
                    ['Step 2', 'Enters education details', 'Cards expand, upload triggered', 'Easy', 'Which board to select?'],
                    ['Step 3', 'Uploads documents', 'Preview + OCR metadata extracted', 'Careful', 'File size limit exceeded'],
                    ['Step 4', 'Reviews all data', 'Summary shown, edit option visible', 'Verifying', 'Found an error?'],
                    ['Step 5', 'Clicks Submit', 'Success screen + Trainee Code generated', 'Relieved', 'None — smooth!'],
                  ].map((row, i) => (
                    <tr key={i} className="border-t" style={{ borderColor: '#f1f5f9', background: i % 2 === 0 ? '#f8fafc' : '#fff' }}>
                      {row.map((cell, j) => (
                        <td key={j} className="px-3 py-2.5 text-slate-600">{cell}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <H3>6.2 Senior Management Journey — Accessing Trainee Profile</H3>
            <div className="flex gap-2 overflow-x-auto pb-2">
              {[
                { step: 1, action: 'Login with Management credentials', Icon: Lock },
                { step: 2, action: 'View Executive Dashboard KPIs', Icon: BarChart3 },
                { step: 3, action: 'Browse Trainee Registry table', Icon: ClipboardList },
                { step: 4, action: 'Search by name or trainee code', Icon: Search },
                { step: 5, action: "Click 'View 360°' on any trainee", Icon: Eye },
                { step: 6, action: 'Access full profile, docs, agreement', Icon: FileText },
                { step: 7, action: 'Download or Print profile', Icon: Download },
              ].map(s => (
                <div key={s.step} className="flex-shrink-0 rounded-xl p-4 text-center w-36" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                  <div className="flex justify-center mb-2" style={{ color: '#64748b' }}><s.Icon size={20} /></div>
                  <div className="text-xs font-bold text-slate-700 mb-1" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Step {s.step}</div>
                  <div className="text-xs text-slate-500">{s.action}</div>
                </div>
              ))}
            </div>
          </DocPage>
        </div>

        {/* SECTION 7: REGISTRATION FLOW */}
        <div id="reg-flow">
          <DocPage title="7. Registration Flow — Detailed Specification" subtitle="Complete field-by-field documentation of the 5-step wizard" pageNum={16}>
            <H3>7.1 Step 1 — Personal Information</H3>
            <Table
              headers={['Field', 'Type', 'Required', 'Validation', 'Notes']}
              rows={[
                ['Full Name', 'Text', 'Yes', 'Min 3 chars, no numbers', 'Must match Aadhaar exactly'],
                ['Date of Birth', 'Date', 'Yes', 'Age 18–35 for PMKVY', 'Age eligibility is scheme-dependent'],
                ['Aadhaar Number', 'Numeric', 'Yes', '12 digits, Luhn check', 'OTP verification in production'],
                ['Mobile Number', 'Numeric', 'Yes', '10 digits, duplicate check', 'OTP sent for verification'],
                ['Email Address', 'Email', 'No', 'RFC 5322 format', 'Welcome email is sent'],
                ['Gender', 'Dropdown', 'Yes', 'Male / Female / Transgender', '—'],
                ["Father's Name", 'Text', 'Yes', 'Min 2 chars', '—'],
                ["Mother's Name", 'Text', 'Yes', 'Min 2 chars', '—'],
                ['State', 'Dropdown', 'Yes', 'From NSDC state list', 'Drives district dropdown'],
                ['District', 'Dropdown', 'Yes', 'From state mapping', '—'],
                ['City / Town', 'Text', 'Yes', 'Min 2 chars', '—'],
                ['PIN Code', 'Numeric', 'Yes', '6 digits, India Post API', 'Auto-fills city and state'],
                ['Bank Account No.', 'Numeric', 'Yes', '9–18 digits', 'Penny-drop verification in production'],
                ['IFSC Code', 'Alphanumeric', 'Yes', 'RBI IFSC format', 'Auto-fills bank name'],
                ['Scheme', 'Dropdown', 'Yes', 'Active schemes only', 'Drives NSQF and job role filters'],
                ['NSQF Level', 'Dropdown', 'Yes', 'Level 2 to 7', '—'],
                ['Job Role', 'Dropdown', 'Yes', 'From NSQF registry', 'Linked to sector skill council'],
              ]}
            />

            <H3>7.2 Step 2 — Education</H3>
            <P>The education step uses card-based navigation. Each qualification (10th, 12th, ITI, Diploma, Graduation) is a tab card. Trainees fill only the qualifications they possess. At minimum, 10th Standard details are mandatory for all schemes.</P>
            <Table
              headers={['Card', 'Fields', 'Marksheet Required', 'Notes']}
              rows={[
                ['10th Standard', 'Board, Year, Percentage', 'Yes (Mandatory)', 'Minimum for all schemes'],
                ['12th Standard', 'Board, Year, Percentage', 'Yes if filled', 'Required for PMKVY Level 4+'],
                ['ITI', 'Trade, Year, Marks', 'Yes if filled', 'Links to DGT trade codes'],
                ['Diploma', 'Stream, College, Year', 'Yes if filled', '—'],
                ['Graduation', 'Subject, University, Year, %', 'Yes if filled', '—'],
              ]}
            />

            <H3>7.3 Step 3 — Document Checklist</H3>
            <Table
              headers={['Document', 'Format', 'Max Size', 'Required', 'Purpose']}
              rows={[
                ['Aadhaar Card', 'JPG/PDF', '2 MB', 'Yes', 'Identity verification'],
                ['PAN Card', 'JPG/PDF', '2 MB', 'If applicable', 'Financial verification'],
                ['Passport Photo', 'JPG', '500 KB', 'Yes', 'Biometric identity'],
                ['Signature', 'JPG/PNG', '200 KB', 'Yes', 'For agreement'],
                ['10th Marksheet', 'PDF/JPG', '2 MB', 'Yes', 'Education proof'],
                ['12th Marksheet', 'PDF/JPG', '2 MB', 'If applicable', 'Education proof'],
                ['Bank Passbook', 'PDF/JPG', '2 MB', 'Yes', 'Payment proof'],
                ['Agreement Form', 'PDF', '5 MB', 'Yes', 'Signed MoU'],
                ['Offer Letter', 'PDF', '5 MB', 'If available', 'Pre-placement offer'],
              ]}
            />
          </DocPage>
        </div>

        {/* SECTIONS 8-10 */}
        <div id="validation">
          <DocPage title="8. Validation Rules" subtitle="Field-level and form-level validation specifications" pageNum={20}>
            <H3>8.1 Real-Time Validation</H3>
            <P>All fields validate on blur (when user leaves the field). Errors appear as red text below the field with a specific actionable message. Fields with errors are highlighted with a red border.</P>
            <Table
              headers={['Validation Type', 'Trigger', 'Error Message', 'Action Required']}
              rows={[
                ['Aadhaar Format', 'On blur', '"Aadhaar must be 12 digits"', 'Re-enter valid 12-digit number'],
                ['Duplicate Mobile', 'On blur (API)', '"This mobile is already registered"', 'Use different number or contact admin'],
                ['Age Eligibility', 'On DOB blur', '"Trainee must be 18–35 for PMKVY"', 'Check scheme requirements'],
                ['Mandatory Field', 'On submit', '"This field is required"', 'Fill the highlighted field'],
                ['PIN Code', 'On blur (API)', '"Invalid PIN code"', 'Enter correct 6-digit PIN'],
                ['IFSC Code', 'On blur', '"Invalid IFSC format"', 'Format: AAAA0XXXXXX'],
                ['Email Format', 'On blur', '"Invalid email address"', 'Check email format'],
                ['File Size', 'On upload', '"File exceeds 2MB limit"', 'Compress or resize the file'],
                ['File Type', 'On upload', '"Only JPG/PNG/PDF allowed"', 'Convert to supported format'],
              ]}
            />
            <InfoBox color="green">
              <strong>Auto-Save:</strong> The wizard auto-saves progress after each step so users can resume if the browser is closed or session times out (within 30 minutes).
            </InfoBox>
          </DocPage>
        </div>

        <div id="error">
          <DocPage title="9. Error Handling" subtitle="System error states and recovery paths" pageNum={22}>
            <H3>9.1 Error Categories</H3>
            <div className="space-y-3">
              {[
                { type: 'Field Validation Error', color: '#dc2626', bg: '#fef2f2', desc: 'Shown inline below the field. User must correct before proceeding.', example: '"Aadhaar must be 12 digits"' },
                { type: 'Server Error (500)', color: '#7c3aed', bg: '#f5f3ff', desc: 'Full-screen error with retry button. Data is preserved.', example: '"Server error. Please try again in a moment."' },
                { type: 'Session Timeout', color: '#d97706', bg: '#fffbeb', desc: 'Warning shown 2 minutes before timeout. Data auto-saved.', example: '"Your session will expire in 2 minutes. Click to continue."' },
                { type: 'Duplicate Record', color: '#0891b2', bg: '#ecfeff', desc: 'Dialog showing the existing record with option to view it.', example: '"A trainee with this Aadhaar already exists: TRN000892"' },
                { type: 'Network Error', color: '#475569', bg: '#f8fafc', desc: 'Toast notification with offline indicator. Auto-retries.', example: '"Connection lost. Reconnecting..."' },
              ].map(e => (
                <div key={e.type} className="rounded-xl p-4" style={{ background: e.bg, border: `1px solid ${e.color}33` }}>
                  <div className="font-semibold text-sm mb-1" style={{ color: e.color, fontFamily: 'Rajdhani, sans-serif' }}>{e.type}</div>
                  <div className="text-xs text-slate-600 mb-1">{e.desc}</div>
                  <div className="text-xs font-mono" style={{ color: e.color }}>Example: {e.example}</div>
                </div>
              ))}
            </div>
          </DocPage>
        </div>

        <div id="success">
          <DocPage title="10. Success States" subtitle="Confirmation and next-step guidance patterns" pageNum={24}>
            <H3>10.1 Registration Success</H3>
            <P>Upon successful form submission, the system displays a full-screen success state with:</P>
            <UL items={[
              'Green checkmark animation',
              'Generated Trainee Code (e.g., TRN001235) in large monospace font',
              'Generation timestamp',
              'SMS confirmation to registered mobile number',
              'Two CTAs: "Register Another" and "Proceed to Batch Allocation"',
              'Print receipt option',
            ]} />

            <H3>10.2 Other Success Notifications</H3>
            <Table
              headers={['Action', 'Success Message', 'Follow-up Action']}
              rows={[
                ['Document Upload', '"Document uploaded successfully"', 'Check shows on upload card'],
                ['Batch Assignment', '"Trainee assigned to Batch HYD-B12"', 'Batch confirmation shown'],
                ['Verification Approval', '"Application approved and trainee notified"', 'Status updates to Verified'],
                ['Profile Update', '"Profile updated successfully"', 'Updated timestamp shown'],
              ]}
            />
          </DocPage>
        </div>

        {/* SECTIONS 11-12: WIREFRAMES + PROFILE */}
        <div id="wireframes">
          <DocPage title="11. Dashboard Wireframe Specification" subtitle="Branch User Dashboard — screen components" pageNum={25}>
            <H3>11.1 Dashboard Layout</H3>
            <div className="rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0' }}>
              <div className="p-4" style={{ background: '#f8fafc' }}>
                <div className="grid grid-cols-6 gap-2 mb-3">
                  {['Total Trainees', "Today's Reg.", 'Pending Verify', 'Batch Pending', 'Completed', 'Rejected'].map(k => (
                    <div key={k} className="rounded-lg p-3 text-center" style={{ background: '#fff', border: '1px solid #e2e8f0' }}>
                      <div className="text-xs text-slate-400 mb-1">{k}</div>
                      <div className="text-lg font-bold text-slate-700">—</div>
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {['Register Trainee', 'Search Trainee', 'Verify Docs', 'Assign Batch'].map(a => (
                    <div key={a} className="rounded-lg p-3 text-center" style={{ background: '#fff', border: '1.5px dashed #cbd5e1' }}>
                      <div className="text-xs text-slate-500">{a}</div>
                    </div>
                  ))}
                </div>
                <div className="rounded-lg" style={{ background: '#fff', border: '1px solid #e2e8f0', padding: 12 }}>
                  <div className="text-xs font-semibold text-slate-500 mb-2">Recent Registrations (Table)</div>
                  {[1,2,3].map(i => (
                    <div key={i} className="h-6 rounded mb-1" style={{ background: '#f1f5f9', width: `${85 + Math.random() * 15}%` }} />
                  ))}
                </div>
              </div>
            </div>

            <H3>11.2 Component Inventory</H3>
            <Table
              headers={['Component', 'Type', 'Data Source', 'Refresh']}
              rows={[
                ['KPI Cards (6)', 'Stat tile', 'Branch-scoped API', 'On page load'],
                ['Quick Actions (4)', 'Icon button grid', 'Static navigation', '—'],
                ['Recent Registrations', 'Data table', 'Last 10 records', 'On load + manual'],
                ['Notice Board', 'Alert banner', 'Admin broadcast API', 'Daily'],
              ]}
            />
          </DocPage>
        </div>

        <div id="profile360">
          <DocPage title="12. Trainee 360° Profile" subtitle="Complete profile view accessible to management" pageNum={28}>
            <H3>12.1 Profile Header</H3>
            <P>The profile header is always visible and contains: Photo/Avatar, Trainee Code (JetBrains Mono font), Full Name, Job Role, Scheme, Center Name, and 4 quick-reference data pills (DOB, Mobile, State, Attendance).</P>

            <H3>12.2 Tab Structure</H3>
            <Table
              headers={['Tab', 'Content', 'Access Level']}
              rows={[
                ['Personal', 'Basic details, family, address', 'Branch + Management'],
                ['Education', 'All qualification records', 'Branch + Management'],
                ['Course & Batch', 'Scheme, job role, batch ID, trainer', 'Branch + Management'],
                ['Attendance', 'Attendance %, daily log', 'Branch + Management'],
                ['Documents', 'All uploaded documents with status', 'Branch + Management'],
                ['Agreement', 'PDF viewer, download, version history', 'Management Only'],
                ['Timeline', 'Chronological audit trail', 'Management Only'],
                ['Placement', 'Employer, salary, joining date', 'Management Only'],
              ]}
            />

            <InfoBox color="purple">
              <strong>Management Access:</strong> Senior management can access the Agreement tab and view the signed Agreement Form (PDF) directly in the browser with options to Download, Print, or view Version History. This is read-only — no edits are possible.
            </InfoBox>
          </DocPage>
        </div>

        {/* SECTIONS 13-20 */}
        <div id="docmgmt">
          <DocPage title="13. Document Management" subtitle="Upload, verify, and retrieve trainee documents" pageNum={30}>
            <H3>13.1 Document Lifecycle</H3>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 mb-5">
              {['Upload', 'OCR Extract', 'Pending Review', 'Verification', 'Approved / Rejected', 'Archived'].map((s, i, arr) => (
                <div key={s} className="flex items-center gap-2 flex-shrink-0">
                  <div className="px-3 py-2 rounded-lg text-xs font-semibold" style={{ background: '#1e3a5f', color: '#fff', fontFamily: 'Rajdhani, sans-serif' }}>{s}</div>
                  {i < arr.length - 1 && <span className="text-slate-400">→</span>}
                </div>
              ))}
            </div>
            <UL items={[
              'Supported formats: JPG, PNG, PDF (max 2 MB per file, 10 MB total)',
              'OCR extracts key fields (Aadhaar number, name, DOB) for pre-fill',
              'Drag-and-drop and click-to-upload both supported',
              'Image preview shown after upload',
              'Documents cannot be deleted after verification; only replaced',
              'All uploads are encrypted at rest (AES-256)',
            ]} />
          </DocPage>
        </div>

        <div id="verification">
          <DocPage title="14. Verification Workflow" subtitle="End-to-end document and application approval process" pageNum={32}>
            <H3>14.1 Verification States</H3>
            <Table
              headers={['Status', 'Color Code', 'Meaning', 'Next Action']}
              rows={[
                ['Submitted', 'Blue', 'Application received, pending review', 'Verifier picks up'],
                ['Under Review', 'Amber', 'Verifier is currently reviewing', 'Wait for decision'],
                ['Documents Missing', 'Red', 'Required docs not uploaded', 'Branch re-uploads'],
                ['Approved', 'Green', 'All verified, ready for batch', 'Assign to batch'],
                ['Rejected', 'Dark Red', 'Application rejected with reason', 'Re-register if eligible'],
              ]}
            />
            <H3>14.2 Verifier Actions</H3>
            <UL items={[
              'Approve individual documents or entire application',
              'Reject with mandatory reason code and remarks',
              'Request re-upload for specific documents',
              'Flag for senior review',
              'All actions are logged with timestamp and user ID',
            ]} />
          </DocPage>
        </div>

        <div id="batch">
          <DocPage title="15. Batch Allocation" subtitle="Assigning trainees to training batches" pageNum={34}>
            <H3>15.1 Batch Filters</H3>
            <UL items={['Branch', 'Trainer', 'Course / Job Role', 'Start Date', 'Available Capacity', 'NSQF Level']} />
            <H3>15.2 Allocation Process</H3>
            <P>After a trainee is verified, they appear in the "Batch Allocation Pending" queue. Branch users filter available batches and assign the trainee. The system checks capacity before allowing assignment.</P>
            <InfoBox color="amber">
              A batch must have at least 1 seat available. Over-allocation triggers a warning. Trainees can only be assigned to batches matching their scheme and job role.
            </InfoBox>
          </DocPage>
        </div>

        <div id="reports">
          <DocPage title="16. Reports" subtitle="Available reports and export formats" pageNum={36}>
            <H3>16.1 Report Catalog</H3>
            <Table
              headers={['Report Name', 'Scope', 'Filters Available', 'Export Formats']}
              rows={[
                ['Registration Report', 'All trainees registered in date range', 'Date, Branch, Scheme', 'Excel, PDF, CSV'],
                ['Branch Report', 'Center-wise trainee count and status', 'Region, State, Branch', 'Excel, PDF'],
                ['Batch Report', 'Batch utilization and completion %', 'Date, Course, Trainer', 'Excel, PDF'],
                ['Document Status Report', 'Missing/pending documents list', 'Status, Branch', 'Excel'],
                ['Gender Report', 'M/F/Other breakdown by branch', 'Branch, Scheme', 'Excel, Chart PNG'],
                ['Age Distribution', 'Age band analysis', 'Scheme, Branch', 'Excel, Chart PNG'],
                ['Trainer Performance', 'Batch completion by trainer', 'Trainer, Course', 'Excel, PDF'],
                ['Placement Report', 'Placed vs not placed by batch', 'Branch, Date, Course', 'Excel, PDF'],
              ]}
            />
          </DocPage>
        </div>

        <div id="analytics">
          <DocPage title="17. Analytics Dashboard" subtitle="Senior management analytics and KPI definitions" pageNum={38}>
            <H3>17.1 KPI Definitions</H3>
            <Table
              headers={['KPI', 'Definition', 'Formula', 'Target']}
              rows={[
                ['Enrollment Rate', '% of registered trainees who complete enrollment', '(Completed / Registered) × 100', '>85%'],
                ['Verification TAT', 'Average time from submission to verification', 'Avg(Verify Date − Submit Date)', '<72 hours'],
                ['Placement Rate', '% of certified trainees placed', '(Placed / Certified) × 100', '>60%'],
                ['Dropout Rate', '% trainees who left before completion', '(Dropped / Enrolled) × 100', '<10%'],
                ['Batch Utilization', '% of batch seats filled', '(Filled Seats / Total Seats) × 100', '>80%'],
                ['Daily Registration', 'New trainees registered per day', 'Count of new registrations per day', 'Per branch target'],
              ]}
            />
          </DocPage>
        </div>

        <div id="mobile">
          <DocPage title="18. Mobile UX" subtitle="Mobile-first registration experience" pageNum={40}>
            <H3>18.1 Mobile Adaptation Principles</H3>
            <UL items={[
              'One question per screen on mobile (vs. multi-column on desktop)',
              'Large touch targets — minimum 44×44px for all buttons',
              'Sticky "Next" and "Back" buttons fixed at the bottom of the viewport',
              'Camera integration for document capture (no need for file manager)',
              'Auto-save after every field change (not just step completion)',
              'Offline mode: form data preserved if connectivity drops',
              'Bottom sheet for dropdowns instead of native select elements',
              'Progress bar collapses to a numeric indicator (Step 2 of 5) on small screens',
            ]} />
            <InfoBox color="blue">
              The SES mobile experience is optimized for Android 8+ and iOS 14+ browsers. A native app wrapper is available through the NSDC mobile app (NSDCConnect) which provides additional features like biometric login.
            </InfoBox>
          </DocPage>
        </div>

        <div id="design-system">
          <DocPage title="19. Design System" subtitle="Color tokens, typography, and component library" pageNum={42}>
            <H3>19.1 Color Palette</H3>
            <div className="grid grid-cols-4 gap-3 mb-5">
              {[
                { name: 'Navy (Primary)', hex: '#1e3a5f', use: 'Navigation, headers, CTAs' },
                { name: 'Blue (Secondary)', hex: '#2563eb', use: 'Interactive elements, links' },
                { name: 'Sky (Accent)', hex: '#0ea5e9', use: 'Highlights, active states' },
                { name: 'Amber (Warning)', hex: '#d97706', use: 'Warnings, pending status' },
                { name: 'Green (Success)', hex: '#16a34a', use: 'Success states, verified' },
                { name: 'Red (Error)', hex: '#dc2626', use: 'Errors, rejected status' },
                { name: 'Slate 800', hex: '#1e293b', use: 'Body text, headings' },
                { name: 'Slate 400', hex: '#94a3b8', use: 'Labels, placeholders, captions' },
              ].map(c => (
                <div key={c.name} className="rounded-xl overflow-hidden" style={{ border: '1px solid #e2e8f0' }}>
                  <div className="h-12" style={{ background: c.hex }} />
                  <div className="p-2.5">
                    <div className="text-xs font-semibold text-slate-700">{c.name}</div>
                    <div className="text-xs font-mono text-slate-400">{c.hex}</div>
                    <div className="text-xs text-slate-500 mt-0.5">{c.use}</div>
                  </div>
                </div>
              ))}
            </div>
            <H3>19.2 Typography Scale</H3>
            <Table
              headers={['Role', 'Font', 'Size', 'Weight', 'Usage']}
              rows={[
                ['Display', 'Rajdhani', '32px', '800', 'Page titles, hero text'],
                ['Heading 2', 'Rajdhani', '24px', '700', 'Section headings'],
                ['Heading 3', 'Rajdhani', '18px', '600', 'Sub-section headings'],
                ['Body', 'Exo 2', '14px', '400', 'Paragraph text, descriptions'],
                ['Label', 'Exo 2', '12px', '600', 'Form labels, badge text'],
                ['Code', 'JetBrains Mono', '13px', '500', 'Trainee codes, Aadhaar, IFSC'],
                ['Caption', 'Exo 2', '11px', '400', 'Footnotes, timestamps'],
              ]}
            />
          </DocPage>
        </div>

        <div id="accessibility">
          <DocPage title="20. Accessibility Guidelines" subtitle="WCAG 2.1 AA compliance notes" pageNum={44}>
            <H3>20.1 Compliance Checklist</H3>
            <UL items={[
              'All text meets 4.5:1 contrast ratio against its background (AA standard)',
              'Interactive elements (buttons, links) have minimum 44×44px touch target size',
              'All form fields have visible labels (not just placeholder text)',
              'Error messages are announced via ARIA live regions for screen readers',
              'Keyboard navigation works for all interactive elements (Tab, Enter, Escape)',
              'Focus indicators are visible (2px blue ring) on all focusable elements',
              'Images have descriptive alt text; decorative images use alt=""',
              'Status badges use icon + color + text (not color alone)',
              'PDFs include accessible tagging',
            ]} />
          </DocPage>
        </div>

        {/* ADMIN LOGIN MANUAL */}
        <div id="credentials">
          <DocPage title="21. Credential Management & Login Manual" subtitle="Student Enrollment System (Web) — Admin Login for Branch User Manual" pageNum={45}>
            <div className="rounded-xl overflow-hidden mb-5" style={{ border: '2px solid #1e3a5f' }}>
              <div className="px-5 py-3" style={{ background: '#1e3a5f' }}>
                <div className="text-white font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>SES Admin Login for Branch User — Official Reference</div>
                <div className="text-blue-300 text-xs">Confidential · For authorized personnel only</div>
              </div>
              <div className="p-5">
                <H3>How to Log In as a Branch User</H3>
                <ol className="space-y-3">
                  {[
                    'Open the SES portal in your web browser: https://ses.nsdc.gov.in',
                    'On the login screen, select the "Branch / Center Login" tab (left tab)',
                    'Enter your assigned Username in the Username field (e.g., branch_hyd01)',
                    'Enter your Password in the Password field',
                    'Click the "Sign In →" button',
                    'You will be redirected to the Branch Dashboard upon successful authentication',
                    'If you see an error, double-check your credentials. Contact your system admin if locked out.',
                  ].map((step, i) => (
                    <li key={i} className="flex gap-3 text-sm text-slate-600">
                      <span className="w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center flex-shrink-0" style={{ background: '#1e3a5f', color: '#fff' }}>{i + 1}</span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            <div className="rounded-xl overflow-hidden" style={{ border: '2px solid #7c3aed' }}>
              <div className="px-5 py-3" style={{ background: '#7c3aed' }}>
                <div className="text-white font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Management Login — Official Reference</div>
                <div className="text-purple-300 text-xs">Confidential · For Senior Management only</div>
              </div>
              <div className="p-5">
                <H3>How to Log In as Senior Management</H3>
                <ol className="space-y-3">
                  {[
                    'Open the SES portal: https://ses.nsdc.gov.in',
                    'Select the "Management Login" tab (right tab, purple)',
                    'Enter your Management username (e.g., mgmt_admin)',
                    'Enter your password and click Sign In',
                    'You will land on the Executive Dashboard with full analytics',
                    'To view a trainee profile: scroll to Trainee Registry → click "View 360°"',
                    'The 360° profile shows photo, trainee code, agreement, all documents',
                  ].map((step, i) => (
                    <li key={i} className="flex gap-3 text-sm text-slate-600">
                      <span className="w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center flex-shrink-0" style={{ background: '#7c3aed', color: '#fff' }}>{i + 1}</span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>
            </div>
          </DocPage>
        </div>

        <div id="admin-login">
          <DocPage title="22. SES Admin Login — Branch User Manual (Full)" pageNum={47}>
            <H3>Password Policy</H3>
            <UL items={[
              'Minimum 8 characters',
              'At least 1 uppercase letter, 1 lowercase letter, 1 number, 1 special character',
              'Password expires every 90 days',
              'Cannot reuse last 5 passwords',
              'Account locked after 5 incorrect attempts (auto-unlocks after 30 minutes)',
            ]} />
            <H3>First Login (New Account)</H3>
            <P>On first login, the system forces a password reset. The temporary password provided by the administrator must be changed before accessing any feature.</P>
            <H3>Forgot Password</H3>
            <P>Click "Forgot Password?" on the login screen. Enter your registered mobile number. An OTP is sent. Enter the OTP and set a new password. Contact your administrator if your mobile number has changed.</P>
            <H3>Session Management</H3>
            <Table
              headers={['Parameter', 'Value', 'Notes']}
              rows={[
                ['Session Timeout', '30 minutes of inactivity', 'Warning shown at 28 minutes'],
                ['Max Concurrent Sessions', '1 per user', 'Second login logs out first session'],
                ['Token Refresh', 'Every 15 minutes', 'Transparent to user'],
                ['Logout', 'Click "Sign Out" in sidebar', 'Clears all session data'],
              ]}
            />
          </DocPage>
        </div>

        <div id="future">
          <DocPage title="23. Future Enhancements" pageNum={49}>
            <UL items={[
              'AI-powered duplicate detection using face recognition on uploaded photos',
              'WhatsApp integration for registration status notifications',
              'Offline-capable mobile app with sync on connectivity restore',
              'Bulk registration via Excel upload with validation',
              'Biometric attendance integration via Aadhaar-linked fingerprint scanner',
              'Employer portal for placement offers and trainee ratings',
              'Multilingual UI — support for 10 regional languages by 2025',
              'Integration with DigiLocker for automatic document verification',
              'Predictive analytics for dropout risk identification',
              'API marketplace for third-party integrations',
            ]} />
          </DocPage>
        </div>

        <div id="glossary">
          <DocPage title="24. Glossary" pageNum={51}>
            <Table
              headers={['Term', 'Full Form / Meaning']}
              rows={[
                ['SES', 'Student Enrollment System'],
                ['NSDC', 'National Skill Development Corporation'],
                ['PMKVY', 'Pradhan Mantri Kaushal Vikas Yojana'],
                ['DDU-GKY', 'Deen Dayal Upadhyaya Grameen Kaushalya Yojana'],
                ['NAPS', 'National Apprenticeship Promotion Scheme'],
                ['NSQF', 'National Skills Qualifications Framework'],
                ['SSC', 'Sector Skill Council'],
                ['DGT', 'Directorate General of Training'],
                ['TRN', 'Trainee Registration Number (prefix for Trainee Code)'],
                ['OCR', 'Optical Character Recognition — auto-reads text from uploaded images'],
                ['TAT', 'Turn-Around Time — time taken to process an application'],
                ['IFSC', 'Indian Financial System Code — used for bank transfer identification'],
                ['KPI', 'Key Performance Indicator'],
                ['MoU', 'Memorandum of Understanding — the trainee agreement document'],
                ['OTP', 'One-Time Password — for mobile/email verification'],
                ['RBAC', 'Role-Based Access Control — security model used in SES'],
              ]}
            />
            <div className="mt-8 pt-6 border-t text-center" style={{ borderColor: '#f1f5f9' }}>
              <div className="text-slate-400 text-xs">— End of Document —</div>
              <div className="text-slate-400 text-xs mt-1">Student Enrollment System User Manual · v3.2.1 · August 2024 · NSDC</div>
            </div>
          </DocPage>
        </div>

      </div>
    </div>
  )
}

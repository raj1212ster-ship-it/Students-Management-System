import { useState } from 'react'
import type React from 'react'
import {
  Users, CheckCircle, Clock, XCircle, CreditCard, AlertTriangle, Layers,
  Eye, Check, Download, ListChecks, X, UserPlus, ChevronDown, Search, ChevronRight,
  Plus, RefreshCw, Calendar, Square, CheckSquare,
} from 'lucide-react'

/* ── Types ───────────────────────────────────────────────── */
type Status = 'Pending' | 'Approved' | 'Rejected'
type RegStatus = 'Completed' | 'Incomplete'
type PanelMode = 'pending-reg' | 'batch-view' | 'batch-allocate' | 'quick-allocate' | 'payroll-list'

interface Trainee {
  id: number; code: string; name: string; aadhaar: string
  company: string; scheme: string; status: Status; payroll: boolean
  batch: string; regStatus: RegStatus; verStatus: string; payrollStatus: string
  docs: { aadhaar: boolean; photo: boolean; tenth: boolean; bank: boolean; offer: boolean }
}

interface BatchRow {
  id: string; batchName: string; trainer: string; capacity: number
  allocated: number; payroll: number; regStatus: string; regPending: number
}

/* ── Data ────────────────────────────────────────────────── */
const TRAINEES_INIT: Trainee[] = [
  { id: 1,  code: 'TRN000154', name: 'Rahul Sharma',  aadhaar: 'XXXX XXXX 1234', company: 'Amber Enterprises India Limited, Supa', scheme: 'WILP',  status: 'Pending',  payroll: true,  batch: 'Batch-05', regStatus: 'Completed',  verStatus: 'Pending Approval', payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 2,  code: 'TRN000155', name: 'Sneha Patil',   aadhaar: 'XXXX XXXX 2568', company: 'Minda Corporation Limited',            scheme: 'BVOC',  status: 'Approved', payroll: true,  batch: 'Batch-03', regStatus: 'Completed',  verStatus: 'Approved',         payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 3,  code: 'TRN000156', name: 'Amit Kumar',    aadhaar: 'XXXX XXXX 4589', company: 'Endurance Technologies Limited',       scheme: 'DVOC',  status: 'Rejected', payroll: false, batch: '—',        regStatus: 'Incomplete', verStatus: 'Rejected',         payrollStatus: 'Not Added',        docs: { aadhaar: true,  photo: false, tenth: true,  bank: false, offer: false } },
  { id: 4,  code: 'TRN000157', name: 'Priya Desai',   aadhaar: 'XXXX XXXX 3310', company: 'Hyundai Motor India Limited',          scheme: 'FLEXI', status: 'Approved', payroll: true,  batch: 'Batch-02', regStatus: 'Completed',  verStatus: 'Approved',         payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 5,  code: 'TRN000158', name: 'Vikram Nair',   aadhaar: 'XXXX XXXX 6621', company: 'TDK India Private Limited',            scheme: 'MSBTE', status: 'Pending',  payroll: false, batch: '—',        regStatus: 'Completed',  verStatus: 'Pending Approval', payrollStatus: 'Not Added',        docs: { aadhaar: true,  photo: true,  tenth: false, bank: true,  offer: false } },
  { id: 6,  code: 'TRN000159', name: 'Sunita Yadav',  aadhaar: 'XXXX XXXX 9982', company: 'Gilbarco Veeder Root India Pvt. Ltd.', scheme: 'WILP',  status: 'Approved', payroll: true,  batch: 'Batch-02', regStatus: 'Completed',  verStatus: 'Approved',         payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 7,  code: 'TRN000160', name: 'Kiran Reddy',   aadhaar: 'XXXX XXXX 4450', company: 'Electrontech Industries',              scheme: 'BVOC',  status: 'Pending',  payroll: false, batch: '—',        regStatus: 'Incomplete', verStatus: 'Pending Approval', payrollStatus: 'Not Added',        docs: { aadhaar: false, photo: true,  tenth: true,  bank: false, offer: true  } },
  { id: 8,  code: 'TRN000161', name: 'Meena Joshi',   aadhaar: 'XXXX XXXX 7730', company: 'V-Guard Consumer Products Limited',    scheme: 'FLEXI', status: 'Approved', payroll: true,  batch: 'Batch-06', regStatus: 'Completed',  verStatus: 'Approved',         payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 9,  code: 'TRN000162', name: 'Raju Singh',    aadhaar: 'XXXX XXXX 1195', company: 'Sintex India Limited',                 scheme: 'DVOC',  status: 'Rejected', payroll: false, batch: '—',        regStatus: 'Incomplete', verStatus: 'Rejected',         payrollStatus: 'Not Added',        docs: { aadhaar: true,  photo: false, tenth: false, bank: false, offer: false } },
  { id: 10, code: 'TRN000163', name: 'Divya Menon',   aadhaar: 'XXXX XXXX 5563', company: 'Jai Suspension Ltd.',                  scheme: 'MSBTE', status: 'Approved', payroll: true,  batch: 'Batch-04', regStatus: 'Completed',  verStatus: 'Approved',         payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: true,  bank: true,  offer: true  } },
  { id: 11, code: 'TRN000164', name: 'Arjun Patel',   aadhaar: 'XXXX XXXX 8832', company: 'Timken India Ltd',                     scheme: 'WILP',  status: 'Pending',  payroll: true,  batch: '—',        regStatus: 'Incomplete', verStatus: 'Pending Approval', payrollStatus: 'Added in Payroll', docs: { aadhaar: true,  photo: true,  tenth: false, bank: true,  offer: false } },
  { id: 12, code: 'TRN000165', name: 'Rekha Sharma',  aadhaar: 'XXXX XXXX 2241', company: 'Novateer Electrical & Digital Systems Pvt. Ltd. Ambad', scheme: 'BVOC', status: 'Approved', payroll: true, batch: 'Batch-01', regStatus: 'Completed', verStatus: 'Approved', payrollStatus: 'Added in Payroll', docs: { aadhaar: true, photo: true, tenth: true, bank: true, offer: true } },
]

const BATCH_SUMMARY = [
  { label: 'Total Batches',      value: 52, color: '#1565C0', bg: 'rgba(21,101,192,0.12)' },
  { label: 'Running Batches',    value: 18, color: '#16a34a', bg: 'rgba(22,163,74,0.12)'  },
  { label: 'Completed Batches',  value: 28, color: '#0891b2', bg: 'rgba(8,145,178,0.12)'  },
  { label: 'Pending Allocation', value: 6,  color: '#CA8A04', bg: 'rgba(202,138,4,0.12)'  },
]

const BATCH_TABLE: BatchRow[] = [
  { id: 'BAT001', batchName: 'Batch-01', trainer: 'Mr. Patil',    capacity: 50, allocated: 48, payroll: 48, regStatus: 'Complete', regPending: 0 },
  { id: 'BAT002', batchName: 'Batch-02', trainer: 'Mr. Shah',     capacity: 40, allocated: 39, payroll: 37, regStatus: 'Pending',  regPending: 2 },
  { id: 'BAT003', batchName: 'Batch-03', trainer: 'Mrs. Singh',   capacity: 45, allocated: 45, payroll: 45, regStatus: 'Complete', regPending: 0 },
  { id: 'BAT004', batchName: 'Batch-04', trainer: 'Mr. Jadhav',   capacity: 50, allocated: 44, payroll: 42, regStatus: 'Pending',  regPending: 2 },
  { id: 'BAT005', batchName: 'Batch-05', trainer: 'Ms. Kulkarni', capacity: 40, allocated: 40, payroll: 40, regStatus: 'Complete', regPending: 0 },
  { id: 'BAT006', batchName: 'Batch-06', trainer: 'Mr. Rao',      capacity: 45, allocated: 31, payroll: 29, regStatus: 'Pending',  regPending: 2 },
]

/* ── Shared styles ────────────────────────────────────────── */
const GLASS: React.CSSProperties = {
  background: 'rgba(255,255,255,0.72)',
  backdropFilter: 'blur(18px) saturate(130%)',
  WebkitBackdropFilter: 'blur(18px) saturate(130%)',
  border: '1px solid rgba(255,255,255,0.75)',
}
const CARD_SHADOW = '0 4px 24px rgba(21,101,192,0.10), inset 0 1px 0 rgba(255,255,255,0.90)'

const STATUS_CFG = {
  Pending:  { bg: 'rgba(202,138,4,0.12)',  color: '#A16207', dot: '#CA8A04' },
  Approved: { bg: 'rgba(22,163,74,0.12)',  color: '#15803D', dot: '#16a34a' },
  Rejected: { bg: 'rgba(229,57,53,0.12)',  color: '#B91C1C', dot: '#E53935' },
}

/* ── Sub-components ─────────────────────────────────────── */
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <span className="text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full"
        style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0', border: '1px solid rgba(21,101,192,0.18)', fontFamily: "'Exo 2', sans-serif" }}>
        {children}
      </span>
      <div className="flex-1 h-px" style={{ background: 'rgba(21,101,192,0.12)' }} />
    </div>
  )
}

/* ── KPI Detail Panel ───────────────────────────────────── */
function KpiDetailPanel({ title, subtitle, accentGradient, rows, onClose }: {
  title: string; subtitle: string; accentGradient: string
  rows: Trainee[]; onClose: () => void
}) {
  const [search, setSearch] = useState('')
  const visible = rows.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.code.toLowerCase().includes(search.toLowerCase())
  )
  return (
    <>
      <div className="fixed inset-0 z-40" style={{ background: 'rgba(13,43,94,0.30)', backdropFilter: 'blur(4px)' }} onClick={onClose} />
      <div className="fixed right-0 top-0 h-full z-50 flex flex-col"
        style={{ width: 540, background: 'rgba(255,255,255,0.94)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderLeft: '1px solid rgba(255,255,255,0.80)', boxShadow: '-8px 0 48px rgba(21,101,192,0.16)' }}>
        {/* Header */}
        <div className="flex-shrink-0 px-5 py-4 flex items-center justify-between"
          style={{ background: accentGradient, borderBottom: '1px solid rgba(255,255,255,0.18)' }}>
          <div>
            <div className="font-black text-lg text-white" style={{ fontFamily: 'Rajdhani,sans-serif' }}>{title}</div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.82)', fontFamily: "'Exo 2',sans-serif" }}>{subtitle}</div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.20)', color: '#fff', border: '1px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}>
            <X size={15} />
          </button>
        </div>
        {/* Search */}
        <div className="flex-shrink-0 px-5 py-3" style={{ borderBottom: '1px solid rgba(21,101,192,0.08)' }}>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
            style={{ background: 'rgba(21,101,192,0.06)', border: '1px solid rgba(21,101,192,0.14)' }}>
            <Search size={13} style={{ color: '#7A90A8' }} />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name or code…"
              className="flex-1 bg-transparent outline-none text-sm" style={{ color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }} />
            {search && <button onClick={() => setSearch('')}><X size={11} style={{ color: '#7A90A8', cursor: 'pointer' }} /></button>}
          </div>
        </div>
        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          {visible.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Search size={28} style={{ color: '#B0BECE', marginBottom: 10 }} />
              <div className="text-sm font-semibold" style={{ color: '#4A6080', fontFamily: 'Rajdhani,sans-serif' }}>No matching records</div>
            </div>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead className="sticky top-0">
                <tr style={{ background: 'rgba(21,101,192,0.05)', borderBottom: '1px solid rgba(21,101,192,0.10)' }}>
                  {['#','Code','Name','Company','Scheme','Status','Payroll','Batch'].map(h => (
                    <th key={h} style={{ padding: '10px 12px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: '#4A6080', fontFamily: "'Exo 2',sans-serif", textTransform: 'uppercase', letterSpacing: '0.05em', whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {visible.map((t, i) => {
                  const sc = STATUS_CFG[t.status]
                  return (
                    <tr key={t.id} style={{ borderBottom: '1px solid rgba(21,101,192,0.06)', transition: 'background 0.12s' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(21,101,192,0.03)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ padding: '10px 12px', fontSize: 12, color: '#7A90A8' }}>{i + 1}</td>
                      <td style={{ padding: '10px 12px', fontSize: 11, color: '#1565C0', fontWeight: 700, whiteSpace: 'nowrap' }}>{t.code}</td>
                      <td style={{ padding: '10px 12px', fontSize: 12, color: '#0D2B5E', fontWeight: 600, whiteSpace: 'nowrap', fontFamily: "'Exo 2',sans-serif" }}>{t.name}</td>
                      <td style={{ padding: '10px 12px', fontSize: 11, color: '#4A6080', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontFamily: "'Exo 2',sans-serif" }}>{t.company}</td>
                      <td style={{ padding: '10px 12px' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: 'rgba(124,58,237,0.10)', color: '#7c3aed', fontFamily: "'Exo 2',sans-serif" }}>{t.scheme}</span>
                      </td>
                      <td style={{ padding: '10px 12px' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: sc.bg, color: sc.color, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                          <span style={{ width: 6, height: 6, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />{t.status}
                        </span>
                      </td>
                      <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 700, background: t.payroll ? 'rgba(22,163,74,0.10)' : 'rgba(229,57,53,0.08)', color: t.payroll ? '#15803D' : '#B91C1C', fontFamily: "'Exo 2',sans-serif" }}>
                          {t.payroll ? 'Yes' : 'No'}
                        </span>
                      </td>
                      <td style={{ padding: '10px 12px', fontSize: 11, color: '#4A6080', fontFamily: 'monospace' }}>{t.batch}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
        </div>
        {/* Footer */}
        <div className="flex-shrink-0 px-5 py-3 flex items-center justify-between"
          style={{ borderTop: '1px solid rgba(21,101,192,0.10)', background: 'rgba(21,101,192,0.03)' }}>
          <span style={{ fontSize: 12, color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{visible.length} record{visible.length !== 1 ? 's' : ''}</span>
          <button onClick={onClose} className="px-5 py-2 rounded-xl text-xs font-semibold"
            style={{ background: 'rgba(21,101,192,0.09)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            Close
          </button>
        </div>
      </div>
    </>
  )
}

function KpiCard({ label, value, Icon, color, bg, sub, onClick }: {
  label: string; value: string | number; Icon: React.ElementType; color: string; bg: string; sub?: string; onClick?: () => void
}) {
  return (
    <button onClick={onClick}
      className="rounded-xl p-4 flex flex-col gap-2 transition-all duration-200 text-left w-full"
      style={{ ...GLASS, boxShadow: CARD_SHADOW, cursor: onClick ? 'pointer' : 'default' }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'; (e.currentTarget as HTMLElement).style.boxShadow = `0 0 32px ${color}22, 0 8px 32px rgba(21,101,192,0.13), inset 0 1px 0 rgba(255,255,255,0.90)` }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = ''; (e.currentTarget as HTMLElement).style.boxShadow = CARD_SHADOW }}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-semibold leading-snug" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>{label}</p>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: bg, color }}>
          <Icon size={16} />
        </div>
      </div>
      <div className="text-2xl font-bold leading-none" style={{ color, fontFamily: 'Rajdhani, sans-serif' }}>{value}</div>
      <div className="flex items-center justify-between">
        {sub && <div className="text-xs" style={{ color: '#7A90A8', fontFamily: "'Exo 2', sans-serif" }}>{sub}</div>}
        {onClick && <ChevronRight size={12} style={{ color: '#B0BECE', marginLeft: 'auto' }} />}
      </div>
    </button>
  )
}

/* ── Trainee row in panel table ─────────────────────────── */
function TraineeTableRow({ t, idx, action }: { t: Trainee; idx: number; action?: React.ReactNode }) {
  const sc = STATUS_CFG[t.status]
  return (
    <tr style={{ borderBottom: '1px solid rgba(21,101,192,0.06)', transition: 'background 0.12s' }}
      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(21,101,192,0.03)')}
      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
      <td style={{ padding: '10px 12px', fontSize: 12, color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{idx + 1}</td>
      <td style={{ padding: '10px 12px', fontSize: 11, color: '#1565C0', fontFamily: 'JetBrains Mono,monospace', fontWeight: 600, whiteSpace: 'nowrap' }}>{t.code}</td>
      <td style={{ padding: '10px 12px', fontSize: 12, color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", fontWeight: 600, whiteSpace: 'nowrap' }}>{t.name}</td>
      <td style={{ padding: '10px 12px', fontSize: 11, color: '#4A6080', fontFamily: "'Exo 2',sans-serif", maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.company}</td>
      <td style={{ padding: '10px 12px' }}>
        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: sc.bg, color: sc.color, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
          <span style={{ width: 6, height: 6, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />
          {t.status}
        </span>
      </td>
      {action && <td style={{ padding: '8px 12px' }}>{action}</td>}
    </tr>
  )
}

/* ── Data Panel (slide-over) ─────────────────────────────── */
function DataPanel({ mode, batch, trainees, onClose, onAllocate }: {
  mode: PanelMode
  batch?: BatchRow
  trainees: Trainee[]
  onClose: () => void
  onAllocate: (traineeId: number, batchName: string) => void
}) {
  const [selectedBatch, setSelectedBatch] = useState(BATCH_TABLE[0].batchName)

  const isPendingReg   = mode === 'pending-reg'
  const isBatchView    = mode === 'batch-view'
  const isBatchAlloc   = mode === 'batch-allocate'
  const isQuickAlloc   = mode === 'quick-allocate'
  const isPayrollList  = mode === 'payroll-list'
  const rows =
    isPendingReg  ? trainees.filter(t => t.payroll && t.regStatus === 'Incomplete') :
    isBatchView   ? trainees.filter(t => t.batch === batch!.batchName) :
    isBatchAlloc  ? trainees.filter(t => t.batch === '—') :
    isQuickAlloc  ? trainees.filter(t => t.batch === '—') :
    trainees.filter(t => t.payroll)  // payroll-list

  const title =
    isPendingReg  ? 'Pending Registration' :
    isBatchView   ? `Batch Trainees — ${batch!.id}` :
    isBatchAlloc  ? `Allocate to ${batch!.id}` :
    isQuickAlloc  ? 'Allocate Batch' :
    'Payroll List'

  const subtitle =
    isPendingReg  ? `${rows.length} trainees on payroll with incomplete registration` :
    isBatchView   ? `${rows.length} trainees assigned · Trainer: ${batch!.trainer}` :
    isBatchAlloc  ? `${rows.length} unallocated trainees — assign to ${batch!.id}` :
    isQuickAlloc  ? `${rows.length} unallocated trainees — select batch and assign` :
    `${rows.length} trainees currently on payroll`

  const headerGradient =
    isPendingReg  ? 'linear-gradient(120deg,#C2470A,#F97316)' :
    isQuickAlloc || isBatchAlloc ? 'linear-gradient(120deg,#7c3aed,#1565C0)' :
    isPayrollList ? 'linear-gradient(120deg,#5b21b6,#7c3aed)' :
    'linear-gradient(120deg,#1565C0,#1976D2 60%,#F97316)'

  const showAssignCol  = isBatchAlloc || isQuickAlloc
  const showPayrollCol = isPayrollList
  const showBatchCol   = isPayrollList

  const cols = [
    '#', 'Code', 'Name', 'Company', 'Scheme',
    ...(showBatchCol   ? ['Batch']   : []),
    ...(showPayrollCol ? ['Payroll'] : []),
    'Status',
    ...(showAssignCol  ? ['Assign']  : []),
  ]

  return (
    <>
      <div className="fixed inset-0 z-40"
        style={{ background: 'rgba(13,43,94,0.28)', backdropFilter: 'blur(4px)' }}
        onClick={onClose}
      />
      <div className="fixed right-0 top-0 h-full z-50 flex flex-col"
        style={{ width: 620, background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderLeft: '1px solid rgba(255,255,255,0.80)', boxShadow: '-8px 0 48px rgba(21,101,192,0.16)' }}>

        {/* Header */}
        <div className="flex-shrink-0" style={{ background: headerGradient, padding: '18px 20px' }}>
          <div className="flex items-start justify-between mb-2">
            <div>
              <div className="font-bold text-lg text-white" style={{ fontFamily: 'Rajdhani, sans-serif', lineHeight: '22px' }}>{title}</div>
              <div className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.80)', fontFamily: "'Exo 2',sans-serif" }}>{subtitle}</div>
            </div>
            <button onClick={onClose}
              className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.18)', color: '#fff', border: '1px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}>
              <X size={15} />
            </button>
          </div>

          {/* Batch meta chips */}
          {batch && (
            <div className="flex flex-wrap gap-2 mt-3">
              {[
                { label: 'Trainer',   val: batch.trainer },
                { label: 'Capacity',  val: String(batch.capacity) },
                { label: 'Allocated', val: String(batch.allocated) },
                { label: 'Payroll',   val: String(batch.payroll) },
              ].map(c => (
                <div key={c.label} className="px-3 py-1 rounded-lg"
                  style={{ background: 'rgba(255,255,255,0.18)', backdropFilter: 'blur(8px)' }}>
                  <span style={{ color: 'rgba(255,255,255,0.70)', fontSize: 10, fontFamily: "'Exo 2',sans-serif" }}>{c.label}: </span>
                  <span style={{ color: '#fff', fontSize: 11, fontWeight: 700, fontFamily: "'Exo 2',sans-serif" }}>{c.val}</span>
                </div>
              ))}
            </div>
          )}

          {/* Quick Allocate: batch selector */}
          {isQuickAlloc && (
            <div className="flex items-center gap-3 mt-3">
              <span style={{ color: 'rgba(255,255,255,0.80)', fontSize: 12, fontFamily: "'Exo 2',sans-serif", whiteSpace: 'nowrap' }}>Assign to:</span>
              <div style={{ position: 'relative', flex: 1, maxWidth: 220 }}>
                <select value={selectedBatch} onChange={e => setSelectedBatch(e.target.value)}
                  style={{ width: '100%', padding: '6px 28px 6px 10px', borderRadius: 8, fontSize: 12, border: '1px solid rgba(255,255,255,0.40)', background: 'rgba(255,255,255,0.18)', color: '#fff', fontFamily: "'Exo 2',sans-serif", appearance: 'none', outline: 'none', cursor: 'pointer' }}>
                  {BATCH_TABLE.map(b => <option key={b.id} value={b.batchName} style={{ color: '#0D2B5E', background: '#fff' }}>{b.id} — {b.batchName} ({b.trainer})</option>)}
                </select>
                <ChevronDown size={11} style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', color: 'rgba(255,255,255,0.70)', pointerEvents: 'none' }} />
              </div>
            </div>
          )}

        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto" style={{ background: 'rgba(245,248,255,0.80)' }}>
          {rows.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-16 text-center px-8">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
                style={{ background: 'rgba(21,101,192,0.08)' }}>
                <Users size={24} style={{ color: '#B0BECE' }} />
              </div>
              <div className="text-base font-bold mb-1" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>No records found</div>
              <div className="text-sm" style={{ color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>
                {isPendingReg ? 'All payroll trainees have completed registration.' :
                 showAssignCol ? 'No unallocated trainees available.' :
                 'No trainees to display.'}
              </div>
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 500 }}>
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(21,101,192,0.10)', position: 'sticky', top: 0 }}>
                    {cols.map(h => (
                      <th key={h} style={{ padding: '10px 12px', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#4A6080', fontFamily: "'Exo 2',sans-serif", whiteSpace: 'nowrap', background: 'rgba(240,244,255,0.97)' }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((t, idx) => {
                    const sc = STATUS_CFG[t.status]
                    return (
                      <tr key={t.id} style={{ borderBottom: '1px solid rgba(21,101,192,0.06)', transition: 'background 0.12s' }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'rgba(21,101,192,0.03)')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                        <td style={{ padding: '10px 12px', fontSize: 12, color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{idx + 1}</td>
                        <td style={{ padding: '10px 12px', fontSize: 11, color: '#1565C0', fontFamily: 'JetBrains Mono,monospace', fontWeight: 600, whiteSpace: 'nowrap' }}>{t.code}</td>
                        <td style={{ padding: '10px 12px', fontSize: 12, color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", fontWeight: 600, whiteSpace: 'nowrap' }}>{t.name}</td>
                        <td style={{ padding: '10px 12px', fontSize: 11, color: '#4A6080', fontFamily: "'Exo 2',sans-serif", maxWidth: 130, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.company}</td>
                        <td style={{ padding: '10px 12px' }}>
                          <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: 'rgba(21,101,192,0.08)', color: '#1565C0', fontFamily: "'Exo 2',sans-serif" }}>{t.scheme}</span>
                        </td>
                        {showBatchCol && (
                          <td style={{ padding: '10px 12px', fontSize: 11, color: '#7c3aed', fontFamily: 'JetBrains Mono,monospace', fontWeight: 600 }}>{t.batch}</td>
                        )}
                        {showPayrollCol && (
                          <td style={{ padding: '10px 12px' }}>
                            <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: t.payroll ? 'rgba(22,163,74,0.12)' : 'rgba(229,57,53,0.10)', color: t.payroll ? '#15803D' : '#B91C1C', fontFamily: "'Exo 2',sans-serif" }}>
                              {t.payroll ? 'Yes' : 'No'}
                            </span>
                          </td>
                        )}
                        <td style={{ padding: '10px 12px' }}>
                          <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: sc.bg, color: sc.color, display: 'inline-flex', alignItems: 'center', gap: 4, fontFamily: "'Exo 2',sans-serif" }}>
                            <span style={{ width: 6, height: 6, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />{t.status}
                          </span>
                        </td>
                        {showAssignCol && (
                          <td style={{ padding: '8px 12px' }}>
                            <button
                              onClick={() => onAllocate(t.id, isBatchAlloc ? batch!.batchName : selectedBatch)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-white"
                              style={{ background: 'linear-gradient(135deg,#7c3aed,#1565C0)', boxShadow: '0 3px 8px rgba(124,58,237,0.28)', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', whiteSpace: 'nowrap' }}>
                              <UserPlus size={11} /> Assign
                            </button>
                          </td>
                        )}
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex-shrink-0 flex items-center justify-between px-5 py-3"
          style={{ borderTop: '1px solid rgba(21,101,192,0.10)', background: 'rgba(255,255,255,0.80)' }}>
          <span style={{ fontSize: 12, color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>
            {rows.length} record{rows.length !== 1 ? 's' : ''}
          </span>
          <div className="flex gap-2">
            <button onClick={onClose}
              className="px-5 py-2 rounded-xl text-xs font-semibold"
              style={{ background: 'rgba(21,101,192,0.09)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer' }}>
              Close
            </button>
          </div>
        </div>
      </div>
    </>
  )
}

/* ── Main Component ─────────────────────────────────────── */
interface BatchManagementProps {
  onNavigate: (screen: string) => void
}

type KpiPanelState = { title: string; subtitle: string; gradient: string; rows: Trainee[] } | null

export default function BatchManagement({ onNavigate: _onNavigate }: BatchManagementProps) {
  const [trainees, setTrainees] = useState<Trainee[]>(TRAINEES_INIT)
  const [panel, setPanel] = useState<{ mode: PanelMode; batch?: BatchRow } | null>(null)
  const [kpiPanel, setKpiPanel] = useState<KpiPanelState>(null)

  // Batch Allocation form state
  const [showBatchForm, setShowBatchForm] = useState(false)
  const [batchMonth, setBatchMonth] = useState('July 2026')
  const [batchScheme, setBatchScheme] = useState('')
  const [batchZone, setBatchZone] = useState('')
  const [batchCompany, setBatchCompany] = useState('')
  const [batchNameInput, setBatchNameInput] = useState('')
  const [expectedTrainees, setExpectedTrainees] = useState(350)
  const [batchGenerated, setBatchGenerated] = useState(false)
  const [filterPendingReg, setFilterPendingReg] = useState(false)
  const [filterCompletedReg, setFilterCompletedReg] = useState(false)
  const [filterPayrollEligible, setFilterPayrollEligible] = useState(false)
  const [searchTab, setSearchTab] = useState<'code' | 'aadhaar' | 'mobile' | 'name'>('code')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set())

  const pendingAlert = trainees.filter(t => t.payroll && t.regStatus === 'Incomplete').length

  const kpiData = {
    total:      { rows: trainees,                                                   title: 'Total Registrations',     gradient: 'linear-gradient(120deg,#1565C0,#1976D2 60%,#F97316)' },
    completed:  { rows: trainees.filter(t => t.status === 'Approved'),              title: 'Completed Enrollment',    gradient: 'linear-gradient(120deg,#15803D,#16a34a)'              },
    pending:    { rows: trainees.filter(t => t.status === 'Pending'),               title: 'Pending Verification',    gradient: 'linear-gradient(120deg,#C2470A,#F97316)'              },
    rejected:   { rows: trainees.filter(t => t.status === 'Rejected'),              title: 'Rejected Applications',   gradient: 'linear-gradient(120deg,#B91C1C,#E53935)'              },
    payroll:    { rows: trainees.filter(t => t.payroll),                            title: 'Payroll Trainees',        gradient: 'linear-gradient(120deg,#5b21b6,#7c3aed)'              },
    incomplete: { rows: trainees.filter(t => t.payroll && t.regStatus === 'Incomplete'), title: 'Registration Incomplete', gradient: 'linear-gradient(120deg,#C2470A,#F97316)'         },
  }

  const openKpi = (key: keyof typeof kpiData) => {
    const d = kpiData[key]
    setKpiPanel({ title: d.title, subtitle: `${d.rows.length} trainee${d.rows.length !== 1 ? 's' : ''}`, gradient: d.gradient, rows: d.rows })
  }

  const allocTrainees = trainees.filter(t => {
    if (filterPayrollEligible && !t.payroll) return false
    if (filterPendingReg && t.regStatus !== 'Incomplete') return false
    if (filterCompletedReg && t.regStatus !== 'Completed') return false
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      if (searchTab === 'code')   return t.code.toLowerCase().includes(q)
      if (searchTab === 'aadhaar') return t.aadhaar.toLowerCase().includes(q)
      if (searchTab === 'name')   return t.name.toLowerCase().includes(q)
      return false
    }
    return true
  })

  const allAllocSelected = allocTrainees.length > 0 && allocTrainees.every(t => selectedIds.has(t.id))
  const toggleAllAlloc = () => {
    if (allAllocSelected) {
      setSelectedIds(prev => { const s = new Set(prev); allocTrainees.forEach(t => s.delete(t.id)); return s })
    } else {
      setSelectedIds(prev => { const s = new Set(prev); allocTrainees.forEach(t => s.add(t.id)); return s })
    }
  }
  const toggleAllocId = (id: number) => {
    setSelectedIds(prev => { const s = new Set(prev); s.has(id) ? s.delete(id) : s.add(id); return s })
  }

  const exportCSV = () => {
    const headers = ['#', 'Trainee Code', 'Name', 'Aadhaar', 'Company', 'Scheme', 'Batch', 'Status', 'Payroll', 'Reg Status', 'Ver Status']
    const rows = trainees.map((t, i) => [
      i + 1, t.code, t.name, t.aadhaar, t.company, t.scheme,
      t.batch, t.status, t.payroll ? 'Yes' : 'No', t.regStatus, t.verStatus,
    ])
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a')
    a.href = url; a.download = `batch-report-${new Date().toISOString().slice(0, 10)}.csv`
    a.click(); URL.revokeObjectURL(url)
  }

  const handleAllocate = (traineeId: number, batchName: string) => {
    setTrainees(prev => prev.map(t => t.id === traineeId ? { ...t, batch: batchName } : t))
  }

  return (
    <div className="space-y-6">

      {/* KPI Detail Panel */}
      {kpiPanel && (
        <KpiDetailPanel
          title={kpiPanel.title}
          subtitle={kpiPanel.subtitle}
          accentGradient={kpiPanel.gradient}
          rows={kpiPanel.rows}
          onClose={() => setKpiPanel(null)}
        />
      )}

      {/* Panel */}
      {panel && (
        <DataPanel
          mode={panel.mode}
          batch={panel.batch}
          trainees={trainees}
          onClose={() => setPanel(null)}
          onAllocate={handleAllocate}
        />
      )}

      {/* ── Banner ──────────────────────────────────────── */}
      <div className="rounded-2xl p-5 relative overflow-hidden"
        style={{ background: 'linear-gradient(120deg,#1565C0 0%,#1976D2 55%,#F97316 100%)', boxShadow: '0 0 60px rgba(21,101,192,0.25), 0 8px 32px rgba(21,101,192,0.20)', border: '1px solid rgba(255,255,255,0.20)' }}>
        <div className="absolute right-0 top-0 w-56 h-56 rounded-full opacity-10 hidden sm:block" style={{ background: 'white', transform: 'translate(30%,-40%)' }} />
        <div className="relative z-10">
          <p className="text-xs font-medium mb-1" style={{ color: 'rgba(255,255,255,0.80)', fontFamily: "'Exo 2', sans-serif" }}>Branch Center · Hyderabad</p>
          <h1 className="text-xl md:text-2xl font-bold text-white" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Batch Management</h1>
          <p className="text-sm mt-1 hidden sm:block" style={{ color: 'rgba(255,255,255,0.75)', fontFamily: "'Exo 2', sans-serif" }}>
            Manage batches, verify trainees, track payroll, and monitor enrollment completion.
          </p>
        </div>
      </div>

      {/* KPI DASHBOARD */}
      <div>
        <SectionTitle>KPI Dashboard</SectionTitle>
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
          <KpiCard label="Total Registrations"     value={kpiData.total.rows.length}      Icon={Users}         color="#1565C0" bg="rgba(21,101,192,0.12)" onClick={() => openKpi('total')} />
          <KpiCard label="Completed Enrollment"    value={kpiData.completed.rows.length}  Icon={CheckCircle}   color="#16a34a" bg="rgba(22,163,74,0.12)"  onClick={() => openKpi('completed')} />
          <KpiCard label="Pending Verification"    value={kpiData.pending.rows.length}    Icon={Clock}         color="#CA8A04" bg="rgba(202,138,4,0.12)"  onClick={() => openKpi('pending')} />
          <KpiCard label="Rejected Applications"   value={kpiData.rejected.rows.length}   Icon={XCircle}       color="#E53935" bg="rgba(229,57,53,0.12)"  onClick={() => openKpi('rejected')} />
          <KpiCard label="Payroll Trainees"        value={kpiData.payroll.rows.length}    Icon={CreditCard}    color="#7c3aed" bg="rgba(124,58,237,0.12)" onClick={() => openKpi('payroll')} />
          <KpiCard label="Registration Incomplete" value={kpiData.incomplete.rows.length} Icon={AlertTriangle} color="#F97316" bg="rgba(249,115,22,0.12)" sub="Payroll added, reg. pending" onClick={() => openKpi('incomplete')} />
        </div>
      </div>

      {/* BATCH ALLOCATION */}
      <div>
        {/* Section header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3 flex-1 mr-4">
            <span className="text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full whitespace-nowrap"
              style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0', border: '1px solid rgba(21,101,192,0.18)', fontFamily: "'Exo 2', sans-serif" }}>
              Batch Allocation
            </span>
            <div className="flex-1 h-px" style={{ background: 'rgba(21,101,192,0.12)' }} />
          </div>
          <button
            onClick={() => setShowBatchForm(v => !v)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all"
            style={{ background: showBatchForm ? 'linear-gradient(135deg,#1565C0,#1976D2)' : 'rgba(21,101,192,0.09)', color: showBatchForm ? '#fff' : '#1565C0', border: '1px solid rgba(21,101,192,0.22)', cursor: 'pointer', boxShadow: showBatchForm ? '0 4px 12px rgba(21,101,192,0.28)' : 'none', fontFamily: "'Exo 2', sans-serif" }}>
            <Plus size={12} /> Create Monthly Batch
          </button>
        </div>

        {/* Allocation stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          {([
            { label: 'Active Batches',   value: 12,  Icon: Layers,        color: '#1565C0', bg: 'rgba(21,101,192,0.10)' },
            { label: 'Payroll Ready',    value: 356, Icon: CreditCard,    color: '#7c3aed', bg: 'rgba(124,58,237,0.10)' },
            { label: 'Pending Reg.',     value: 28,  Icon: AlertTriangle, color: '#E53935', bg: 'rgba(229,57,53,0.10)'  },
            { label: 'Completed Reg.',   value: 328, Icon: CheckCircle,   color: '#16a34a', bg: 'rgba(22,163,74,0.10)'  },
          ] as const).map(c => (
            <div key={c.label} className="rounded-2xl p-4 flex flex-col gap-2" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold leading-snug" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>{c.label}</span>
                <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: c.bg, color: c.color }}>
                  <c.Icon size={15} />
                </div>
              </div>
              <div className="text-3xl font-bold" style={{ color: c.color, fontFamily: 'Rajdhani, sans-serif' }}>{c.value}</div>
            </div>
          ))}
        </div>

        {/* Monthly Payroll Batch Form */}
        {showBatchForm && (
          <div className="rounded-2xl p-5 mb-5" style={{ ...GLASS, boxShadow: CARD_SHADOW, border: '1.5px solid rgba(21,101,192,0.18)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Calendar size={15} style={{ color: '#1565C0' }} />
              <h3 className="font-bold text-sm" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>Monthly Payroll Batch</h3>
            </div>

            {/* Dropdowns row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
              {([
                { label: 'Month',   value: batchMonth,   setter: setBatchMonth,   options: ['April 2026','May 2026','June 2026','July 2026','August 2026'] },
                { label: 'Scheme',  value: batchScheme,  setter: setBatchScheme,  options: ['PMKVY','DDUGKY','WILP','BVOC','DVOC','FLEXI','MSBTE'] },
                { label: 'Zone',    value: batchZone,    setter: setBatchZone,    options: ['North','South','East','West','Central'] },
                { label: 'Company', value: batchCompany, setter: setBatchCompany, options: ['Suzlon','Vestas','Inox Wind','Adani Green','Hyundai','TDK India'] },
              ] as const).map(f => (
                <div key={f.label} className="flex flex-col gap-1">
                  <label className="text-xs font-semibold" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>{f.label}</label>
                  <div style={{ position: 'relative' }}>
                    <select
                      value={f.value}
                      onChange={e => (f.setter as (v: string) => void)(e.target.value)}
                      style={{ width: '100%', padding: '8px 28px 8px 10px', borderRadius: 10, fontSize: 12, border: '1px solid rgba(21,101,192,0.20)', background: 'rgba(255,255,255,0.80)', color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", appearance: 'none', outline: 'none', cursor: 'pointer' }}>
                      <option value="">— Select —</option>
                      {f.options.map(o => <option key={o} value={o}>{o}</option>)}
                    </select>
                    <ChevronDown size={11} style={{ position: 'absolute', right: 9, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
                  </div>
                </div>
              ))}
            </div>

            {/* Name + Expected row */}
            <div className="flex flex-col sm:flex-row gap-3 mb-4">
              <div className="flex flex-col gap-1 flex-1">
                <label className="text-xs font-semibold" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>Payroll Batch Name</label>
                <input
                  type="text"
                  value={batchNameInput}
                  onChange={e => setBatchNameInput(e.target.value)}
                  placeholder="e.g. Batch-July-PMKVY-2026"
                  style={{ padding: '8px 12px', borderRadius: 10, fontSize: 12, border: '1px solid rgba(21,101,192,0.20)', background: 'rgba(255,255,255,0.80)', color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", outline: 'none', width: '100%' }}
                />
              </div>
              <div className="flex flex-col gap-1" style={{ minWidth: 160 }}>
                <label className="text-xs font-semibold" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>Expected Trainees</label>
                <input
                  type="number"
                  value={expectedTrainees}
                  onChange={e => setExpectedTrainees(Number(e.target.value))}
                  style={{ padding: '8px 12px', borderRadius: 10, fontSize: 12, border: '1px solid rgba(21,101,192,0.20)', background: 'rgba(255,255,255,0.80)', color: '#0D2B5E', fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, outline: 'none', width: '100%' }}
                />
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => { setBatchGenerated(true); setShowBatchForm(false) }}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg,#1565C0,#1976D2)', boxShadow: '0 4px 14px rgba(21,101,192,0.30)', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer' }}>
                <CheckSquare size={13} /> Generate Batch
              </button>
              <button
                onClick={() => { setBatchMonth('July 2026'); setBatchScheme(''); setBatchZone(''); setBatchCompany(''); setBatchNameInput(''); setExpectedTrainees(350); setBatchGenerated(false) }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold"
                style={{ background: 'rgba(100,116,139,0.10)', border: '1px solid rgba(100,116,139,0.22)', color: '#475569', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer' }}>
                <RefreshCw size={12} /> Reset
              </button>
            </div>
          </div>
        )}

        {/* Divider */}
        <div className="h-px mb-5" style={{ background: 'rgba(21,101,192,0.12)' }} />

        {/* Registration Status filters */}
        <div className="rounded-2xl p-4 mb-4" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          <h3 className="font-bold text-sm mb-3" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>Registration Status</h3>
          <div className="flex flex-wrap gap-5">
            {([
              { label: 'Show Only Pending Registration', value: filterPendingReg,       setter: setFilterPendingReg },
              { label: 'Show Completed Registration',    value: filterCompletedReg,     setter: setFilterCompletedReg },
              { label: 'Payroll Eligible Only',          value: filterPayrollEligible,  setter: setFilterPayrollEligible },
            ] as const).map(f => (
              <label key={f.label} className="flex items-center gap-2 cursor-pointer select-none"
                style={{ fontFamily: "'Exo 2', sans-serif", fontSize: 13, color: '#1E3A5F' }}>
                <button
                  onClick={() => (f.setter as (v: boolean) => void)(!f.value)}
                  style={{ border: 'none', background: 'none', padding: 0, cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                  {f.value
                    ? <CheckSquare size={16} style={{ color: '#1565C0' }} />
                    : <Square size={16} style={{ color: '#B0BECE' }} />}
                </button>
                {f.label}
              </label>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="rounded-2xl p-4 mb-4" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          <div className="flex items-center gap-2 mb-3">
            <Search size={14} style={{ color: '#1565C0' }} />
            <span className="font-bold text-sm" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>Search</span>
          </div>
          {/* Search input */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl mb-3"
            style={{ background: 'rgba(21,101,192,0.05)', border: '1px solid rgba(21,101,192,0.18)' }}>
            <Search size={13} style={{ color: '#7A90A8', flexShrink: 0 }} />
            <input
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={`Search by ${searchTab === 'code' ? 'Trainee Code' : searchTab === 'aadhaar' ? 'Aadhaar' : searchTab === 'mobile' ? 'Mobile' : 'Name'}…`}
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: '#0D2B5E', fontFamily: "'Exo 2', sans-serif" }}
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} style={{ background: 'none', border: 'none', cursor: 'pointer' }}>
                <X size={12} style={{ color: '#7A90A8' }} />
              </button>
            )}
          </div>
          {/* Search tabs */}
          <div className="flex gap-2 flex-wrap">
            {(['code', 'aadhaar', 'mobile', 'name'] as const).map(tab => {
              const label = tab === 'code' ? 'Trainee Code' : tab === 'aadhaar' ? 'Aadhaar' : tab === 'mobile' ? 'Mobile' : 'Name'
              const active = searchTab === tab
              return (
                <button
                  key={tab}
                  onClick={() => { setSearchTab(tab); setSearchQuery('') }}
                  className="px-4 py-1.5 rounded-lg text-xs font-semibold transition-all"
                  style={{ background: active ? 'rgba(21,101,192,0.12)' : 'rgba(21,101,192,0.04)', color: active ? '#1565C0' : '#4A6080', border: active ? '1px solid rgba(21,101,192,0.28)' : '1px solid transparent', fontFamily: "'Exo 2', sans-serif", cursor: 'pointer' }}>
                  {label}
                </button>
              )
            })}
          </div>
        </div>

        {/* Trainee table */}
        <div className="rounded-2xl overflow-hidden mb-4" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          <div className="px-5 py-3 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(21,101,192,0.08)' }}>
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>Payroll Eligible Trainees</h3>
              {batchGenerated && (
                <span className="text-xs px-2 py-0.5 rounded-full font-bold"
                  style={{ background: 'rgba(22,163,74,0.12)', color: '#15803D', fontFamily: "'Exo 2', sans-serif" }}>
                  Batch Generated
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              {selectedIds.size > 0 && (
                <span className="text-xs font-semibold" style={{ color: '#1565C0', fontFamily: "'Exo 2', sans-serif" }}>
                  {selectedIds.size} selected
                </span>
              )}
              <span className="text-xs px-3 py-1 rounded-full" style={{ background: 'rgba(21,101,192,0.08)', color: '#1565C0', fontFamily: "'Exo 2', sans-serif" }}>
                {allocTrainees.length} trainees
              </span>
            </div>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 720 }}>
              <thead>
                <tr style={{ background: 'rgba(21,101,192,0.05)', borderBottom: '1px solid rgba(21,101,192,0.10)' }}>
                  <th style={{ padding: '11px 14px', width: 40 }}>
                    <button onClick={toggleAllAlloc} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                      {allAllocSelected
                        ? <CheckSquare size={15} style={{ color: '#1565C0' }} />
                        : <Square size={15} style={{ color: '#B0BECE' }} />}
                    </button>
                  </th>
                  {['Trainee Code', 'Name', 'Company', 'Scheme', 'Payroll Status', 'Registration Status', 'Action'].map(h => (
                    <th key={h} style={{ padding: '11px 14px', textAlign: 'left', fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#4A6080', fontFamily: "'Exo 2', sans-serif", whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allocTrainees.length === 0 ? (
                  <tr>
                    <td colSpan={8} style={{ padding: '40px 20px', textAlign: 'center' }}>
                      <div style={{ color: '#B0BECE', fontFamily: "'Exo 2', sans-serif", fontSize: 13 }}>No trainees match the current filters</div>
                    </td>
                  </tr>
                ) : allocTrainees.map(t => {
                  const isChecked = selectedIds.has(t.id)
                  const isCompleted = t.regStatus === 'Completed'
                  return (
                    <tr key={t.id}
                      style={{ borderBottom: '1px solid rgba(21,101,192,0.06)', transition: 'background 0.12s', background: isChecked ? 'rgba(21,101,192,0.04)' : 'transparent' }}
                      onMouseEnter={e => { if (!isChecked) (e.currentTarget as HTMLElement).style.background = 'rgba(21,101,192,0.025)' }}
                      onMouseLeave={e => { if (!isChecked) (e.currentTarget as HTMLElement).style.background = 'transparent' }}>
                      <td style={{ padding: '10px 14px' }}>
                        <button onClick={() => toggleAllocId(t.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                          {isChecked
                            ? <CheckSquare size={15} style={{ color: '#1565C0' }} />
                            : <Square size={15} style={{ color: '#B0BECE' }} />}
                        </button>
                      </td>
                      <td style={{ padding: '10px 14px', fontSize: 11, color: '#1565C0', fontFamily: 'JetBrains Mono,monospace', fontWeight: 700, whiteSpace: 'nowrap' }}>{t.code}</td>
                      <td style={{ padding: '10px 14px', fontSize: 12, color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", fontWeight: 600, whiteSpace: 'nowrap' }}>{t.name}</td>
                      <td style={{ padding: '10px 14px', fontSize: 11, color: '#4A6080', fontFamily: "'Exo 2',sans-serif", maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.company}</td>
                      <td style={{ padding: '10px 14px' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: 'rgba(21,101,192,0.08)', color: '#1565C0', fontFamily: "'Exo 2',sans-serif" }}>{t.scheme}</span>
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <span style={{ padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: t.payroll ? 'rgba(22,163,74,0.12)' : 'rgba(229,57,53,0.10)', color: t.payroll ? '#15803D' : '#B91C1C', fontFamily: "'Exo 2',sans-serif" }}>
                          {t.payroll ? 'Eligible' : 'Not Eligible'}
                        </span>
                      </td>
                      <td style={{ padding: '10px 14px' }}>
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold"
                          style={{ background: isCompleted ? 'rgba(22,163,74,0.12)' : 'rgba(202,138,4,0.12)', color: isCompleted ? '#15803D' : '#A16207', fontFamily: "'Exo 2',sans-serif" }}>
                          {isCompleted ? <><Check size={9} /> Completed</> : <><Clock size={9} /> Pending</>}
                        </span>
                      </td>
                      <td style={{ padding: '9px 14px' }}>
                        {isCompleted ? (
                          <button
                            onClick={() => setPanel({ mode: 'quick-allocate' })}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold text-white"
                            style={{ background: 'linear-gradient(135deg,#1565C0,#1976D2)', boxShadow: '0 3px 8px rgba(21,101,192,0.26)', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', whiteSpace: 'nowrap' }}>
                            <Layers size={10} /> Assign Batch
                          </button>
                        ) : (
                          <button
                            onClick={() => setPanel({ mode: 'pending-reg' })}
                            className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold"
                            style={{ background: 'rgba(249,115,22,0.12)', border: '1px solid rgba(249,115,22,0.28)', color: '#C2470A', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', whiteSpace: 'nowrap' }}>
                            <ListChecks size={10} /> Complete Reg.
                          </button>
                        )}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Assign selected trainees button */}
        <div className="flex justify-center pt-1 pb-2">
          <button
            disabled={selectedIds.size === 0}
            onClick={() => { setPanel({ mode: 'quick-allocate' }); setSelectedIds(new Set()) }}
            className="flex items-center gap-2 px-8 py-3 rounded-xl text-sm font-bold transition-all"
            style={{
              background: selectedIds.size > 0 ? 'linear-gradient(135deg,#1565C0,#7c3aed)' : 'rgba(21,101,192,0.07)',
              color: selectedIds.size > 0 ? '#fff' : '#B0BECE',
              boxShadow: selectedIds.size > 0 ? '0 4px 18px rgba(21,101,192,0.30)' : 'none',
              border: selectedIds.size > 0 ? 'none' : '1px solid rgba(21,101,192,0.14)',
              fontFamily: "'Exo 2', sans-serif",
              cursor: selectedIds.size > 0 ? 'pointer' : 'not-allowed',
            }}>
            <UserPlus size={14} />
            {selectedIds.size > 0 ? `Assign Selected Trainees (${selectedIds.size})` : 'Assign Selected Trainees'}
          </button>
        </div>
      </div>

    </div>
  )
}


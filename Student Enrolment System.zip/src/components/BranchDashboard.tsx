import { useState, useMemo } from 'react'
import { User, Plus, AlertTriangle, Layers, CheckCircle, X, Search, Megaphone, TrendingUp, TrendingDown, Activity, ChevronRight } from 'lucide-react'
import { TRAINEES, TODAY } from '@/data/trainees'
import type { Trainee } from '@/data/trainees'

interface BranchDashboardProps {
  onNavigate: (screen: string) => void
}

const RECENT = [
  { code: 'TRN000173', name: 'Manoj Tiwari',  mobile: '9801234578', scheme: 'NEEM',  course: 'Fitter General',           status: 'Approved', date: '10 Aug 2026' },
  { code: 'TRN000172', name: 'Sunita Desai',  mobile: '9890123467', scheme: 'FLEXI', course: 'Electrician General',       status: 'Pending',  date: '09 Aug 2026' },
  { code: 'TRN000171', name: 'Anil Chaudhari',mobile: '9889012356', scheme: 'MSBTE', course: 'Mechanic Diesel',           status: 'Pending',  date: '07 Aug 2026' },
  { code: 'TRN000170', name: 'Rekha Iyer',    mobile: '9878901245', scheme: 'DVOC',  course: 'AC & Refrigeration Tech.',  status: 'Approved', date: '05 Aug 2026' },
  { code: 'TRN000169', name: 'Suresh Babu',   mobile: '9867890134', scheme: 'WILP',  course: 'Welder (SMAW)',             status: 'Approved', date: '03 Aug 2026' },
]

const STATUS_STYLE: Record<string, { bg: string; color: string; dot: string }> = {
  'Approved': { bg: 'rgba(22,163,74,0.12)',  color: '#15803D', dot: '#16a34a' },
  'Pending':  { bg: 'rgba(202,138,4,0.12)',  color: '#A16207', dot: '#CA8A04' },
  'Rejected': { bg: 'rgba(229,57,53,0.12)', color: '#B91C1C', dot: '#E53935' },
}

const QUICK_ACTIONS = [
  { Icon: Plus,        label: 'Register New Trainee', desc: 'Start 5-step enrollment wizard', action: 'register',     color: '#1565C0' },
  { Icon: CheckCircle, label: 'Verify Documents',     desc: 'Review pending verifications',   action: 'verification', color: '#F97316' },
]

/* ── KPI Panel ─────────────────────────────────────────────────────── */
function KpiPanel({ rows, title, subtitle, accentColor, onClose }: {
  rows: Trainee[]
  title: string
  subtitle: string
  accentColor: string
  onClose: () => void
}) {
  const [search, setSearch] = useState('')
  const visible = rows.filter(t =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.code.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <>
      <div className="fixed inset-0 z-40" style={{ background: 'rgba(13,43,94,0.30)', backdropFilter: 'blur(4px)' }} onClick={onClose} />
      <div className="fixed right-0 top-0 h-full z-50 flex flex-col"
        style={{ width: 520, background: 'rgba(255,255,255,0.94)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderLeft: '1px solid rgba(255,255,255,0.80)', boxShadow: '-8px 0 48px rgba(21,101,192,0.16)' }}>

        {/* Header */}
        <div className="flex-shrink-0 px-5 py-4 flex items-center justify-between"
          style={{ background: accentColor, borderBottom: '1px solid rgba(255,255,255,0.20)' }}>
          <div>
            <div className="font-black text-lg text-white" style={{ fontFamily: 'Rajdhani,sans-serif' }}>{title}</div>
            <div className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.82)', fontFamily: "'Exo 2',sans-serif" }}>{subtitle}</div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{ background: 'rgba(255,255,255,0.20)', color: '#fff', border: '1px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}>
            <X size={15} />
          </button>
        </div>

        {/* Search */}
        <div className="flex-shrink-0 px-5 py-3" style={{ borderBottom: '1px solid rgba(21,101,192,0.08)' }}>
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
            style={{ background: 'rgba(21,101,192,0.06)', border: '1px solid rgba(21,101,192,0.14)' }}>
            <Search size={13} style={{ color: '#7A90A8' }} />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search by name or code…"
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }} />
            {search && <button onClick={() => setSearch('')}><X size={11} style={{ color: '#7A90A8', cursor: 'pointer' }} /></button>}
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-y-auto">
          {visible.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Search size={28} style={{ color: '#B0BECE', marginBottom: 10 }} />
              <div className="text-sm font-semibold" style={{ color: '#4A6080', fontFamily: 'Rajdhani,sans-serif' }}>No matching records</div>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0">
                <tr style={{ background: 'rgba(21,101,192,0.05)' }}>
                  {['#', 'Code', 'Trainee', 'Scheme', 'Batch', 'Status'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider"
                      style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif", borderBottom: '1px solid rgba(21,101,192,0.10)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {visible.map((t, i) => {
                  const sc = STATUS_STYLE[t.status] ?? STATUS_STYLE['Pending']
                  return (
                    <tr key={t.id} className="border-t"
                      style={{ borderColor: 'rgba(21,101,192,0.07)' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(21,101,192,0.03)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td className="px-4 py-3 text-xs font-mono" style={{ color: '#7A90A8' }}>{String(i + 1).padStart(2, '0')}</td>
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg"
                          style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0' }}>{t.code}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-semibold text-sm" style={{ color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }}>{t.name}</div>
                        <div className="text-xs" style={{ color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{t.course}</div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-xs font-bold px-2 py-1 rounded-lg"
                          style={{ background: 'rgba(124,58,237,0.10)', color: '#7c3aed', fontFamily: "'Exo 2',sans-serif" }}>{t.scheme}</span>
                      </td>
                      <td className="px-4 py-3 text-xs font-mono" style={{ color: '#4A6080' }}>{t.batch}</td>
                      <td className="px-4 py-3">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap"
                          style={{ background: sc.bg, color: sc.color, fontFamily: "'Exo 2',sans-serif" }}>
                          <span className="w-1.5 h-1.5 rounded-full" style={{ background: sc.dot }} />{t.status}
                        </span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        <div className="flex-shrink-0 px-5 py-3 flex items-center justify-between"
          style={{ borderTop: '1px solid rgba(21,101,192,0.10)', background: 'rgba(21,101,192,0.03)' }}>
          <span className="text-xs font-semibold" style={{ color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>
            {visible.length} record{visible.length !== 1 ? 's' : ''}
          </span>
          <button onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold"
            style={{ background: 'rgba(21,101,192,0.09)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            Close
          </button>
        </div>
      </div>
    </>
  )
}

/* ── Main Component ────────────────────────────────────────────────── */
type PanelKey = 0 | 1 | 2 | 3 | 4 | 5

export default function BranchDashboard({ onNavigate }: BranchDashboardProps) {
  const [hoveredKpi, setHoveredKpi] = useState<number | null>(null)
  const [openPanel,  setOpenPanel]  = useState<PanelKey | null>(null)

  const kpi = useMemo(() => {
    const total      = TRAINEES.length
    const todayReg   = TRAINEES.filter(t => t.enrolled === TODAY).length
    const prevDayReg = TRAINEES.filter(t => t.enrolled === '2026-08-09').length
    const pending    = TRAINEES.filter(t => t.status === 'Pending').length
    const docUrgent  = TRAINEES.filter(t => t.status === 'Pending' && t.docs.filter(d => d.done).length === 0).length
    const batchPend  = TRAINEES.filter(t => t.batch === '—').length
    const completed  = TRAINEES.filter(t => t.status === 'Approved').length
    const rejected   = TRAINEES.filter(t => t.status === 'Rejected').length
    const rejPct     = total ? ((rejected / total) * 100).toFixed(1) : '0'
    const compPct    = total ? ((completed / total) * 100).toFixed(1) : '0'
    const todayDelta = todayReg - prevDayReg

    return [
      { label: 'Total Trainees',           value: total.toLocaleString(),  delta: `${todayReg} enrolled today`,   up: true,  color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)', Icon: User,          accent: 'linear-gradient(120deg,#1565C0,#1976D2 60%,#F97316)', rows: TRAINEES },
      { label: "Today's Registrations",    value: String(todayReg),        delta: todayDelta >= 0 ? `+${todayDelta} vs yesterday` : `${todayDelta} vs yesterday`, up: todayDelta >= 0, color: '#16a34a', bg: 'rgba(22,163,74,0.10)', Icon: Plus, accent: 'linear-gradient(120deg,#15803D,#16a34a)', rows: TRAINEES.filter(t => t.enrolled === TODAY) },
      { label: 'Pending Verification',     value: String(pending),         delta: `${docUrgent} docs missing`,    up: false, color: 'var(--ysf-orange)', bg: 'rgba(249,115,22,0.10)', Icon: AlertTriangle, accent: 'linear-gradient(120deg,#C2470A,#F97316)', rows: TRAINEES.filter(t => t.status === 'Pending') },
      { label: 'Batch Allocation Pending', value: String(batchPend),       delta: `${total - batchPend} allocated`, up: false, color: '#7c3aed',          bg: 'rgba(124,58,237,0.10)', Icon: Layers,        accent: 'linear-gradient(120deg,#5b21b6,#7c3aed)', rows: TRAINEES.filter(t => t.batch === '—') },
      { label: 'Completed Enrollment',     value: String(completed),       delta: `${compPct}% completion rate`,  up: true,  color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)', Icon: CheckCircle,   accent: 'linear-gradient(120deg,#1565C0,#1976D2)', rows: TRAINEES.filter(t => t.status === 'Approved') },
      { label: 'Rejected Applications',    value: String(rejected),        delta: `${rejPct}% of total`,          up: false, color: 'var(--ysf-red)',    bg: 'var(--ysf-red-light)',  Icon: X,             accent: 'linear-gradient(120deg,#B91C1C,#E53935)', rows: TRAINEES.filter(t => t.status === 'Rejected') },
    ]
  }, [])

  const panel = openPanel !== null ? kpi[openPanel] : null

  return (
    <div className="space-y-5">

      {/* KPI Panel slide-over */}
      {panel && (
        <KpiPanel
          rows={panel.rows}
          title={panel.label}
          subtitle={`${panel.rows.length} trainee${panel.rows.length !== 1 ? 's' : ''} · ${panel.delta}`}
          accentColor={panel.accent}
          onClose={() => setOpenPanel(null)}
        />
      )}

      {/* Welcome Banner */}
      <div className="rounded-2xl p-5 md:p-6 overflow-hidden relative"
        style={{ background: 'linear-gradient(120deg,#1565C0 0%,#1976D2 55%,#F97316 100%)', boxShadow: '0 0 60px rgba(21,101,192,0.25),0 0 120px rgba(249,115,22,0.12),0 8px 32px rgba(21,101,192,0.20)', border: '1px solid rgba(255,255,255,0.20)' }}>
        <div className="absolute right-0 top-0 w-64 h-64 rounded-full opacity-10 hidden sm:block" style={{ background: 'white', transform: 'translate(30%,-40%)' }} />
        <div className="absolute right-32 bottom-0 w-40 h-40 rounded-full opacity-10 hidden sm:block" style={{ background: 'white', transform: 'translateY(50%)' }} />
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs font-medium mb-1" style={{ color: 'rgba(255,255,255,0.80)', fontFamily: "'Exo 2',sans-serif" }}>Branch Center · Hyderabad</p>
            <h1 className="text-xl md:text-2xl font-bold text-white mb-1" style={{ fontFamily: 'Rajdhani,sans-serif' }}>Good Morning, Priya 👋</h1>
            <p className="text-sm hidden sm:block" style={{ color: 'rgba(255,255,255,0.75)', fontFamily: "'Exo 2',sans-serif" }}>Here's what's happening at Hyderabad Center today.</p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
            <div className="text-xs px-3 py-1.5 rounded-lg font-medium hidden md:block"
              style={{ background: 'rgba(255,255,255,0.18)', color: '#fff', border: '1px solid rgba(255,255,255,0.25)', fontFamily: "'Exo 2',sans-serif" }}>
              {TODAY}
            </div>
            <button onClick={() => onNavigate('register')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm"
              style={{ background: 'white', color: 'var(--ysf-blue)', boxShadow: '0 4px 12px rgba(0,0,0,0.15)', fontFamily: 'Rajdhani,sans-serif' }}>
              <Plus size={14} /> New Trainee
            </button>
          </div>
        </div>
      </div>

      {/* Live status strip */}
      <div className="flex items-center gap-0 rounded-xl overflow-x-auto text-xs scrollbar-hide"
        style={{ background: 'rgba(255,255,255,0.62)', backdropFilter: 'blur(16px)', border: '1px solid rgba(255,255,255,0.72)', boxShadow: 'var(--card-shadow)' }}>
        <div className="flex items-center gap-2 px-4 py-2.5 font-bold flex-shrink-0"
          style={{ background: 'var(--ysf-blue)', color: '#fff', fontFamily: "'Exo 2',sans-serif" }}>
          <Activity size={12} /> Center Live
        </div>
        {[
          `${kpi[2].value} verifications pending`,
          `${kpi[1].value} registered today`,
          `${kpi[3].value} awaiting batch`,
          `${kpi[4].value} completed enrollment`,
          `${kpi[5].value} rejected`,
        ].map((s, i) => (
          <span key={i} className="px-4 py-2.5 flex-shrink-0"
            style={{ color: 'var(--muted-foreground)', borderLeft: '1px solid var(--border)', fontFamily: "'Exo 2',sans-serif" }}>
            {s}
          </span>
        ))}
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {kpi.map((k, i) => (
          <button
            key={k.label}
            onClick={() => setOpenPanel(i as PanelKey)}
            onMouseEnter={() => setHoveredKpi(i)}
            onMouseLeave={() => setHoveredKpi(null)}
            className="rounded-xl p-4 text-left transition-all duration-200 w-full"
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border)',
              borderTop: `3px solid ${k.color}`,
              boxShadow: hoveredKpi === i ? 'var(--card-shadow-md)' : 'var(--card-shadow)',
              transform: hoveredKpi === i ? 'translateY(-2px)' : 'none',
              cursor: 'pointer',
            }}
          >
            <div className="flex items-start justify-between mb-3">
              <p className="text-xs leading-snug pr-2" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>{k.label}</p>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: k.bg, color: k.color }}>
                <k.Icon size={16} />
              </div>
            </div>
            <div className="text-2xl font-bold mb-1.5" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani,sans-serif' }}>{k.value}</div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1 text-xs font-semibold" style={{ color: k.up ? '#16a34a' : '#E53935', fontFamily: "'Exo 2',sans-serif" }}>
                {k.up ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                {k.delta}
              </div>
              <ChevronRight size={12} style={{ color: '#B0BECE' }} />
            </div>
          </button>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>Quick Actions</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {QUICK_ACTIONS.map(a => (
            <button key={a.action} onClick={() => onNavigate(a.action)}
              className="rounded-xl p-4 text-left transition-all duration-200"
              style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)', cursor: 'pointer' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = a.color + '40'; e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.boxShadow = `0 4px 16px ${a.color}18` }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'none'; e.currentTarget.style.boxShadow = 'var(--card-shadow)' }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ background: a.color + '12', color: a.color }}>
                <a.Icon size={18} />
              </div>
              <div className="font-bold text-sm mb-0.5" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani,sans-serif' }}>{a.label}</div>
              <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>{a.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Registrations Table */}
      <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)' }}>
        <div className="px-5 py-4 flex items-center justify-between" style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-blue)' }}>
          <div>
            <h2 className="font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani,sans-serif' }}>Recent Registrations</h2>
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>Latest 5 enrollments at this center</p>
          </div>
          <button className="text-xs font-semibold px-4 py-1.5 rounded-lg"
            style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)', border: '1px solid rgba(21,101,192,0.20)', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer' }}
            onClick={() => onNavigate('recent-registrations')}>
            View All
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: 'var(--muted)' }}>
                {['#', 'Trainee Code', 'Name', 'Mobile', 'Scheme', 'Course', 'Status', 'Date'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {RECENT.map((r, idx) => {
                const s = STATUS_STYLE[r.status] ?? STATUS_STYLE['Pending']
                return (
                  <tr key={r.code} className="border-t transition-colors"
                    style={{ borderColor: 'var(--border)' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--muted)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                    <td className="px-4 py-3 text-xs font-mono" style={{ color: 'var(--muted-foreground)' }}>{String(idx + 1).padStart(2, '0')}</td>
                    <td className="px-4 py-3">
                      <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)' }}>{r.code}</span>
                    </td>
                    <td className="px-4 py-3 font-semibold text-sm" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2',sans-serif" }}>{r.name}</td>
                    <td className="px-4 py-3 font-mono text-xs" style={{ color: 'var(--muted-foreground)' }}>{r.mobile}</td>
                    <td className="px-4 py-3 text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>{r.scheme}</td>
                    <td className="px-4 py-3 text-xs" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2',sans-serif" }}>{r.course}</td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: s.bg, color: s.color, fontFamily: "'Exo 2',sans-serif" }}>
                        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: s.dot }} />{r.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2',sans-serif" }}>{r.date}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Notice Banner */}
      <div className="rounded-xl p-4 flex gap-3" style={{ background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.18)' }}>
        <span className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: 'rgba(21,101,192,0.12)', color: 'var(--ysf-blue)' }}>
          <Megaphone size={15} />
        </span>
        <div>
          <div className="font-bold text-sm mb-1.5" style={{ color: 'var(--ysf-blue)', fontFamily: 'Rajdhani,sans-serif' }}>Important Notices</div>
          <ul className="space-y-1 text-xs" style={{ color: '#1e3a5f', fontFamily: "'Exo 2',sans-serif" }}>
            <li className="flex items-start gap-2"><span style={{ color: 'var(--ysf-orange)' }}>•</span> WILP / BVOC enrollment deadline: 31 August 2026. Complete all pending verifications.</li>
            <li className="flex items-start gap-2"><span style={{ color: 'var(--ysf-orange)' }}>•</span> New batch (HYD-ELEC-2026-B3) starts 15 August 2026. Assign pending trainees before 13 Aug.</li>
            <li className="flex items-start gap-2"><span style={{ color: 'var(--ysf-orange)' }}>•</span> Aadhaar-based biometric attendance mandatory from September 2026 onwards.</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'
import { Download, TrendingUp, TrendingDown, Users, Award, MapPin, BarChart3, Activity } from 'lucide-react'
import {
  LineChart, Line, BarChart, Bar, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts'

/* ── Data ──────────────────────────────────────────────────────────── */
const MONTHLY_TREND = [
  { month: 'Jan', registrations: 7200,  completions: 5100,  placements: 4200,  rejections: 310 },
  { month: 'Feb', registrations: 8200,  completions: 6100,  placements: 5400,  rejections: 280 },
  { month: 'Mar', registrations: 9100,  completions: 7200,  placements: 6100,  rejections: 320 },
  { month: 'Apr', registrations: 10400, completions: 8300,  placements: 7200,  rejections: 290 },
  { month: 'May', registrations: 11200, completions: 9100,  placements: 8000,  rejections: 340 },
  { month: 'Jun', registrations: 12100, completions: 10200, placements: 8900,  rejections: 310 },
  { month: 'Jul', registrations: 13400, completions: 11100, placements: 9800,  rejections: 360 },
  { month: 'Aug', registrations: 14200, completions: 12000, placements: 10500, rejections: 330 },
]

const BRANCH_PERF = [
  { branch: 'Hyderabad', enrolled: 18240, completed: 15200, placed: 12800, rate: 70.2 },
  { branch: 'Mumbai',    enrolled: 16800, completed: 14100, placed: 11900, rate: 70.8 },
  { branch: 'Delhi',     enrolled: 15400, completed: 12900, placed: 10200, rate: 66.2 },
  { branch: 'Chennai',   enrolled: 14200, completed: 11800, placed: 9600,  rate: 67.6 },
  { branch: 'Bengaluru', enrolled: 13900, completed: 11500, placed: 9100,  rate: 65.5 },
  { branch: 'Kolkata',   enrolled: 12100, completed: 10200, placed: 7800,  rate: 64.5 },
]

const SCHEME_DIST = [
  { name: 'WILP',  value: 52000, color: '#1565C0' },
  { name: 'BVOC',  value: 28000, color: '#F97316' },
  { name: 'DVOC',  value: 22000, color: '#16a34a' },
  { name: 'FLEXI', value: 14000, color: '#7c3aed' },
  { name: 'MSBTE', value: 8530,  color: '#0891b2' },
]

const GENDER_DIST = [
  { name: 'Male',   value: 68420, color: '#1565C0' },
  { name: 'Female', value: 54320, color: '#F97316' },
  { name: 'Other',  value: 1790,  color: '#9CA3AF' },
]

const COURSE_TOP = [
  { course: 'Electrician',           enrolled: 12400, placed: 9800, rate: 79.0, sector: 'Power' },
  { course: 'Data Entry Operator',   enrolled: 10200, placed: 7100, rate: 69.6, sector: 'IT' },
  { course: 'Retail Sales Associate',enrolled: 9800,  placed: 7400, rate: 75.5, sector: 'Retail' },
  { course: 'Beauty Therapist',      enrolled: 8900,  placed: 6200, rate: 69.7, sector: 'Wellness' },
  { course: 'Solar PV Technician',   enrolled: 8200,  placed: 7000, rate: 85.4, sector: 'Green' },
  { course: 'Welder (FCAW)',         enrolled: 7800,  placed: 6100, rate: 78.2, sector: 'Mfg.' },
  { course: 'CNC Operator',          enrolled: 6400,  placed: 5200, rate: 81.3, sector: 'Mfg.' },
  { course: 'Plumber',               enrolled: 5900,  placed: 4200, rate: 71.2, sector: 'Infra' },
]

const STATE_DATA = [
  { state: 'Telangana',    trainees: 22400, rate: 71.2, color: '#1565C0' },
  { state: 'Maharashtra',  trainees: 20100, rate: 70.8, color: '#2563EB' },
  { state: 'Delhi',        trainees: 17800, rate: 66.2, color: '#0891b2' },
  { state: 'Tamil Nadu',   trainees: 16400, rate: 67.6, color: '#16a34a' },
  { state: 'Karnataka',    trainees: 15600, rate: 65.5, color: '#F97316' },
  { state: 'West Bengal',  trainees: 14200, rate: 64.5, color: '#7c3aed' },
]

const QUARTERLY = [
  { q: 'Q1 FY24', target: 28000, achieved: 24500 },
  { q: 'Q2 FY24', target: 32000, achieved: 31200 },
  { q: 'Q3 FY24', target: 36000, achieved: 38100 },
  { q: 'Q4 FY24', target: 40000, achieved: 30700 },
]

function Panel({ title, subtitle, accentColor = 'var(--ysf-blue)', children }: {
  title: string; subtitle?: string; accentColor?: string; children: React.ReactNode
}) {
  return (
    <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)' }}>
      <div className="px-5 py-4" style={{ borderBottom: '1px solid var(--border)', borderTop: `3px solid ${accentColor}` }}>
        <h3 className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{title}</h3>
        {subtitle && <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{subtitle}</p>}
      </div>
      <div className="p-5">{children}</div>
    </div>
  )
}

const PERIODS = ['Monthly', 'Quarterly', 'Yearly']

export default function MgmtAnalytics() {
  const [period, setPeriod] = useState('Monthly')

  const KPI = [
    { label: 'Total Enrolled',       value: '1,24,530', delta: '+2,340',   up: true,  color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)',       Icon: Users },
    { label: 'Placement Rate',       value: '57.9%',    delta: '+2.1%',    up: true,  color: '#16a34a',           bg: 'rgba(22,163,74,0.10)',        Icon: Award },
    { label: 'Active Batches',       value: '847',      delta: '+34',      up: true,  color: 'var(--ysf-orange)', bg: 'rgba(249,115,22,0.10)',       Icon: BarChart3 },
    { label: 'Avg. Completion Days', value: '62',       delta: '-4 days',  up: true,  color: '#0891b2',           bg: 'rgba(8,145,178,0.10)',        Icon: Activity },
    { label: 'Rejection Rate',       value: '3.9%',     delta: '-0.4%',    up: true,  color: '#16a34a',           bg: 'rgba(22,163,74,0.10)',        Icon: TrendingDown },
    { label: 'Centers Active',       value: '847',      delta: '+12',      up: true,  color: '#7c3aed',           bg: 'rgba(124,58,237,0.10)',       Icon: MapPin },
  ]

  return (
    <div className="space-y-5">

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start gap-3 sm:justify-between">
        <div>
          <h1 className="text-xl font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
            Analytics & Reports
          </h1>
          <p className="text-sm mt-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
            Pan-India performance data across 847 training centers · FY 2023–24
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Period selector */}
          <div className="flex items-center rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', background: 'var(--card)' }}>
            {PERIODS.map(p => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className="px-4 py-2 text-xs font-semibold transition-all"
                style={{
                  background: period === p ? 'var(--ysf-blue)' : 'transparent',
                  color: period === p ? '#fff' : 'var(--muted-foreground)',
                  border: 'none',
                  cursor: 'pointer',
                  fontFamily: "'Exo 2', sans-serif",
                }}
              >
                {p}
              </button>
            ))}
          </div>
          <button
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold"
            style={{ background: 'var(--card)', border: '1px solid var(--border)', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}
          >
            <Download size={14} /> Export PDF
          </button>
        </div>
      </div>

      {/* KPI grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        {KPI.map(k => (
          <div
            key={k.label}
            className="rounded-xl p-4 transition-all duration-200"
            style={{ background: 'var(--card)', border: '1px solid var(--border)', borderTop: `3px solid ${k.color}`, boxShadow: 'var(--card-shadow)' }}
          >
            <div className="flex items-start justify-between mb-2">
              <p className="text-xs leading-snug pr-1" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{k.label}</p>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: k.bg, color: k.color }}>
                <k.Icon size={14} />
              </div>
            </div>
            <div className="text-2xl font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{k.value}</div>
            <div className="flex items-center gap-1 text-xs font-semibold" style={{ color: k.up ? '#16a34a' : '#E53935', fontFamily: "'Exo 2', sans-serif" }}>
              {k.up ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
              {k.delta} this month
            </div>
          </div>
        ))}
      </div>

      {/* Trend + Target attainment */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2">
          <Panel title="Registration, Completion & Placement Trend" subtitle={`${period} view · FY 2023-24`} accentColor="var(--ysf-blue)">
            <div className="flex items-center gap-5 mb-4 text-xs" style={{ fontFamily: "'Exo 2', sans-serif", color: 'var(--muted-foreground)' }}>
              {[
                { label: 'Registrations', color: '#1565C0' },
                { label: 'Completions',   color: '#16a34a' },
                { label: 'Placements',    color: '#F97316' },
                { label: 'Rejections',    color: '#E53935' },
              ].map(l => (
                <span key={l.label} className="flex items-center gap-1.5">
                  <span className="w-3 h-1.5 rounded-full inline-block" style={{ background: l.color }} />
                  {l.label}
                </span>
              ))}
            </div>
            <div style={{ position: 'relative', width: '100%', height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={MONTHLY_TREND}>
                  <defs>
                    <linearGradient id="regGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#1565C0" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="#1565C0" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="placeGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%"  stopColor="#F97316" stopOpacity={0.12} />
                      <stop offset="95%" stopColor="#F97316" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(21,101,192,0.07)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: '1px solid rgba(21,101,192,0.12)', background: 'rgba(255,255,255,0.97)', boxShadow: '0 8px 24px rgba(0,0,0,0.08)' }} />
                  <Area type="monotone" dataKey="registrations" stroke="#1565C0" strokeWidth={2.5} fill="url(#regGrad)"   name="Registrations" dot={false} />
                  <Line  type="monotone" dataKey="completions"   stroke="#16a34a" strokeWidth={2}   dot={false} name="Completions" />
                  <Area type="monotone" dataKey="placements"    stroke="#F97316" strokeWidth={2.5} fill="url(#placeGrad)" name="Placements"    dot={false} />
                  <Line  type="monotone" dataKey="rejections"    stroke="#E53935" strokeWidth={1.5} dot={false} name="Rejections"   strokeDasharray="4 3" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Panel>
        </div>

        <Panel title="Quarterly Target vs. Achieved" subtitle="FY 2023-24" accentColor="var(--ysf-orange)">
          <div style={{ position: 'relative', width: '100%', height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={QUARTERLY} barGap={4}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(21,101,192,0.07)" vertical={false} />
                <XAxis dataKey="q" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: '1px solid rgba(21,101,192,0.12)', background: 'rgba(255,255,255,0.97)' }} />
                <Bar dataKey="target"   fill="rgba(21,101,192,0.15)" radius={[6,6,0,0]} name="Target" />
                <Bar dataKey="achieved" fill="#1565C0"               radius={[6,6,0,0]} name="Achieved" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 space-y-2">
            {QUARTERLY.map(q => (
              <div key={q.q} className="flex items-center gap-2">
                <span className="text-xs w-12 font-semibold" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{q.q}</span>
                <div className="flex-1 h-1.5 rounded-full" style={{ background: 'var(--border)' }}>
                  <div
                    className="h-1.5 rounded-full"
                    style={{ width: `${Math.min((q.achieved / q.target) * 100, 100)}%`, background: q.achieved >= q.target ? '#16a34a' : 'var(--ysf-blue)' }}
                  />
                </div>
                <span className="text-xs font-bold w-10 text-right" style={{ color: q.achieved >= q.target ? '#16a34a' : 'var(--ysf-blue)', fontFamily: 'Rajdhani, sans-serif' }}>
                  {Math.round((q.achieved / q.target) * 100)}%
                </span>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      {/* Branch performance + Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        <Panel title="Branch-wise Performance" subtitle="Enrollment, completion & placement" accentColor="var(--ysf-blue)">
          <div style={{ position: 'relative', width: '100%', height: 230 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={BRANCH_PERF} layout="vertical" barSize={10} barGap={2}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(21,101,192,0.07)" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis dataKey="branch" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={72} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: '1px solid rgba(21,101,192,0.12)', background: 'rgba(255,255,255,0.97)' }} />
                <Bar dataKey="enrolled"  fill="rgba(21,101,192,0.25)" radius={[0,4,4,0]} name="Enrolled"  stackId="a" />
                <Bar dataKey="completed" fill="#1565C0"               radius={[0,0,0,0]} name="Completed" stackId="b" />
                <Bar dataKey="placed"    fill="#F97316"               radius={[0,4,4,0]} name="Placed"    stackId="b" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Placement rate table */}
          <div className="mt-3 space-y-1.5">
            {BRANCH_PERF.map(b => (
              <div key={b.branch} className="flex items-center gap-2">
                <span className="text-xs w-20 font-medium" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{b.branch}</span>
                <div className="flex-1 h-2 rounded-full" style={{ background: 'var(--border)' }}>
                  <div className="h-2 rounded-full" style={{ width: `${b.rate}%`, background: b.rate >= 70 ? '#16a34a' : 'var(--ysf-blue)' }} />
                </div>
                <span className="text-xs font-bold w-10 text-right" style={{ color: b.rate >= 70 ? '#16a34a' : 'var(--ysf-blue)', fontFamily: 'Rajdhani, sans-serif' }}>{b.rate}%</span>
              </div>
            ))}
          </div>
        </Panel>

        {/* Two pie charts stacked */}
        <div className="space-y-4">
          <Panel title="Scheme-wise Distribution" subtitle="By enrolled trainees" accentColor="var(--ysf-blue)">
            <div className="flex items-center gap-4">
              <div style={{ position: 'relative', width: 140, height: 140, flexShrink: 0 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={SCHEME_DIST} cx={65} cy={65} innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={2}>
                      {SCHEME_DIST.map((s, i) => <Cell key={i} fill={s.color} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2">
                {SCHEME_DIST.map(s => (
                  <div key={s.name} className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: s.color }} />
                    <span className="text-xs flex-1" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{s.name}</span>
                    <span className="text-xs font-bold" style={{ color: 'var(--foreground)', fontFamily: 'JetBrains Mono, monospace' }}>{(s.value / 1000).toFixed(0)}K</span>
                  </div>
                ))}
              </div>
            </div>
          </Panel>

          <Panel title="Gender Distribution" subtitle="Pan-India trainees" accentColor="var(--ysf-orange)">
            <div className="flex items-center gap-4">
              <div style={{ position: 'relative', width: 120, height: 120, flexShrink: 0 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={GENDER_DIST} cx={55} cy={55} innerRadius={32} outerRadius={55} dataKey="value" paddingAngle={2}>
                      {GENDER_DIST.map((g, i) => <Cell key={i} fill={g.color} />)}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex-1 space-y-2.5">
                {GENDER_DIST.map(g => {
                  const total = GENDER_DIST.reduce((a, x) => a + x.value, 0)
                  return (
                    <div key={g.name} className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: g.color }} />
                      <span className="text-xs flex-1" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{g.name}</span>
                      <span className="text-xs font-bold" style={{ color: g.color, fontFamily: 'Rajdhani, sans-serif' }}>{((g.value / total) * 100).toFixed(1)}%</span>
                    </div>
                  )
                })}
              </div>
            </div>
          </Panel>
        </div>
      </div>

      {/* Top courses table */}
      <Panel title="Top Job Roles by Placement Rate" subtitle="Minimum 5,000 enrolled · sorted by placement %" accentColor="var(--ysf-blue)">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: 'var(--muted)', borderBottom: '1px solid var(--border)' }}>
                {['#', 'Job Role', 'Sector', 'Enrolled', 'Placed', 'Placement Rate'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-bold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...COURSE_TOP].sort((a, b) => b.rate - a.rate).map((c, i) => (
                <tr
                  key={c.course}
                  className="border-t transition-colors"
                  style={{ borderColor: 'var(--border)' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--muted)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <td className="px-4 py-3 text-xs font-bold" style={{ color: 'var(--muted-foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                    {i < 3
                      ? <span className="w-6 h-6 rounded-full inline-flex items-center justify-center text-white text-xs" style={{ background: ['#F5B800', '#9CA3AF', '#CD7F32'][i] }}>{i + 1}</span>
                      : `${i + 1}`
                    }
                  </td>
                  <td className="px-4 py-3 font-semibold text-sm" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{c.course}</td>
                  <td className="px-4 py-3">
                    <span className="text-xs px-2 py-1 rounded-lg" style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)', fontFamily: "'Exo 2', sans-serif" }}>{c.sector}</span>
                  </td>
                  <td className="px-4 py-3 text-xs font-mono" style={{ color: 'var(--muted-foreground)' }}>{c.enrolled.toLocaleString()}</td>
                  <td className="px-4 py-3 text-xs font-mono" style={{ color: 'var(--muted-foreground)' }}>{c.placed.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-2 rounded-full flex-shrink-0" style={{ background: 'var(--border)' }}>
                        <div
                          className="h-2 rounded-full"
                          style={{ width: `${c.rate}%`, background: c.rate >= 80 ? '#16a34a' : c.rate >= 70 ? 'var(--ysf-blue)' : 'var(--ysf-orange)' }}
                        />
                      </div>
                      <span className="font-bold text-xs" style={{ color: c.rate >= 80 ? '#16a34a' : c.rate >= 70 ? 'var(--ysf-blue)' : 'var(--ysf-orange)', fontFamily: 'Rajdhani, sans-serif' }}>
                        {c.rate}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      {/* State-wise summary */}
      <Panel title="State-wise Enrollment Summary" subtitle="Top 6 states by trainee count" accentColor="var(--ysf-orange)">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {STATE_DATA.map(s => (
            <div
              key={s.state}
              className="rounded-xl p-4"
              style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: s.color + '15', color: s.color }}>
                  <MapPin size={14} />
                </div>
                <div className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{s.state}</div>
              </div>
              <div className="text-xl font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                {(s.trainees / 1000).toFixed(1)}K
              </div>
              <div className="text-xs mb-2" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>trainees enrolled</div>
              <div className="h-1.5 rounded-full" style={{ background: 'var(--border)' }}>
                <div className="h-1.5 rounded-full transition-all" style={{ width: `${s.rate}%`, background: s.color }} />
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Placement rate</span>
                <span className="text-xs font-bold" style={{ color: s.color, fontFamily: 'Rajdhani, sans-serif' }}>{s.rate}%</span>
              </div>
            </div>
          ))}
        </div>
      </Panel>

    </div>
  )
}

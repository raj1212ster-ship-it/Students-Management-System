import {
  LayoutGrid, Plus, Search, Layers, CheckCircle,
  FileText, BarChart3, Zap, ArrowDown, TrendingUp,
  BookMarked, LogOut, PanelLeftClose, PanelLeftOpen,
} from 'lucide-react'
import logoYsf from '@/imports/logo-ysf-2.png'
import logoYsfIcon from '@/imports/logo-ysf-3.png'

interface SidebarProps {
  active: string
  onNavigate: (screen: string) => void
  role: 'branch' | 'management'
  onLogout: () => void
  collapsed: boolean
  onToggleCollapse: () => void
  mobileOpen: boolean
  onMobileClose: () => void
}

const BRANCH_NAV_GROUPS = [
  {
    label: 'Main',
    items: [
      { id: 'dashboard',    Icon: LayoutGrid,  label: 'Dashboard',           badge: null,  badgeColor: 'orange' as const },
      { id: 'register',         Icon: Plus,        label: 'New Trainee Registration', badge: null,  badgeColor: null },
      { id: 'verification',     Icon: CheckCircle, label: 'Verification Queue',    badge: '34',  badgeColor: 'orange' as const },
      { id: 'batch',            Icon: Layers,      label: 'Batch Management',    badge: '3',   badgeColor: 'orange' as const },
    ],
  },
  {
    label: 'Operations',
    items: [
      { id: 'documents',   Icon: FileText,  label: 'Documents',          badge: null, badgeColor: null },
      { id: 'reports',     Icon: BarChart3, label: 'Reports',            badge: null, badgeColor: null },
    ],
  },
]

const MGMT_NAV_GROUPS = [
  {
    label: 'Main',
    items: [
      { id: 'mgmt-dashboard', Icon: LayoutGrid, label: 'Executive Dashboard', badge: null, badgeColor: null },
      { id: 'search',         Icon: Search,     label: 'Search Trainee',      badge: null, badgeColor: null },
      { id: 'analytics',      Icon: TrendingUp, label: 'Analytics & Reports', badge: null, badgeColor: null },
    ],
  },
  {
    label: 'Operations',
    items: [
      { id: 'trainee-flow',  Icon: ArrowDown,  label: 'Trainee Flow',       badge: null, badgeColor: null },
      { id: 'pricing',       Icon: Zap,        label: 'Packages & Pricing', badge: null, badgeColor: null },
      { id: 'documentation', Icon: BookMarked, label: 'User Manuals',       badge: null, badgeColor: null },
    ],
  },
]

export default function Sidebar({
  active, onNavigate, role, onLogout, collapsed, onToggleCollapse, mobileOpen,
}: SidebarProps) {
  const groups       = role === 'branch' ? BRANCH_NAV_GROUPS : MGMT_NAV_GROUPS
  const userName     = role === 'branch' ? 'Priya Sharma'    : 'Rajesh Kumar'
  const userRole     = role === 'branch' ? 'Branch User'     : 'Senior Manager'
  const userInitials = role === 'branch' ? 'PS'              : 'RK'
  const avatarBg     = role === 'branch' ? 'var(--ysf-orange)' : 'var(--sidebar-avatar-mgmt)'
  const subtitle     = role === 'branch' ? 'Branch Center'   : 'Executive Portal'

  const w = collapsed ? 'var(--sidebar-collapsed-width)' : 'var(--sidebar-width)'

  return (
    <aside
      className={`sidebar-root fixed left-0 top-0 h-screen flex flex-col z-20 overflow-hidden${mobileOpen ? ' sidebar-mobile-open' : ''}`}
      style={{
        width: w,
        background: 'var(--sidebar-bg)',
        backdropFilter: 'blur(24px) saturate(150%)',
        WebkitBackdropFilter: 'blur(24px) saturate(150%)',
        boxShadow: 'var(--sidebar-right-shadow)',
        borderRight: '1px solid rgba(255,255,255,0.65)',
      }}
    >
      {/* ─── Header ─────────────────────────────────────────── */}
      <div
        className="flex items-center flex-shrink-0"
        style={{
          padding: collapsed ? '14px 0' : '14px 14px 12px',
          justifyContent: collapsed ? 'center' : 'flex-start',
          gap: collapsed ? 0 : 10,
          borderBottom: '1px solid var(--sidebar-divider)',
          minHeight: 68,
        }}
      >
        {/* Logo — full colour, no filter */}
        {!collapsed && (
          <img
            src={logoYsf}
            alt="Yuvashakti Foundation"
            style={{ height: 38, objectFit: 'contain', flexShrink: 0 }}
          />
        )}

        {/* Collapsed: full-colour logo, no box */}
        {collapsed && (
          <img
            src={logoYsfIcon}
            alt="Yuvashakti Foundation"
            style={{ width: 44, height: 44, objectFit: 'contain', flexShrink: 0 }}
          />
        )}

        {/* Title + subtitle (hidden when collapsed) */}
        {!collapsed && (
          <div className="flex-1 min-w-0">
            <div
              className="font-bold leading-tight truncate"
              style={{ fontFamily: 'Rajdhani, sans-serif', fontSize: 15, color: 'var(--sidebar-title-text)' }}
            >
              YSF · SES
            </div>
            <div
              className="truncate"
              style={{ fontFamily: 'Exo 2, sans-serif', fontSize: 11, color: 'var(--sidebar-text-dim)', marginTop: 1 }}
            >
              {subtitle}
            </div>
          </div>
        )}

        {/* Collapse / expand toggle */}
        {!collapsed && (
          <button
            onClick={onToggleCollapse}
            title="Collapse sidebar"
            style={{
              background: 'transparent',
              border: 'none',
              padding: 4,
              cursor: 'pointer',
              borderRadius: 6,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              color: 'var(--sidebar-text-dim)',
              transition: 'background 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--sidebar-hover-bg)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent' }}
          >
            <PanelLeftClose size={17} />
          </button>
        )}

      </div>

      {/* ─── Navigation ─────────────────────────────────────── */}
      <nav
        className="flex-1 pt-3"
        style={{ overflowY: 'auto', overflowX: 'hidden', scrollbarWidth: 'none' }}
      >
        {groups.map((group, gi) => (
          <div key={gi} style={{ marginTop: gi > 0 ? 8 : 0 }}>

            {/* Section label — hidden when collapsed */}
            {!collapsed && (
              <div
                style={{
                  padding: '6px 16px 4px',
                  fontFamily: 'Exo 2, sans-serif',
                  fontSize: 10,
                  fontWeight: 700,
                  letterSpacing: '0.14em',
                  textTransform: 'uppercase',
                  color: 'var(--sidebar-section-label)',
                }}
              >
                {group.label}
              </div>
            )}

            {/* Collapsed: thin divider between groups */}
            {collapsed && gi > 0 && (
              <div style={{ height: 1, background: 'var(--sidebar-divider)', margin: '6px 12px' }} />
            )}

            {/* Items */}
            {group.items.map(item => {
              const isActive = active === item.id
              const badgeBg = 'var(--sidebar-badge-bg)'

              return (
                <div
                  key={item.id}
                  title={collapsed ? item.label : undefined}
                  style={{ position: 'relative' }}
                >
                  <button
                    onClick={() => onNavigate(item.id)}
                    className="w-full flex items-center text-left"
                    style={{
                      gap: collapsed ? 0 : 12,
                      padding: collapsed ? '11px 0' : '11px 16px 11px 12px',
                      justifyContent: collapsed ? 'center' : 'flex-start',
                      borderTop: 'none',
                      borderRight: 'none',
                      borderBottom: 'none',
                      borderLeft: collapsed
                        ? 'none'
                        : isActive
                          ? '4px solid var(--sidebar-active-bar)'
                          : '4px solid transparent',
                      background: isActive ? 'var(--sidebar-active-bg)' : 'transparent',
                      outline: 'none',
                      cursor: 'pointer',
                      transition: 'background 0.15s ease',
                    }}
                    onMouseEnter={e => {
                      if (!isActive) (e.currentTarget as HTMLButtonElement).style.background = 'var(--sidebar-hover-bg)'
                    }}
                    onMouseLeave={e => {
                      if (!isActive) (e.currentTarget as HTMLButtonElement).style.background = 'transparent'
                    }}
                  >
                    {/* Icon */}
                    <item.Icon
                      size={18}
                      style={{
                        color: isActive ? 'var(--sidebar-active-icon)' : 'var(--sidebar-text-dim)',
                        flexShrink: 0,
                      }}
                    />

                    {/* Label + badge — hidden when collapsed */}
                    {!collapsed && (
                      <>
                        <span
                          className="flex-1"
                          style={{
                            fontFamily: 'Exo 2, sans-serif',
                            fontSize: 13.5,
                            fontWeight: isActive ? 600 : 400,
                            color: isActive ? 'var(--sidebar-active-text)' : 'var(--sidebar-text)',
                            lineHeight: '18px',
                            whiteSpace: 'nowrap',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                          }}
                        >
                          {item.label}
                        </span>

                        {item.badge && (
                          <span
                            className="text-white font-bold flex-shrink-0"
                            style={{
                              background: badgeBg,
                              fontFamily: 'Exo 2, sans-serif',
                              fontSize: 10,
                              lineHeight: '14px',
                              padding: '2px 7px',
                              borderRadius: 20,
                              minWidth: 22,
                              textAlign: 'center',
                            }}
                          >
                            {item.badge}
                          </span>
                        )}
                      </>
                    )}

                    {/* Collapsed: dot badge on icon */}
                    {collapsed && item.badge && (
                      <div
                        style={{
                          position: 'absolute',
                          top: 8,
                          right: 10,
                          width: 7,
                          height: 7,
                          borderRadius: '50%',
                          background: 'var(--sidebar-badge-bg)',
                        }}
                      />
                    )}
                  </button>
                </div>
              )
            })}
          </div>
        ))}
      </nav>

      {/* ─── Expand button (collapsed only) — sits above profile ── */}
      {collapsed && (
        <div
          style={{
            flexShrink: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '6px 0',
            borderTop: '1px solid var(--sidebar-divider)',
          }}
        >
          <button
            onClick={onToggleCollapse}
            title="Expand sidebar"
            style={{
              background: 'transparent',
              border: 'none',
              padding: 6,
              cursor: 'pointer',
              borderRadius: 6,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'var(--sidebar-text-dim)',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--sidebar-hover-bg)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent' }}
          >
            <PanelLeftOpen size={16} />
          </button>
        </div>
      )}

      {/* ─── User profile (bottom) ──────────────────────────── */}
      <div
        className="flex-shrink-0"
        style={{ borderTop: '1px solid var(--sidebar-divider)', padding: collapsed ? '12px 0' : '12px 16px' }}
      >
        {/* Profile row */}
        <div
          className="flex items-center"
          style={{
            gap: collapsed ? 0 : 12,
            justifyContent: collapsed ? 'center' : 'flex-start',
          }}
        >
          <div
            className="rounded-full flex items-center justify-center font-bold text-white flex-shrink-0"
            style={{
              width: 36, height: 36,
              background: avatarBg,
              fontFamily: 'Rajdhani, sans-serif',
              fontSize: 12,
            }}
          >
            {userInitials}
          </div>

          {!collapsed && (
            <>
              <div className="flex-1 min-w-0">
                <div
                  className="font-semibold truncate"
                  style={{ fontFamily: 'Rajdhani, sans-serif', fontSize: 13.5, color: 'var(--sidebar-title-text)', lineHeight: '18px' }}
                >
                  {userName}
                </div>
                <div
                  className="truncate"
                  style={{ fontFamily: 'Exo 2, sans-serif', fontSize: 11, color: 'var(--sidebar-text-dim)', lineHeight: '16px' }}
                >
                  {userRole}
                </div>
              </div>
              <div className="rounded-full flex-shrink-0" style={{ width: 8, height: 8, background: 'var(--sidebar-online-dot)' }} />
            </>
          )}
        </div>

        {/* Sign Out — hidden when collapsed */}
        {!collapsed && (
          <button
            onClick={onLogout}
            className="w-full flex items-center gap-2 mt-3"
            style={{
              padding: '6px 8px',
              borderRadius: 6,
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              transition: 'background 0.15s',
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--sidebar-signout-hover-bg)' }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'transparent' }}
          >
            <LogOut size={14} style={{ color: 'var(--sidebar-signout-color)', flexShrink: 0 }} />
            <span style={{ fontFamily: 'Exo 2, sans-serif', fontSize: 12, color: 'var(--sidebar-signout-color)' }}>
              Sign Out
            </span>
          </button>
        )}
      </div>
    </aside>
  )
}

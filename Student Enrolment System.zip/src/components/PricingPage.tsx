import { BookOpen, Zap, Trophy, Check, Award, Building2, MapPin, Star } from 'lucide-react'

const PACKAGES = [
  {
    tier: 'Foundation',
    tagline: 'Start your journey',
    price: '₹4,999',
    period: '/ 3 months',
    badge: null,
    color: 'var(--ysf-blue)',
    shadowColor: 'rgba(21,101,192,0.18)',
    features: [
      '1 Vocational Trade of Choice',
      'Classroom & Practical Sessions',
      'Industry-Ready Curriculum',
      'Attendance Tracking Portal',
      'YSF Certificate on Completion',
      'Placement Assistance (Basic)',
    ],
    cta: 'Enroll Now',
    Icon: BookOpen,
  },
  {
    tier: 'Empowerment',
    tagline: 'Most chosen by trainees',
    price: '₹8,999',
    period: '/ 6 months',
    badge: 'BEST VALUE',
    color: 'var(--ysf-orange)',
    shadowColor: 'rgba(249,115,22,0.20)',
    features: [
      '2 Vocational Trades + Soft Skills',
      'Live Projects & Industry Mentors',
      'Digital Literacy Module',
      'Attendance & Progress Dashboard',
      'YSF Gold Certificate',
      'Priority Placement Support',
      'Mock Interviews & Resume Help',
    ],
    cta: 'Get Started',
    Icon: Zap,
  },
  {
    tier: 'Excellence',
    tagline: 'For high achievers',
    price: '₹14,999',
    period: '/ 12 months',
    badge: null,
    color: 'var(--ysf-red)',
    shadowColor: 'rgba(229,57,53,0.18)',
    features: [
      '3 Trades + Advanced Specialisation',
      'On-Site Industry Internship (1 mo.)',
      'Personal Career Coach',
      'Live Analytics & Parent Access',
      'YSF Platinum Certificate',
      'Guaranteed Placement Interview',
      'Entrepreneurship Module',
      'Alumni Network Access (Lifetime)',
    ],
    cta: 'Apply Now',
    Icon: Trophy,
  },
]

const TRUST = [
  { Icon: Award,     label: '50,000+ Trainees Placed' },
  { Icon: Building2, label: '200+ Hiring Partners'    },
  { Icon: MapPin,    label: '85+ Centers Pan-India'   },
  { Icon: Star,      label: '4.8 / 5 Trainee Rating'  },
]

export default function PricingPage() {
  return (
    <div className="min-h-screen py-10 px-6" style={{ background: 'var(--background)' }}>

      {/* Header */}
      <div className="text-center mb-10 max-w-2xl mx-auto">
        <p className="text-xs font-bold uppercase tracking-widest mb-2" style={{ color: 'var(--ysf-orange)' }}>
          Training Programs
        </p>
        <h1 className="text-4xl font-bold mb-3" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif', letterSpacing: '-0.01em' }}>
          Choose Your Growth Path
        </h1>
        <p className="text-base" style={{ color: 'var(--muted-foreground)', fontFamily: 'Exo 2, sans-serif' }}>
          Invest in skills that open doors. Every YSF package is designed for real-world readiness and guaranteed employability.
        </p>
      </div>

      {/* Trust bar */}
      <div
        className="flex flex-wrap items-center justify-center gap-6 px-8 py-4 rounded-xl mb-10 mx-auto"
        style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)', maxWidth: 760 }}
      >
        {TRUST.map(item => (
          <div key={item.label} className="flex items-center gap-2">
            <span style={{ color: 'var(--ysf-orange)' }}><item.Icon size={16} /></span>
            <span className="text-xs font-semibold" style={{ color: 'var(--foreground)', fontFamily: 'Exo 2, sans-serif' }}>{item.label}</span>
          </div>
        ))}
      </div>

      {/* Pricing cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-5xl mx-auto">
        {PACKAGES.map((pkg, idx) => {
          const isCenter = idx === 1
          return (
            <div
              key={pkg.tier}
              className="relative flex flex-col rounded-xl overflow-hidden transition-all duration-200 group"
              style={{
                background: 'var(--card)',
                border: isCenter ? `2px solid var(--ysf-orange)` : '1px solid var(--border)',
                boxShadow: isCenter ? `0 8px 32px ${pkg.shadowColor}, var(--card-shadow)` : 'var(--card-shadow)',
                transform: isCenter ? 'translateY(-8px)' : 'none',
              }}
              onMouseEnter={e => { e.currentTarget.style.boxShadow = `0 8px 32px ${pkg.shadowColor}`; e.currentTarget.style.transform = isCenter ? 'translateY(-10px)' : 'translateY(-4px)' }}
              onMouseLeave={e => { e.currentTarget.style.boxShadow = isCenter ? `0 8px 32px ${pkg.shadowColor}, var(--card-shadow)` : 'var(--card-shadow)'; e.currentTarget.style.transform = isCenter ? 'translateY(-8px)' : 'none' }}
            >
              {/* Badge */}
              {pkg.badge && (
                <div
                  className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold tracking-widest text-white uppercase whitespace-nowrap"
                  style={{ background: 'var(--ysf-orange)', boxShadow: '0 4px 12px rgba(249,115,22,0.30)' }}
                >
                  {pkg.badge}
                </div>
              )}

              {/* Top accent border */}
              <div className="h-1.5 w-full" style={{ background: pkg.color }} />

              {/* Card body */}
              <div className="flex flex-col flex-1 p-6">
                {/* Icon + tier */}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: pkg.shadowColor, color: pkg.color }}
                  >
                    <pkg.Icon size={22} />
                  </div>
                  <div>
                    <div className="font-bold text-lg leading-tight" style={{ color: pkg.color, fontFamily: 'Rajdhani, sans-serif' }}>
                      {pkg.tier}
                    </div>
                    <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: 'Exo 2, sans-serif' }}>
                      {pkg.tagline}
                    </div>
                  </div>
                </div>

                {/* Price */}
                <div className="flex items-end gap-1 mb-5">
                  <span className="text-4xl font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif', letterSpacing: '-0.02em' }}>
                    {pkg.price}
                  </span>
                  <span className="text-sm mb-1" style={{ color: 'var(--muted-foreground)', fontFamily: 'Exo 2, sans-serif' }}>
                    {pkg.period}
                  </span>
                </div>

                {/* Divider */}
                <div className="h-px w-full mb-5" style={{ background: 'var(--border)' }} />

                {/* Features */}
                <ul className="flex flex-col gap-3 flex-1 mb-6">
                  {pkg.features.map(f => (
                    <li key={f} className="flex items-start gap-2.5">
                      <span
                        className="mt-0.5 flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-white"
                        style={{ background: pkg.color, boxShadow: `0 2px 6px ${pkg.shadowColor}` }}
                      >
                        <Check size={11} />
                      </span>
                      <span className="text-sm leading-snug" style={{ color: 'var(--foreground)', fontFamily: 'Exo 2, sans-serif' }}>
                        {f}
                      </span>
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <button
                  className="w-full py-3 rounded-xl font-bold text-sm text-white transition-all"
                  style={{
                    background: pkg.color,
                    boxShadow: `0 4px 14px ${pkg.shadowColor}`,
                    fontFamily: 'Rajdhani, sans-serif',
                    letterSpacing: '0.03em',
                    border: 'none',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.opacity = '0.9')}
                  onMouseLeave={e => (e.currentTarget.style.opacity = '1')}
                >
                  {pkg.cta}
                </button>

                <p className="text-center text-xs mt-3" style={{ color: 'var(--muted-foreground)', fontFamily: 'Exo 2, sans-serif' }}>
                  No hidden fees · Flexible installments
                </p>
              </div>
            </div>
          )
        })}
      </div>

    </div>
  )
}

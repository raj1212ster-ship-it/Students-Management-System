import { useState } from 'react'
import { CheckCircle, Clock, XCircle, Download, FileText, Printer, PartyPopper } from 'lucide-react'

interface TraineeProfileProps {
  code: string
  onBack: () => void
}

const PROFILE_DATA: Record<string, {
  name: string; dob: string; gender: string; aadhaar: string; mobile: string; email: string;
  father: string; mother: string; state: string; city: string; pincode: string;
  scheme: string; jobRole: string; nsqf: string;
  batch: string; batchStart: string; trainer: string; center: string;
  status: string; attendance: string;
  edu: { level: string; board: string; year: string; pct: string }[];
  timeline: { date: string; event: string; by: string }[];
  docs: { name: string; status: 'verified' | 'pending' | 'missing' }[];
}> = {
  'TRN001234': {
    name: 'Rahul Sharma', dob: '14 Mar 2001', gender: 'Male', aadhaar: '7823 XXXX XXXX', mobile: '9876543210', email: 'rahul.sharma@email.com',
    father: 'Suresh Sharma', mother: 'Kamla Sharma', state: 'Telangana', city: 'Hyderabad', pincode: '500032',
    scheme: 'PMKVY 4.0', jobRole: 'Electrician General', nsqf: 'Level 4',
    batch: 'HYD-ELEC-2024-B12', batchStart: '01 Jun 2024', trainer: 'Mr. Venkat Rao', center: 'Hyderabad Training Center',
    status: 'Completed', attendance: '94%',
    edu: [
      { level: '10th', board: 'BSEH', year: '2017', pct: '72%' },
      { level: '12th', board: 'BSEH', year: '2019', pct: '65%' },
    ],
    timeline: [
      { date: '02 Jan 2024', event: 'Registration Submitted', by: 'Branch User' },
      { date: '05 Jan 2024', event: 'Documents Verified', by: 'Verifier' },
      { date: '10 Jan 2024', event: 'Batch HYD-B12 Assigned', by: 'Batch Admin' },
      { date: '01 Jun 2024', event: 'Training Started', by: 'System' },
      { date: '30 Jul 2024', event: 'Training Completed', by: 'System' },
      { date: '01 Aug 2024', event: 'Certificate Issued', by: 'Certifying Body' },
    ],
    docs: [
      { name: 'Aadhaar Card', status: 'verified' },
      { name: 'PAN Card', status: 'verified' },
      { name: 'Passport Photo', status: 'verified' },
      { name: '10th Marksheet', status: 'verified' },
      { name: 'Bank Passbook', status: 'verified' },
      { name: 'Agreement Form', status: 'verified' },
      { name: 'Offer Letter', status: 'verified' },
    ],
  },
}

const DEFAULT_PROFILE = PROFILE_DATA['TRN001234']

const TABS = ['Personal', 'Education', 'Course & Batch', 'Attendance', 'Documents', 'Agreement', 'Timeline', 'Placement']

export default function TraineeProfile({ code, onBack }: TraineeProfileProps) {
  const [tab, setTab] = useState('Personal')
  const profile = PROFILE_DATA[code] || DEFAULT_PROFILE

  const DOC_STYLE = {
    'verified': { Icon: CheckCircle, bg: '#d1fae5', color: '#065f46', label: 'Verified' },
    'pending': { Icon: Clock, bg: '#fef3c7', color: '#92400e', label: 'Pending' },
    'missing': { Icon: XCircle, bg: '#fee2e2', color: '#991b1b', label: 'Missing' },
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* Back */}
      <div className="flex items-center gap-3 mb-5">
        <button onClick={onBack} className="text-slate-400 hover:text-slate-700 transition-colors text-sm">← Back to Dashboard</button>
        <div className="h-4 w-px bg-slate-300" />
        <div className="text-sm text-slate-400">Trainee 360° Profile</div>
      </div>

      {/* Profile Header */}
      <div className="rounded-2xl p-6 mb-5" style={{ background: 'linear-gradient(135deg, #0f2744 0%, var(--ysf-orange) 100%)' }}>
        <div className="flex items-start gap-5">
          {/* Avatar */}
          <div className="flex-shrink-0">
            <div className="w-24 h-24 rounded-xl flex items-center justify-center text-2xl font-bold text-white" style={{ background: 'rgba(255,255,255,0.12)', border: '2px solid rgba(255,255,255,0.25)' }}>
              {profile.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div className="text-center mt-2">
              <span className="text-xs px-2 py-0.5 rounded-full text-white font-medium" style={{ background: profile.status === 'Completed' ? '#16a34a' : '#2563eb' }}>
                {profile.status}
              </span>
            </div>
          </div>

          {/* Info */}
          <div className="flex-1">
            <div className="text-sm text-xs mb-1 font-mono">{code}</div>
            <h2 className="text-2xl font-bold text-white mb-1" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{profile.name}</h2>
            <p className="text-sm text-sm mb-4">{profile.jobRole} · {profile.scheme} · {profile.center}</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { label: 'DOB', value: profile.dob },
                { label: 'Mobile', value: profile.mobile },
                { label: 'State', value: profile.state },
                { label: 'Attendance', value: profile.attendance },
              ].map(f => (
                <div key={f.label} className="rounded-lg px-3 py-2" style={{ background: 'rgba(255,255,255,0.08)' }}>
                  <div className="text-xs text-xs mb-0.5">{f.label}</div>
                  <div className="text-white text-sm font-semibold">{f.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-2">
            <button className="px-3 py-2 rounded-lg text-white text-xs font-medium flex items-center gap-1.5" style={{ background: 'rgba(255,255,255,0.15)' }}><Download size={13} /> Download Profile</button>
            <button className="px-3 py-2 rounded-lg text-white text-xs font-medium flex items-center gap-1.5" style={{ background: 'rgba(255,255,255,0.15)' }}><FileText size={13} /> View Agreement</button>
            <button className="px-3 py-2 rounded-lg text-white text-xs font-medium flex items-center gap-1.5" style={{ background: 'rgba(255,255,255,0.15)' }}><Printer size={13} /> Print</button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto mb-4 rounded-xl p-1" style={{ background: '#fff', border: '1px solid #e2e8f0' }}>
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className="px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-all"
            style={tab === t
              ? { background: 'var(--ysf-orange)', color: '#fff', fontFamily: 'Rajdhani, sans-serif' }
              : { color: 'var(--muted-foreground)', fontFamily: 'Rajdhani, sans-serif' }}
          >
            {t}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="rounded-xl p-6" style={{ background: '#fff', border: '1px solid #e2e8f0' }}>
        {tab === 'Personal' && (
          <div className="space-y-6">
            <Section title="Basic Information">
              <Grid items={[
                { label: 'Full Name', value: profile.name },
                { label: 'Date of Birth', value: profile.dob },
                { label: 'Gender', value: profile.gender },
                { label: 'Aadhaar', value: profile.aadhaar },
                { label: 'Mobile', value: profile.mobile },
                { label: 'Email', value: profile.email },
              ]} />
            </Section>
            <Section title="Family Details">
              <Grid items={[
                { label: "Father's Name", value: profile.father },
                { label: "Mother's Name", value: profile.mother },
              ]} />
            </Section>
            <Section title="Address">
              <Grid items={[
                { label: 'State', value: profile.state },
                { label: 'City', value: profile.city },
                { label: 'PIN Code', value: profile.pincode },
              ]} />
            </Section>
          </div>
        )}

        {tab === 'Education' && (
          <div className="space-y-3">
            {profile.edu.length === 0 && <p className="text-slate-400 text-sm">No education records found.</p>}
            {profile.edu.map(e => (
              <div key={e.level} className="rounded-xl p-4" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-slate-800 text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{e.level} Standard</div>
                    <div className="text-slate-500 text-xs mt-0.5">Board: {e.board} · Year: {e.year}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-sm font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{e.pct}</div>
                    <div className="text-xs text-slate-400">Percentage</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'Course & Batch' && (
          <div className="space-y-5">
            <Section title="Course Details">
              <Grid items={[
                { label: 'Scheme', value: profile.scheme },
                { label: 'Job Role', value: profile.jobRole },
                { label: 'NSQF Level', value: profile.nsqf },
              ]} />
            </Section>
            <Section title="Batch Details">
              <Grid items={[
                { label: 'Batch ID', value: profile.batch },
                { label: 'Batch Start', value: profile.batchStart },
                { label: 'Trainer', value: profile.trainer },
                { label: 'Training Center', value: profile.center },
              ]} />
            </Section>
          </div>
        )}

        {tab === 'Attendance' && (
          <div>
            <div className="flex items-center gap-4 mb-6">
              <div className="rounded-xl px-6 py-4 text-center" style={{ background: '#eff6ff', border: '2px solid #bfdbfe' }}>
                <div className="text-3xl font-bold text-sm font-bold" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{profile.attendance}</div>
                <div className="text-xs text-blue-500 mt-1">Overall Attendance</div>
              </div>
              <div className="text-slate-500 text-sm">
                <p>Total Training Days: <strong>60</strong></p>
                <p>Present: <strong>56</strong></p>
                <p>Absent: <strong>4</strong></p>
              </div>
            </div>
            <div className="rounded-xl p-4" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
              <p className="text-green-700 text-sm flex items-center gap-1.5"><CheckCircle size={14} /> Attendance criteria met (minimum 70% required).</p>
            </div>
          </div>
        )}

        {tab === 'Documents' && (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
            {profile.docs.map(d => {
              const s = DOC_STYLE[d.status]
              return (
                <div key={d.name} className="rounded-xl p-4 flex items-start gap-3" style={{ background: s.bg, border: `1px solid ${s.color}44` }}>
                  <span className="text-xl" style={{ color: s.color }}><s.Icon size={18} /></span>
                  <div>
                    <div className="font-semibold text-slate-800 text-sm">{d.name}</div>
                    <div className="text-xs font-medium mt-0.5" style={{ color: s.color }}>{s.label}</div>
                    {d.status === 'verified' && (
                      <button className="text-xs text-blue-600 hover:underline mt-1">View Document</button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {tab === 'Agreement' && (
          <div>
            <div className="rounded-xl overflow-hidden mb-4" style={{ background: '#f8fafc', border: '1px solid #e2e8f0', height: 400 }}>
              <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: '#e2e8f0', background: '#fff' }}>
                <div className="text-sm font-semibold text-slate-700" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Trainee Agreement — TRN001234</div>
                <div className="flex gap-2">
                  <button className="text-xs px-3 py-1.5 rounded-lg font-medium flex items-center gap-1" style={{ background: '#eff6ff', color: '#1d4ed8' }}><Download size={12} /> Download</button>
                  <button className="text-xs px-3 py-1.5 rounded-lg font-medium flex items-center gap-1" style={{ background: '#f1f5f9', color: '#475569' }}><Printer size={12} /> Print</button>
                </div>
              </div>
              <div className="p-8 text-center flex flex-col items-center justify-center h-full" style={{ color: '#94a3b8' }}>
                <div className="mb-4"><FileText size={56} /></div>
                <div className="font-semibold text-slate-600 mb-2" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Agreement Document</div>
                <div className="text-sm text-slate-400">Trainee_Agreement_TRN001234.pdf</div>
                <div className="mt-4 text-xs flex items-center gap-1.5" style={{ background: '#d1fae5', color: '#065f46', padding: '6px 16px', borderRadius: 20 }}><CheckCircle size={12} /> Signed & Verified on 05 Jan 2024</div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-3 text-sm">
              <div className="rounded-lg p-3" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="text-xs text-slate-400">Signed Date</div>
                <div className="font-medium text-slate-800">03 Jan 2024</div>
              </div>
              <div className="rounded-lg p-3" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="text-xs text-slate-400">Verified By</div>
                <div className="font-medium text-slate-800">Mr. V. Rao (Verifier)</div>
              </div>
              <div className="rounded-lg p-3" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="text-xs text-slate-400">Version</div>
                <div className="font-medium text-slate-800">v1.0 (Current)</div>
              </div>
            </div>
          </div>
        )}

        {tab === 'Timeline' && (
          <div className="relative">
            <div className="absolute left-4 top-0 bottom-0 w-px" style={{ background: '#e2e8f0' }} />
            <div className="space-y-4">
              {profile.timeline.map((e, i) => (
                <div key={i} className="flex gap-4 relative">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 z-10"
                    style={{ background: i === 0 ? 'var(--ysf-orange)' : i === profile.timeline.length - 1 ? '#16a34a' : '#e2e8f0', color: i === 0 || i === profile.timeline.length - 1 ? '#fff' : '#64748b' }}>
                    {i + 1}
                  </div>
                  <div className="flex-1 pb-2">
                    <div className="font-semibold text-slate-800 text-sm" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{e.event}</div>
                    <div className="text-xs text-slate-400 mt-0.5">{e.date} · by {e.by}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {tab === 'Placement' && (
          <div className="rounded-xl p-6 text-center" style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
            <div className="mb-3 flex justify-center" style={{ color: '#16a34a' }}><PartyPopper size={40} /></div>
            <h3 className="font-bold text-slate-800 text-lg mb-2" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Placement Details</h3>
            <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto mt-4 text-left">
              {[
                { label: 'Employer', value: 'Energo Solutions Pvt. Ltd.' },
                { label: 'Location', value: 'Hyderabad, TS' },
                { label: 'Salary (Monthly)', value: '₹14,500' },
                { label: 'Joining Date', value: '15 Aug 2024' },
              ].map(f => (
                <div key={f.label} className="rounded-lg p-3" style={{ background: '#fff', border: '1px solid #d1fae5' }}>
                  <div className="text-xs text-slate-400">{f.label}</div>
                  <div className="font-semibold text-slate-800 text-sm">{f.value}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">{title}</div>
      {children}
    </div>
  )
}

function Grid({ items }: { items: { label: string; value: string }[] }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
      {items.map(i => (
        <div key={i.label} className="rounded-lg p-3" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
          <div className="text-xs text-slate-400 mb-0.5">{i.label}</div>
          <div className="text-sm font-semibold text-slate-800">{i.value}</div>
        </div>
      ))}
    </div>
  )
}

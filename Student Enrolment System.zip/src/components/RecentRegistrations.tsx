import { useState, useMemo } from 'react'
import type React from 'react'
import { ZONE_COMPANIES, ZONE_LIST, ALL_ZONE_COMPANIES } from '@/data/indiaGeo'
import {
  Search, Eye, Edit2, Clock, CheckCircle, XCircle, X, Check,
  ChevronDown, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight,
  Building2, BookOpen, FileText, RotateCcw, Plus, AlertCircle,
} from 'lucide-react'
import type { RecentRegistration } from './RegistrationWizard'

/* ── Shared styles — identical to BatchManagement ──────────────────── */
const GLASS: React.CSSProperties = {
  background: 'rgba(255,255,255,0.72)',
  backdropFilter: 'blur(18px) saturate(130%)',
  WebkitBackdropFilter: 'blur(18px) saturate(130%)',
  border: '1px solid rgba(255,255,255,0.75)',
}
const CARD_SHADOW = '0 4px 24px rgba(21,101,192,0.10), inset 0 1px 0 rgba(255,255,255,0.90)'

const SEL: React.CSSProperties = {
  padding: '8px 32px 8px 12px', borderRadius: 10, fontSize: 13,
  border: '1px solid rgba(255,255,255,0.70)',
  background: 'rgba(255,255,255,0.65)', color: '#0D2B5E',
  fontFamily: "'Exo 2', sans-serif", outline: 'none', cursor: 'pointer', width: '100%',
  appearance: 'none',
}
const INP: React.CSSProperties = {
  padding: '8px 12px 8px 36px', borderRadius: 10, fontSize: 13,
  border: '1px solid rgba(255,255,255,0.70)',
  background: 'rgba(255,255,255,0.65)', color: '#0D2B5E',
  fontFamily: "'Exo 2', sans-serif", outline: 'none', width: '100%',
}

/* ── Constants ─────────────────────────────────────────────────────── */
const SCHEMES   = ['All Schemes', 'WILP', 'BVOC', 'DVOC', 'FLEXI', 'MSBTE']
const STATUSES  = ['All', 'Pending', 'Approved', 'Rejected'] as const
const PAGE_SIZES = [5, 10, 25, 50]

type Status = 'Pending' | 'Approved' | 'Rejected'

const STATUS_CFG: Record<Status, { bg: string; color: string; dot: string }> = {
  Pending:  { bg: 'rgba(202,138,4,0.12)',  color: '#A16207', dot: '#CA8A04' },
  Approved: { bg: 'rgba(22,163,74,0.12)',  color: '#15803D', dot: '#16a34a' },
  Rejected: { bg: 'rgba(229,57,53,0.12)',  color: '#B91C1C', dot: '#E53935' },
}

/* ── Sample trainee data ───────────────────────────────────────────── */
interface TraineeRow {
  id: string; code: string; name: string; aadhaar: string
  company: string; zone: string; scheme: string; status: Status
  mobile: string; email: string; dob: string; gender: string
  course: string; enrolled: string
  docs: { label: string; done: boolean }[]
}

const SAMPLE: TraineeRow[] = [
  { id:'1',  code:'TRN000154', name:'Rahul Sharma',   aadhaar:'XXXX XXXX 1234', company:'Amber Enterprises India Limited, Supa', zone:'Ahilya Nagar',      scheme:'WILP',  status:'Pending',  mobile:'9812345678', email:'rahul.sharma@email.com',  dob:'1999-04-12', gender:'Male',   course:'Electrician General',          enrolled:'2026-07-01', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'2',  code:'TRN000155', name:'Sneha Patil',    aadhaar:'XXXX XXXX 2568', company:'Mahindra & Mahindra Ltd, Nashik',        zone:'Nashik',            scheme:'BVOC',  status:'Approved', mobile:'9823456789', email:'sneha.patil@email.com',   dob:'2000-08-22', gender:'Female', course:'CNC Operator',                 enrolled:'2026-06-15', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'3',  code:'TRN000156', name:'Amit Kumar',     aadhaar:'XXXX XXXX 4589', company:'Bajaj Auto Ltd, Pune',                  zone:'Pune',              scheme:'WILP',  status:'Rejected', mobile:'9834567890', email:'amit.kumar@email.com',    dob:'1998-12-05', gender:'Male',   course:'Welder (FCAW)',                enrolled:'2026-07-10', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'4',  code:'TRN000157', name:'Pooja Singh',    aadhaar:'XXXX XXXX 7896', company:'Bharat Forge Limited, Pune',            zone:'Pune',              scheme:'DVOC',  status:'Pending',  mobile:'9845678901', email:'pooja.singh@email.com',   dob:'2001-03-18', gender:'Female', course:'Solar PV Technician',          enrolled:'2026-07-12', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:true}] },
  { id:'5',  code:'TRN000158', name:'Vikash Yadav',   aadhaar:'XXXX XXXX 1478', company:'Endurance Technologies Limited',        zone:'Chh. Sambhajinagar',scheme:'FLEXI', status:'Pending',  mobile:'9856789012', email:'vikash.yadav@email.com',  dob:'1999-11-30', gender:'Male',   course:'Plumber General',              enrolled:'2026-07-15', docs:[{label:'Aadhaar',done:false},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'6',  code:'TRN000159', name:'Priya Nair',     aadhaar:'XXXX XXXX 3321', company:'Gilbarco Veeder Root India Pvt. Ltd.', zone:'Coimbatore',        scheme:'MSBTE', status:'Approved', mobile:'9867890123', email:'priya.nair@email.com',    dob:'2000-06-07', gender:'Female', course:'AC & Refrigeration Technician',enrolled:'2026-06-20', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'7',  code:'TRN000160', name:'Sanjay Mehta',   aadhaar:'XXXX XXXX 9012', company:'Hero MotoCorp Ltd, Haridwar',          zone:'Haridwar',          scheme:'WILP',  status:'Pending',  mobile:'9878901234', email:'sanjay.mehta@email.com',  dob:'1997-09-14', gender:'Male',   course:'Data Entry Operator',          enrolled:'2026-07-18', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'8',  code:'TRN000161', name:'Kavitha Reddy',  aadhaar:'XXXX XXXX 6543', company:'Hyundai Motor India Ltd, Chennai',    zone:'Chennai',           scheme:'BVOC',  status:'Approved', mobile:'9889012345', email:'kavitha.reddy@email.com', dob:'2001-01-25', gender:'Female', course:'Retail Sales Associate',       enrolled:'2026-06-10', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'9',  code:'TRN000162', name:'Deepak Joshi',   aadhaar:'XXXX XXXX 2109', company:'Amber Enterprises India Limited, Supa',zone:'Ahilya Nagar',     scheme:'DVOC',  status:'Rejected', mobile:'9890123456', email:'deepak.joshi@email.com',  dob:'1998-07-03', gender:'Male',   course:'Electrician General',          enrolled:'2026-07-05', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:false},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'10', code:'TRN000163', name:'Anjali Sharma',  aadhaar:'XXXX XXXX 8765', company:'Tata Steel Ltd, Jamshedpur',          zone:'Jamshedpur',        scheme:'MSBTE', status:'Pending',  mobile:'9801234567', email:'anjali.sharma@email.com', dob:'2000-10-11', gender:'Female', course:'Beauty Therapist',             enrolled:'2026-07-20', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'11', code:'TRN000164', name:'Rajan Verma',    aadhaar:'XXXX XXXX 4410', company:'Maruti Suzuki India Ltd, Gurgaon',   zone:'NCR Haryana',       scheme:'WILP',  status:'Approved', mobile:'9812345670', email:'rajan.verma@email.com',   dob:'1999-02-28', gender:'Male',   course:'CNC Operator',                 enrolled:'2026-06-25', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'12', code:'TRN000165', name:'Meena Kumari',   aadhaar:'XXXX XXXX 3322', company:'Samsung India Electronics Pvt. Ltd.',zone:'NCR Noida',         scheme:'FLEXI', status:'Pending',  mobile:'9823456780', email:'meena.kumari@email.com',  dob:'2001-05-17', gender:'Female', course:'Data Entry Operator',          enrolled:'2026-07-22', docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
]

/* ── Sub-components ────────────────────────────────────────────────── */
function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <span className="text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full"
        style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0', border: '1px solid rgba(21,101,192,0.18)', fontFamily: "'Exo 2', sans-serif" }}>
        {children}
      </span>
      <div className="flex-1 h-px" style={{ background: 'rgba(21,101,192,0.12)' }} />
    </div>
  )
}

/* ── Profile Drawer ────────────────────────────────────────────────── */
function ProfileDrawer({ trainee, onClose, onAction, onEdit }: {
  trainee: TraineeRow
  onClose: () => void
  onAction: (id: string, action: Status) => void
  onEdit: (t: TraineeRow) => void
}) {
  const sc = STATUS_CFG[trainee.status]
  const initials = trainee.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()

  const timeline = [
    { label: 'Form Submitted',     done: true },
    { label: 'Documents Uploaded', done: trainee.docs.some(d => d.done) },
    { label: 'Under Review',       done: trainee.status !== 'Pending' },
    { label: 'Final Decision',     done: trainee.status !== 'Pending' },
  ]

  return (
    <>
      <div className="fixed inset-0 z-40"
        style={{ background: 'rgba(13,43,94,0.28)', backdropFilter: 'blur(4px)' }}
        onClick={onClose}
      />
      <div className="fixed right-0 top-0 h-full z-50 flex flex-col overflow-y-auto"
        style={{ width: 390, background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderLeft: '1px solid rgba(255,255,255,0.80)', boxShadow: '-8px 0 48px rgba(21,101,192,0.16), -2px 0 8px rgba(0,0,0,0.06)' }}>

        {/* Drawer header */}
        <div className="flex-shrink-0"
          style={{ background: 'linear-gradient(120deg,#1565C0,#1976D2 60%,#F97316)', padding: 20 }}>
          <div className="flex items-start justify-between mb-3">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-bold flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.22)', border: '1.5px solid rgba(255,255,255,0.40)', backdropFilter: 'blur(8px)', fontFamily: 'Rajdhani, sans-serif' }}>
              {initials}
            </div>
            <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(255,255,255,0.18)', color: '#fff', border: '1px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}>
              <X size={15} />
            </button>
          </div>
          <div className="font-bold text-xl text-white" style={{ fontFamily: 'Rajdhani, sans-serif' }}>{trainee.name}</div>
          <div className="text-xs mt-0.5 font-mono" style={{ color: 'rgba(255,255,255,0.80)' }}>{trainee.code}</div>
          <div className="mt-2 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold"
            style={{ background: sc.bg, color: sc.color }}>
            <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: sc.dot }} />
            {trainee.status}
          </div>
        </div>

        <div className="flex-1 p-5 space-y-4">
          {/* Status chips */}
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: 'Registration', val: 'Active',      ok: true  },
              { label: 'Verification', val: trainee.status, ok: trainee.status === 'Approved' },
            ].map(s => (
              <div key={s.label} className="rounded-xl p-3 text-center"
                style={{ background: s.ok ? 'rgba(22,163,74,0.10)' : 'rgba(202,138,4,0.10)', border: `1px solid ${s.ok ? 'rgba(22,163,74,0.20)' : 'rgba(202,138,4,0.20)'}` }}>
                <div className="text-xs font-bold mb-1" style={{ color: s.ok ? '#15803D' : '#A16207', fontFamily: "'Exo 2', sans-serif" }}>{s.val}</div>
                <div className="text-xs" style={{ color: '#7A90A8', fontFamily: "'Exo 2', sans-serif" }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Info rows */}
          <div className="rounded-xl p-4 space-y-3"
            style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(255,255,255,0.72)' }}>
            {[
              { Icon: Building2, label: 'Company', val: trainee.company },
              { Icon: BookOpen,  label: 'Scheme',  val: trainee.scheme  },
              { Icon: BookOpen,  label: 'Course',  val: trainee.course  },
              { Icon: BookOpen,  label: 'Zone',    val: trainee.zone    },
            ].map(r => (
              <div key={r.label} className="flex items-center gap-3">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0' }}>
                  <r.Icon size={13} />
                </div>
                <span className="text-xs" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif", minWidth: 60 }}>{r.label}</span>
                <span className="text-xs font-semibold ml-auto text-right" style={{ color: '#0D2B5E', fontFamily: "'Exo 2', sans-serif" }}>{r.val}</span>
              </div>
            ))}
          </div>

          {/* Agreement */}
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold"
            style={{ background: 'rgba(21,101,192,0.08)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', cursor: 'pointer' }}>
            <FileText size={14} /> View Agreement
          </button>

          {/* Documents */}
          <div>
            <div className="text-xs font-bold uppercase tracking-widest mb-2"
              style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>Documents</div>
            <div className="rounded-xl p-3 grid grid-cols-2 gap-1.5"
              style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(255,255,255,0.72)' }}>
              {trainee.docs.map(d => (
                <div key={d.label} className="flex items-center gap-1.5">
                  <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: d.done ? 'rgba(22,163,74,0.15)' : 'rgba(229,57,53,0.12)', color: d.done ? '#15803D' : '#B91C1C' }}>
                    {d.done ? <Check size={9} /> : <X size={9} />}
                  </div>
                  <span className="text-xs" style={{ color: d.done ? '#15803D' : '#B91C1C', fontFamily: "'Exo 2', sans-serif" }}>{d.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Timeline */}
          <div>
            <div className="text-xs font-bold uppercase tracking-widest mb-3"
              style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>Timeline</div>
            {timeline.map((t, i) => (
              <div key={t.label} className="flex flex-col items-start">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs"
                    style={{ background: t.done ? 'rgba(22,163,74,0.15)' : 'rgba(202,138,4,0.12)', color: t.done ? '#15803D' : '#A16207', border: `1.5px solid ${t.done ? '#16a34a' : 'rgba(202,138,4,0.35)'}` }}>
                    {t.done ? <Check size={11} /> : <Clock size={11} />}
                  </div>
                  <span className="text-xs font-medium" style={{ color: t.done ? '#0D2B5E' : '#7A90A8', fontFamily: "'Exo 2', sans-serif" }}>{t.label}</span>
                </div>
                {i < timeline.length - 1 && <div className="ml-3 w-px h-5" style={{ background: 'rgba(21,101,192,0.15)' }} />}
              </div>
            ))}
          </div>
        </div>

        {/* Drawer footer actions */}
        <div className="p-5 flex flex-col gap-2 flex-shrink-0"
          style={{ borderTop: '1px solid rgba(21,101,192,0.10)' }}>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => { onAction(trainee.id, 'Approved'); onClose() }}
              disabled={trainee.status === 'Approved'}
              className="py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-1.5 text-white"
              style={{ background: trainee.status === 'Approved' ? '#e5e7eb' : 'linear-gradient(135deg,#16a34a,#15803D)', color: trainee.status === 'Approved' ? '#9ca3af' : '#fff', boxShadow: trainee.status !== 'Approved' ? '0 4px 16px rgba(22,163,74,0.30)' : 'none', border: 'none', cursor: trainee.status === 'Approved' ? 'not-allowed' : 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
              <Check size={13} /> Approve
            </button>
            <button
              onClick={() => { onAction(trainee.id, 'Rejected'); onClose() }}
              disabled={trainee.status === 'Rejected'}
              className="py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-1.5"
              style={{ background: trainee.status === 'Rejected' ? '#e5e7eb' : 'rgba(229,57,53,0.09)', border: `1px solid ${trainee.status === 'Rejected' ? '#e5e7eb' : 'rgba(229,57,53,0.25)'}`, color: trainee.status === 'Rejected' ? '#9ca3af' : '#B91C1C', cursor: trainee.status === 'Rejected' ? 'not-allowed' : 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
              <X size={13} /> Reject
            </button>
            <button
              onClick={() => { onAction(trainee.id, 'Pending'); onClose() }}
              disabled={trainee.status === 'Pending'}
              className="py-2.5 rounded-xl font-bold text-sm flex items-center justify-center gap-1.5"
              style={{ background: trainee.status === 'Pending' ? '#e5e7eb' : 'rgba(202,138,4,0.09)', border: `1px solid ${trainee.status === 'Pending' ? '#e5e7eb' : 'rgba(202,138,4,0.25)'}`, color: trainee.status === 'Pending' ? '#9ca3af' : '#A16207', cursor: trainee.status === 'Pending' ? 'not-allowed' : 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
              <Clock size={13} /> Pending
            </button>
          </div>
          <button onClick={() => onEdit(trainee)}
            className="w-full py-2.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: 'rgba(21,101,192,0.08)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', cursor: 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
            <Edit2 size={13} /> Edit
          </button>
          <button onClick={onClose} className="w-full py-2.5 rounded-xl font-semibold text-sm"
            style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(21,101,192,0.15)', color: '#4A6080', cursor: 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
            Close
          </button>
        </div>
      </div>
    </>
  )
}

/* ── Edit Drawer ───────────────────────────────────────────────────── */
function EditDrawer({ trainee, onClose, onSave }: {
  trainee: TraineeRow
  onClose: () => void
  onSave: (updated: TraineeRow) => void
}) {
  const [form, setForm] = useState({ ...trainee })
  const set = (k: keyof TraineeRow, v: string) => setForm(f => ({ ...f, [k]: v }))

  const field = (label: string, key: keyof TraineeRow, type = 'text') => (
    <div>
      <div className="text-xs font-semibold mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>{label}</div>
      <input
        type={type}
        value={String(form[key])}
        onChange={e => set(key, e.target.value)}
        className="w-full px-3 py-2 rounded-xl text-sm outline-none"
        style={{ background: 'rgba(255,255,255,0.70)', border: '1px solid rgba(21,101,192,0.22)', color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }}
      />
    </div>
  )

  return (
    <>
      <div className="fixed inset-0 z-40" style={{ background: 'rgba(13,43,94,0.28)', backdropFilter: 'blur(4px)' }} onClick={onClose} />
      <div className="fixed right-0 top-0 h-full z-50 flex flex-col overflow-y-auto"
        style={{ width: 420, background: 'rgba(255,255,255,0.90)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderLeft: '1px solid rgba(255,255,255,0.80)', boxShadow: '-8px 0 48px rgba(21,101,192,0.16)' }}>

        {/* Header */}
        <div className="flex-shrink-0 flex items-center justify-between px-5 py-4"
          style={{ background: 'linear-gradient(120deg,#C2470A,#F97316 60%,#fbbf24)', borderBottom: '1px solid rgba(255,255,255,0.20)' }}>
          <div>
            <div className="font-bold text-white text-base" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Edit Record</div>
            <div className="text-xs mt-0.5 font-mono" style={{ color: 'rgba(255,255,255,0.80)' }}>{trainee.code} · {trainee.name}</div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(255,255,255,0.20)', color: '#fff', border: '1px solid rgba(255,255,255,0.30)', cursor: 'pointer' }}>
            <X size={15} />
          </button>
        </div>

        {/* Form */}
        <div className="flex-1 p-5 space-y-4 overflow-y-auto">
          <div className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>Personal Info</div>
          <div className="rounded-xl p-4 space-y-3" style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(255,255,255,0.72)' }}>
            {field('Full Name', 'name')}
            {field('Mobile', 'mobile', 'tel')}
            {field('Email', 'email', 'email')}
            {field('Date of Birth', 'dob', 'date')}
            <div>
              <div className="text-xs font-semibold mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>Gender</div>
              <select value={form.gender} onChange={e => set('gender', e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-sm outline-none appearance-none"
                style={{ background: 'rgba(255,255,255,0.70)', border: '1px solid rgba(21,101,192,0.22)', color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }}>
                {['Male','Female','Other'].map(g => <option key={g}>{g}</option>)}
              </select>
            </div>
          </div>

          <div className="text-xs font-bold uppercase tracking-widest mt-2 mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>Program Info</div>
          <div className="rounded-xl p-4 space-y-3" style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(255,255,255,0.72)' }}>
            {field('Course', 'course')}
            <div>
              <div className="text-xs font-semibold mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>Scheme</div>
              <select value={form.scheme} onChange={e => set('scheme', e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-sm outline-none appearance-none"
                style={{ background: 'rgba(255,255,255,0.70)', border: '1px solid rgba(21,101,192,0.22)', color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }}>
                {['WILP','DVOC','NEEM','NAPS'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="text-xs font-bold uppercase tracking-widest mt-2 mb-1" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>Status</div>
          <div className="rounded-xl p-4" style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(255,255,255,0.72)' }}>
            <div className="flex gap-2">
              {(['Pending','Approved','Rejected'] as Status[]).map(s => (
                <button key={s} onClick={() => set('status', s)}
                  className="flex-1 py-2 rounded-xl text-xs font-bold"
                  style={{
                    background: form.status === s ? STATUS_CFG[s].bg : 'rgba(255,255,255,0.50)',
                    color: form.status === s ? STATUS_CFG[s].color : '#7A90A8',
                    border: `1.5px solid ${form.status === s ? STATUS_CFG[s].dot : 'rgba(21,101,192,0.12)'}`,
                    cursor: 'pointer', fontFamily: "'Exo 2',sans-serif",
                  }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-5 flex gap-3 flex-shrink-0" style={{ borderTop: '1px solid rgba(21,101,192,0.10)' }}>
          <button onClick={() => { onSave(form); onClose() }}
            className="flex-1 py-2.5 rounded-xl font-bold text-sm text-white"
            style={{ background: 'linear-gradient(135deg,#C2470A,#F97316)', boxShadow: '0 4px 16px rgba(249,115,22,0.30)', border: 'none', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            Save Changes
          </button>
          <button onClick={onClose}
            className="flex-1 py-2.5 rounded-xl font-semibold text-sm"
            style={{ background: 'rgba(255,255,255,0.65)', border: '1px solid rgba(21,101,192,0.15)', color: '#4A6080', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            Cancel
          </button>
        </div>
      </div>
    </>
  )
}

/* ── Props ─────────────────────────────────────────────────────────── */
interface Props {
  registrations: RecentRegistration[]
  onUpdateRegistration: (reg: RecentRegistration) => void
  onApprove: (id: string) => void
  onReject: (id: string) => void
  onNavigate: (screen: string) => void
}

/* ── Main Component ────────────────────────────────────────────────── */
export default function RecentRegistrations({ onNavigate }: Props) {
  const [data, setData] = useState<TraineeRow[]>(SAMPLE)

  /* Filters */
  const [filterScheme,  setFilterScheme]  = useState('All Schemes')
  const [filterZone,    setFilterZone]    = useState('All Zones')
  const [filterCompany, setFilterCompany] = useState('All Companies')
  const [filterStatus,  setFilterStatus]  = useState<typeof STATUSES[number]>('All')

  /* Search */
  const [searchCode,     setSearchCode]     = useState('')
  const [searchAadhaar,  setSearchAadhaar]  = useState('')
  const [appliedCode,    setAppliedCode]    = useState('')
  const [appliedAadhaar, setAppliedAadhaar] = useState('')

  /* Pagination */
  const [page,     setPage]     = useState(1)
  const [pageSize, setPageSize] = useState(5)

  /* Drawer */
  const [drawer,     setDrawer]     = useState<TraineeRow | null>(null)
  const [editDrawer, setEditDrawer] = useState<TraineeRow | null>(null)

  /* Zone-aware company list */
  const companyOptions = useMemo(() => {
    if (filterZone === 'All Zones') return ALL_ZONE_COMPANIES
    return ['All Companies', ...(ZONE_COMPANIES[filterZone] ?? [])]
  }, [filterZone])

  const handleZoneChange = (z: string) => { setFilterZone(z); setFilterCompany('All Companies'); setPage(1) }

  /* Filtering */
  const filtered = useMemo(() => data.filter(r => {
    if (filterScheme  !== 'All Schemes'   && r.scheme  !== filterScheme)  return false
    if (filterZone    !== 'All Zones'     && r.zone    !== filterZone)    return false
    if (filterCompany !== 'All Companies' && r.company !== filterCompany) return false
    if (filterStatus  !== 'All'           && r.status  !== filterStatus)  return false
    if (appliedCode    && !r.code.toLowerCase().includes(appliedCode.toLowerCase()))                         return false
    if (appliedAadhaar && !r.aadhaar.replace(/\s/g,'').includes(appliedAadhaar.replace(/\s/g,''))) return false
    return true
  }), [data, filterScheme, filterZone, filterCompany, filterStatus, appliedCode, appliedAadhaar])

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const pageData   = filtered.slice((page - 1) * pageSize, page * pageSize)

  const handleSearch = () => { setAppliedCode(searchCode); setAppliedAadhaar(searchAadhaar); setPage(1) }
  const handleReset  = () => {
    setFilterScheme('All Schemes'); setFilterZone('All Zones'); setFilterCompany('All Companies')
    setFilterStatus('All'); setSearchCode(''); setSearchAadhaar(''); setAppliedCode(''); setAppliedAadhaar(''); setPage(1)
  }

  const handleAction = (id: string, action: Status) => {
    setData(prev => prev.map(r => r.id === id ? { ...r, status: action } : r))
    if (drawer?.id === id) setDrawer(d => d ? { ...d, status: action } : d)
  }

  const handleSave = (updated: TraineeRow) => {
    setData(prev => prev.map(r => r.id === updated.id ? updated : r))
    if (drawer?.id === updated.id) setDrawer(updated)
  }

  /* Pagination page numbers */
  const pageNums = useMemo(() => {
    if (totalPages <= 5) return Array.from({ length: totalPages }, (_, i) => i + 1)
    if (page <= 3) return [1, 2, 3, 4, 5]
    if (page >= totalPages - 2) return [totalPages-4, totalPages-3, totalPages-2, totalPages-1, totalPages]
    return [page-2, page-1, page, page+1, page+2]
  }, [page, totalPages])

  return (
    <div className="space-y-6">

      {/* Profile Drawer */}
      {drawer && <ProfileDrawer trainee={drawer} onClose={() => setDrawer(null)} onAction={handleAction} onEdit={t => { setDrawer(null); setEditDrawer(t) }} />}
      {/* Edit Drawer */}
      {editDrawer && <EditDrawer trainee={editDrawer} onClose={() => setEditDrawer(null)} onSave={handleSave} />}

      {/* ── Banner ─────────────────────────────────────────── */}
      <div className="rounded-2xl p-5 relative overflow-hidden"
        style={{ background: 'linear-gradient(120deg,#1565C0 0%,#1976D2 55%,#F97316 100%)', boxShadow: '0 0 60px rgba(21,101,192,0.25), 0 8px 32px rgba(21,101,192,0.20)', border: '1px solid rgba(255,255,255,0.20)' }}>
        <div className="absolute right-0 top-0 w-56 h-56 rounded-full opacity-10 hidden sm:block" style={{ background: 'white', transform: 'translate(30%,-40%)' }} />
        <div className="relative z-10 flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-medium mb-1" style={{ color: 'rgba(255,255,255,0.80)', fontFamily: "'Exo 2', sans-serif" }}>Branch Center · Verification Module</p>
            <h1 className="text-xl md:text-2xl font-bold text-white" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Verification Queue</h1>
            <p className="text-sm mt-1 hidden sm:block" style={{ color: 'rgba(255,255,255,0.75)', fontFamily: "'Exo 2', sans-serif" }}>
              Verify trainee registrations, review documents, and update approval status.
            </p>
          </div>
          <button onClick={() => onNavigate('register')}
            className="flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold text-white"
            style={{ background: 'rgba(255,255,255,0.18)', border: '1.5px solid rgba(255,255,255,0.40)', backdropFilter: 'blur(8px)', fontFamily: 'Rajdhani, sans-serif', cursor: 'pointer', whiteSpace: 'nowrap' }}>
            <Plus size={14} /> New Registration
          </button>
        </div>
      </div>

      {/* ── Filters ────────────────────────────────────────── */}
      <div>
        <SectionTitle>Filters &amp; Search</SectionTitle>

        <div className="rounded-2xl p-5" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          {/* Row 1 — dropdowns */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
            <div className="relative">
              <select value={filterScheme} onChange={e => { setFilterScheme(e.target.value); setPage(1) }} style={SEL}>
                {SCHEMES.map(o => <option key={o}>{o}</option>)}
              </select>
              <ChevronDown size={13} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
            </div>
            <div className="relative">
              <select value={filterZone} onChange={e => handleZoneChange(e.target.value)} style={SEL}>
                {ZONE_LIST.map(o => <option key={o}>{o}</option>)}
              </select>
              <ChevronDown size={13} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
            </div>
            <div className="relative">
              <select value={filterCompany} onChange={e => { setFilterCompany(e.target.value); setPage(1) }} style={SEL}>
                {companyOptions.map(o => <option key={o}>{o}</option>)}
              </select>
              <ChevronDown size={13} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
            </div>
            <div className="relative">
              <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value as typeof STATUSES[number]); setPage(1) }} style={SEL}>
                {STATUSES.map(o => <option key={o}>{o === 'All' ? 'All Status' : o}</option>)}
              </select>
              <ChevronDown size={13} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
            </div>
          </div>

          {/* Row 2 — status radios */}
          <div className="flex items-center gap-5 flex-wrap mb-4">
            <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#4A6080', fontFamily: "'Exo 2', sans-serif" }}>Status:</span>
            {STATUSES.map(s => (
              <label key={s} className="flex items-center gap-1.5 cursor-pointer text-xs" style={{ color: '#1E3A5F', fontFamily: "'Exo 2', sans-serif" }}>
                <input type="radio" name="ver-status-radio" checked={filterStatus === s}
                  onChange={() => { setFilterStatus(s); setPage(1) }}
                  style={{ accentColor: '#1565C0' }} />
                {s}
              </label>
            ))}
          </div>

          {/* Row 3 — search */}
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[160px]">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#7A90A8' }} />
              <input value={searchCode} onChange={e => setSearchCode(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
                placeholder="Search by Trainee Code" style={INP} />
            </div>
            <div className="relative flex-1 min-w-[160px]">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#7A90A8' }} />
              <input value={searchAadhaar} onChange={e => setSearchAadhaar(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSearch()}
                placeholder="Search by Aadhaar Number" style={INP} />
            </div>
            <button onClick={handleSearch}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white flex-shrink-0"
              style={{ background: 'linear-gradient(135deg,#1565C0,#1976D2)', boxShadow: '0 4px 12px rgba(21,101,192,0.25)', fontFamily: "'Exo 2', sans-serif", cursor: 'pointer' }}>
              <Search size={12} /> Search
            </button>
            <button onClick={handleReset}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold"
              style={{ background: 'rgba(229,57,53,0.08)', border: '1px solid rgba(229,57,53,0.20)', color: '#B91C1C', fontFamily: "'Exo 2', sans-serif", cursor: 'pointer' }}>
              <RotateCcw size={12} /> Reset
            </button>
          </div>
        </div>
      </div>

      {/* ── Verification Table ──────────────────────────────── */}
      <div>
        <SectionTitle>Trainee Verification List</SectionTitle>

        <div className="rounded-2xl overflow-hidden" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          {/* Table header bar */}
          <div className="px-5 py-3 flex items-center justify-between"
            style={{ borderBottom: '1px solid rgba(21,101,192,0.08)' }}>
            <h3 className="font-bold text-sm" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani, sans-serif' }}>Verification Records</h3>
            <span className="text-xs px-3 py-1 rounded-full" style={{ background: 'rgba(21,101,192,0.08)', color: '#1565C0', fontFamily: "'Exo 2', sans-serif" }}>
              Total Records: <strong>{filtered.length}</strong>
            </span>
          </div>

          {/* Table */}
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
              <thead>
                <tr style={{ background: 'rgba(21,101,192,0.06)', borderBottom: '1px solid rgba(21,101,192,0.10)' }}>
                  {['#', 'Trainee Code', 'Trainee Name', 'Trainee Aadhar No', 'Company', 'Scheme', 'View Profile', 'Status', 'Action'].map(h => (
                    <th key={h} style={{ padding: '11px 14px', textAlign: ['#','View Profile','Status','Action'].includes(h) ? 'center' : 'left', fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: '#4A6080', fontFamily: "'Exo 2', sans-serif", whiteSpace: 'nowrap' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pageData.length === 0 ? (
                  <tr>
                    <td colSpan={9} style={{ padding: 48, textAlign: 'center', color: '#7A90A8', fontFamily: "'Exo 2', sans-serif", fontSize: 14 }}>
                      <AlertCircle size={28} style={{ margin: '0 auto 10px', display: 'block', color: '#B0BECE' }} />
                      No trainees match the current filters.
                    </td>
                  </tr>
                ) : pageData.map((t, idx) => {
                  const sc = STATUS_CFG[t.status]
                  const rowNum = (page - 1) * pageSize + idx + 1
                  return (
                    <tr key={t.id}
                      style={{ borderBottom: '1px solid rgba(21,101,192,0.06)', transition: 'background 0.15s' }}
                      onMouseEnter={e => (e.currentTarget.style.background = 'rgba(21,101,192,0.035)')}
                      onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                      <td style={{ padding: '11px 14px', textAlign: 'center', fontSize: 13, color: '#7A90A8', fontFamily: "'Exo 2', sans-serif" }}>{rowNum}</td>
                      <td style={{ padding: '11px 14px', fontSize: 12, color: '#1565C0', fontFamily: 'JetBrains Mono, monospace', fontWeight: 600, whiteSpace: 'nowrap' }}>{t.code}</td>
                      <td style={{ padding: '11px 14px', fontSize: 13, color: '#0D2B5E', fontFamily: "'Exo 2', sans-serif", fontWeight: 600, whiteSpace: 'nowrap' }}>{t.name}</td>
                      <td style={{ padding: '11px 14px', fontSize: 12, color: '#4A6080', fontFamily: 'JetBrains Mono, monospace', whiteSpace: 'nowrap' }}>{t.aadhaar}</td>
                      <td style={{ padding: '11px 14px', fontSize: 12, color: '#1E3A5F', fontFamily: "'Exo 2', sans-serif", maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.company}</td>
                      <td style={{ padding: '11px 14px', textAlign: 'center' }}>
                        <span style={{ padding: '3px 10px', borderRadius: 20, background: 'rgba(21,101,192,0.08)', color: '#1565C0', fontFamily: "'Exo 2', sans-serif", fontSize: 12, fontWeight: 600 }}>{t.scheme}</span>
                      </td>
                      <td style={{ padding: '11px 14px', textAlign: 'center' }}>
                        <button onClick={() => setDrawer(t)}
                          className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold"
                          style={{ background: 'rgba(21,101,192,0.09)', color: '#1565C0', border: '1px solid rgba(21,101,192,0.18)', fontFamily: "'Exo 2', sans-serif", cursor: 'pointer', margin: '0 auto' }}>
                          <Eye size={11} /> View Profile
                        </button>
                      </td>
                      <td style={{ padding: '11px 14px', textAlign: 'center' }}>
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold"
                          style={{ background: sc.bg, color: sc.color, whiteSpace: 'nowrap' }}>
                          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: sc.dot }} />
                          {t.status}
                        </span>
                      </td>
                      <td style={{ padding: '9px 14px', textAlign: 'center' }}>
                        <div className="inline-flex items-center gap-1 flex-wrap justify-center">
                          <button onClick={() => handleAction(t.id, 'Approved')}
                            disabled={t.status === 'Approved'}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold"
                            style={{ background: t.status==='Approved'?'rgba(21,101,192,0.03)':'rgba(22,163,74,0.10)', color: t.status==='Approved'?'#B0BECE':'#15803D', border: `1px solid ${t.status==='Approved'?'rgba(21,101,192,0.08)':'rgba(22,163,74,0.20)'}`, fontFamily:"'Exo 2',sans-serif", cursor: t.status==='Approved'?'not-allowed':'pointer' }}>
                            <Check size={10} /> Approve
                          </button>
                          <button onClick={() => handleAction(t.id, 'Rejected')}
                            disabled={t.status === 'Rejected'}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold"
                            style={{ background: t.status==='Rejected'?'rgba(21,101,192,0.03)':'rgba(229,57,53,0.08)', color: t.status==='Rejected'?'#B0BECE':'#B91C1C', border: `1px solid ${t.status==='Rejected'?'rgba(21,101,192,0.08)':'rgba(229,57,53,0.18)'}`, fontFamily:"'Exo 2',sans-serif", cursor: t.status==='Rejected'?'not-allowed':'pointer' }}>
                            <X size={10} /> Reject
                          </button>
                          <button onClick={() => setEditDrawer(t)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold"
                            style={{ background: 'rgba(249,115,22,0.09)', color: '#C2470A', border: '1px solid rgba(249,115,22,0.20)', fontFamily:"'Exo 2',sans-serif", cursor: 'pointer' }}>
                            <Edit2 size={10} /> Edit
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between px-5 py-3 flex-wrap gap-2"
            style={{ borderTop: '1px solid rgba(21,101,192,0.07)' }}>
            {/* Show entries */}
            <div className="flex items-center gap-2" style={{ fontFamily: "'Exo 2', sans-serif", fontSize: 12, color: '#7A90A8' }}>
              <span>Show</span>
              <div style={{ position: 'relative' }}>
                <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setPage(1) }}
                  style={{ padding: '4px 24px 4px 8px', borderRadius: 8, border: '1px solid rgba(21,101,192,0.20)', background: 'rgba(255,255,255,0.65)', fontSize: 12, fontFamily: "'Exo 2', sans-serif", color: '#0D2B5E', appearance: 'none', outline: 'none', cursor: 'pointer' }}>
                  {PAGE_SIZES.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <ChevronDown size={10} style={{ position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)', color: '#7A90A8', pointerEvents: 'none' }} />
              </div>
              <span>of <strong style={{ color: '#1E3A5F' }}>{filtered.length}</strong> records</span>
            </div>

            {/* Page buttons */}
            <div className="flex items-center gap-1">
              <PagBtn onClick={() => setPage(1)} disabled={page===1}><ChevronsLeft size={12} /> First</PagBtn>
              <PagBtn onClick={() => setPage(p => Math.max(1,p-1))} disabled={page===1}><ChevronLeft size={12} /> Prev</PagBtn>
              {pageNums.map(n => (
                <button key={n} onClick={() => setPage(n)}
                  className="w-8 h-8 rounded-lg text-xs font-bold"
                  style={{ background: page===n ? 'linear-gradient(135deg,#1565C0,#1976D2)' : 'rgba(255,255,255,0.65)', color: page===n ? '#fff' : '#1E3A5F', border: page===n ? 'none' : '1px solid rgba(21,101,192,0.15)', boxShadow: page===n ? '0 4px 12px rgba(21,101,192,0.25)' : 'none', cursor: 'pointer' }}>
                  {n}
                </button>
              ))}
              {totalPages > 5 && page < totalPages - 2 && <span style={{ color: '#B0BECE', padding: '0 2px', fontSize: 12 }}>…</span>}
              {totalPages > 5 && page < totalPages - 1 && (
                <button onClick={() => setPage(totalPages)}
                  className="w-8 h-8 rounded-lg text-xs font-bold"
                  style={{ background: 'rgba(255,255,255,0.65)', color: '#1E3A5F', border: '1px solid rgba(21,101,192,0.15)', cursor: 'pointer' }}>
                  {totalPages}
                </button>
              )}
              <PagBtn onClick={() => setPage(p => Math.min(totalPages,p+1))} disabled={page===totalPages}>Next <ChevronRight size={12} /></PagBtn>
              <PagBtn onClick={() => setPage(totalPages)} disabled={page===totalPages}>Last <ChevronsRight size={12} /></PagBtn>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function PagBtn({ children, onClick, disabled }: { children: React.ReactNode; onClick: () => void; disabled: boolean }) {
  return (
    <button onClick={onClick} disabled={disabled}
      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold"
      style={{ background: disabled?'transparent':'rgba(21,101,192,0.09)', color: disabled?'#B0BECE':'#1565C0', border:`1px solid ${disabled?'rgba(21,101,192,0.08)':'rgba(21,101,192,0.20)'}`, fontFamily:"'Exo 2',sans-serif", cursor: disabled?'not-allowed':'pointer', whiteSpace: 'nowrap' }}>
      {children}
    </button>
  )
}

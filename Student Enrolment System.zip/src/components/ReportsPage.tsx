import { useState, useMemo } from 'react'
import type React from 'react'
import { ZONE_COMPANIES, ZONE_LIST, ALL_ZONE_COMPANIES } from '@/data/indiaGeo'
import {
  Search, Download, ChevronDown, X, Filter, BarChart2,
  TrendingUp, Users, CheckCircle, Clock, XCircle, FolderOpen,
} from 'lucide-react'

/* ── Shared glass styles ───────────────────────────────────────────── */
const GLASS: React.CSSProperties = {
  background: 'rgba(255,255,255,0.72)',
  backdropFilter: 'blur(18px) saturate(130%)',
  WebkitBackdropFilter: 'blur(18px) saturate(130%)',
  border: '1px solid rgba(255,255,255,0.80)',
}
const CARD_SHADOW = '0 4px 24px rgba(21,101,192,0.10), 0 1.5px 6px rgba(0,0,0,0.06)'
const SEL: React.CSSProperties = { ...GLASS, color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', outline: 'none', appearance: 'none' as const }

const SCHEMES = ['All Schemes', 'WILP', 'BVOC', 'DVOC', 'FLEXI', 'MSBTE', 'NEEM', 'NAPS'] as const
const STATUSES = ['All', 'Approved', 'Pending', 'Rejected'] as const
type Status = 'Approved' | 'Pending' | 'Rejected'
type GroupBy = 'zone' | 'company' | 'scheme'

const STATUS_CFG: Record<Status, { bg: string; color: string; dot: string }> = {
  Approved: { bg: 'rgba(22,163,74,0.12)',  color: '#15803D', dot: '#16a34a' },
  Pending:  { bg: 'rgba(202,138,4,0.12)',  color: '#A16207', dot: '#ca8a04' },
  Rejected: { bg: 'rgba(229,57,53,0.12)', color: '#B91C1C', dot: '#E53935' },
}

/* ── Trainee data ──────────────────────────────────────────────────── */
interface Trainee {
  id: string; code: string; name: string; aadhaar: string
  company: string; zone: string; scheme: string; status: Status
  mobile: string; email: string; course: string; enrolled: string; batch: string
  payroll: boolean; attendance: number; score: number
  docs: { label: string; done: boolean }[]
}

const TRAINEES: Trainee[] = [
  { id:'1',  code:'TRN000154', name:'Rahul Sharma',    aadhaar:'XXXX XXXX 1234', company:'Amber Enterprises India Limited, Supa',   zone:'Ahilya Nagar',       scheme:'WILP',  status:'Pending',  mobile:'9812345678', email:'rahul.sharma@email.com',   course:'Electrician General',           enrolled:'2026-07-01', batch:'Batch-03', payroll:false, attendance:72, score:61, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'2',  code:'TRN000155', name:'Sneha Patil',     aadhaar:'XXXX XXXX 2568', company:'Mahindra & Mahindra Ltd, Nashik',          zone:'Nashik',             scheme:'BVOC',  status:'Approved', mobile:'9823456789', email:'sneha.patil@email.com',    course:'CNC Operator',                  enrolled:'2026-06-15', batch:'Batch-01', payroll:true,  attendance:95, score:88, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'3',  code:'TRN000156', name:'Amit Kumar',      aadhaar:'XXXX XXXX 4589', company:'Bajaj Auto Ltd, Pune',                    zone:'Pune',               scheme:'WILP',  status:'Rejected', mobile:'9834567890', email:'amit.kumar@email.com',     course:'Welder (FCAW)',                 enrolled:'2026-07-10', batch:'—',        payroll:false, attendance:40, score:35, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'4',  code:'TRN000157', name:'Pooja Singh',     aadhaar:'XXXX XXXX 7896', company:'Bharat Forge Limited, Pune',              zone:'Pune',               scheme:'DVOC',  status:'Pending',  mobile:'9845678901', email:'pooja.singh@email.com',    course:'Solar PV Technician',           enrolled:'2026-07-12', batch:'Batch-02', payroll:true,  attendance:80, score:74, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:true}] },
  { id:'5',  code:'TRN000158', name:'Vikash Yadav',    aadhaar:'XXXX XXXX 1478', company:'Endurance Technologies Limited',          zone:'Chh. Sambhajinagar', scheme:'FLEXI', status:'Pending',  mobile:'9856789012', email:'vikash.yadav@email.com',   course:'Plumber General',               enrolled:'2026-07-15', batch:'—',        payroll:false, attendance:55, score:50, docs:[{label:'Aadhaar',done:false},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'6',  code:'TRN000159', name:'Priya Nair',      aadhaar:'XXXX XXXX 3321', company:'Gilbarco Veeder Root India Pvt. Ltd.',   zone:'Coimbatore',         scheme:'MSBTE', status:'Approved', mobile:'9867890123', email:'priya.nair@email.com',     course:'AC & Refrigeration Technician', enrolled:'2026-06-20', batch:'Batch-01', payroll:true,  attendance:98, score:92, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'7',  code:'TRN000160', name:'Sanjay Mehta',    aadhaar:'XXXX XXXX 9012', company:'Hero MotoCorp Ltd, Haridwar',            zone:'Haridwar',           scheme:'WILP',  status:'Pending',  mobile:'9878901234', email:'sanjay.mehta@email.com',   course:'Data Entry Operator',           enrolled:'2026-07-18', batch:'Batch-02', payroll:true,  attendance:68, score:62, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'8',  code:'TRN000161', name:'Kavitha Reddy',   aadhaar:'XXXX XXXX 6543', company:'Hyundai Motor India Ltd, Chennai',      zone:'Chennai',            scheme:'BVOC',  status:'Approved', mobile:'9889012345', email:'kavitha.reddy@email.com',  course:'Retail Sales Associate',        enrolled:'2026-06-10', batch:'Batch-01', payroll:true,  attendance:100,score:96, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'9',  code:'TRN000162', name:'Deepak Joshi',    aadhaar:'XXXX XXXX 2109', company:'Amber Enterprises India Limited, Supa',  zone:'Ahilya Nagar',      scheme:'DVOC',  status:'Rejected', mobile:'9890123456', email:'deepak.joshi@email.com',   course:'Electrician General',           enrolled:'2026-07-05', batch:'—',        payroll:false, attendance:20, score:18, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:false},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'10', code:'TRN000163', name:'Anjali Sharma',   aadhaar:'XXXX XXXX 8765', company:'Tata Steel Ltd, Jamshedpur',            zone:'Jamshedpur',         scheme:'MSBTE', status:'Pending',  mobile:'9801234567', email:'anjali.sharma@email.com',  course:'Beauty Therapist',              enrolled:'2026-07-20', batch:'Batch-03', payroll:true,  attendance:85, score:78, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'11', code:'TRN000164', name:'Rajan Verma',     aadhaar:'XXXX XXXX 4410', company:'Maruti Suzuki India Ltd, Gurgaon',     zone:'NCR Haryana',        scheme:'WILP',  status:'Approved', mobile:'9812345670', email:'rajan.verma@email.com',    course:'CNC Operator',                  enrolled:'2026-06-25', batch:'Batch-01', payroll:true,  attendance:92, score:85, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'12', code:'TRN000165', name:'Meena Kumari',    aadhaar:'XXXX XXXX 3322', company:'Samsung India Electronics Pvt. Ltd.',  zone:'NCR Noida',          scheme:'FLEXI', status:'Pending',  mobile:'9823456780', email:'meena.kumari@email.com',   course:'Data Entry Operator',           enrolled:'2026-07-22', batch:'Batch-02', payroll:false, attendance:60, score:55, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'13', code:'TRN000166', name:'Arjun Patel',     aadhaar:'XXXX XXXX 5511', company:'Bosch Ltd, Nashik',                    zone:'Nashik',             scheme:'NEEM',  status:'Approved', mobile:'9834567801', email:'arjun.patel@email.com',    course:'Fitter General',                enrolled:'2026-07-25', batch:'Batch-01', payroll:true,  attendance:90, score:83, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'14', code:'TRN000167', name:'Divya Menon',     aadhaar:'XXXX XXXX 6622', company:'TVS Motor Company, Chennai',           zone:'Chennai',            scheme:'NAPS',  status:'Approved', mobile:'9845678912', email:'divya.menon@email.com',    course:'Mechanic Motor Vehicle',        enrolled:'2026-07-28', batch:'Batch-01', payroll:true,  attendance:97, score:91, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'15', code:'TRN000168', name:'Kiran Rao',       aadhaar:'XXXX XXXX 7733', company:'Wipro Infrastructure Engineering',    zone:'Pune',               scheme:'BVOC',  status:'Pending',  mobile:'9856789023', email:'kiran.rao@email.com',       course:'Instrumentation Technician',    enrolled:'2026-08-01', batch:'Batch-03', payroll:false, attendance:65, score:58, docs:[{label:'Aadhaar',done:false},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'16', code:'TRN000169', name:'Suresh Babu',     aadhaar:'XXXX XXXX 8844', company:'L&T Construction Equipment Ltd',      zone:'NCR Haryana',        scheme:'WILP',  status:'Approved', mobile:'9867890134', email:'suresh.babu@email.com',    course:'Welder (SMAW)',                 enrolled:'2026-08-03', batch:'Batch-02', payroll:true,  attendance:88, score:80, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:true}] },
  { id:'17', code:'TRN000170', name:'Rekha Iyer',      aadhaar:'XXXX XXXX 9955', company:'Cummins India Ltd, Pune',             zone:'Pune',               scheme:'DVOC',  status:'Approved', mobile:'9878901245', email:'rekha.iyer@email.com',     course:'AC & Refrigeration Technician', enrolled:'2026-08-05', batch:'Batch-01', payroll:true,  attendance:94, score:89, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
  { id:'18', code:'TRN000171', name:'Anil Chaudhari',  aadhaar:'XXXX XXXX 1166', company:'Tata Motors Ltd, Pune',               zone:'Pune',               scheme:'MSBTE', status:'Pending',  mobile:'9889012356', email:'anil.chaudhari@email.com', course:'Mechanic Diesel',               enrolled:'2026-08-07', batch:'Batch-03', payroll:true,  attendance:75, score:68, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:false},{label:'Marksheet',done:true},{label:'Bank Passbook',done:false},{label:'Offer Letter',done:false}] },
  { id:'19', code:'TRN000172', name:'Sunita Desai',    aadhaar:'XXXX XXXX 2277', company:'Kirloskar Electric Co. Ltd',          zone:'Ahilya Nagar',       scheme:'FLEXI', status:'Pending',  mobile:'9890123467', email:'sunita.desai@email.com',   course:'Electrician General',           enrolled:'2026-08-09', batch:'—',        payroll:false, attendance:50, score:45, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:false},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:false}] },
  { id:'20', code:'TRN000173', name:'Manoj Tiwari',    aadhaar:'XXXX XXXX 3388', company:'Ashok Leyland Ltd, Chennai',          zone:'Chennai',            scheme:'NEEM',  status:'Approved', mobile:'9801234578', email:'manoj.tiwari@email.com',   course:'Fitter General',                enrolled:'2026-08-10', batch:'Batch-02', payroll:true,  attendance:93, score:87, docs:[{label:'Aadhaar',done:true},{label:'Photo',done:true},{label:'Marksheet',done:true},{label:'Bank Passbook',done:true},{label:'Offer Letter',done:true}] },
]

function exportCSV(data: Trainee[], label = 'all') {
  const headers = ['#', 'Code', 'Name', 'Aadhaar', 'Zone', 'Company', 'Scheme', 'Course', 'Batch', 'Status', 'Payroll', 'Attendance%', 'Score', 'Enrolled']
  const rows = data.map((t, i) => [i + 1, t.code, t.name, t.aadhaar, t.zone, t.company, t.scheme, t.course, t.batch, t.status, t.payroll ? 'Yes' : 'No', t.attendance, t.score, t.enrolled])
  const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n')
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `report-${label.replace(/[^a-z0-9]/gi, '-').toLowerCase()}-${new Date().toISOString().slice(0, 10)}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

export default function ReportsPage() {
  const [groupBy,   setGroupBy]   = useState<GroupBy>('zone')
  const [zone,      setZone]      = useState('All Zones')
  const [company,   setCompany]   = useState('All Companies')
  const [scheme,    setScheme]    = useState('All Schemes')
  const [status,    setStatus]    = useState<typeof STATUSES[number]>('All')
  const [search,    setSearch]    = useState('')
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set())

  const companyOptions = useMemo(() => {
    if (zone === 'All Zones') return ALL_ZONE_COMPANIES
    return ['All Companies', ...(ZONE_COMPANIES[zone] ?? [])]
  }, [zone])

  const filtered = useMemo(() => TRAINEES.filter(t => {
    if (zone    !== 'All Zones'     && t.zone    !== zone)    return false
    if (company !== 'All Companies' && t.company !== company) return false
    if (scheme  !== 'All Schemes'   && t.scheme  !== scheme)  return false
    if (status  !== 'All'           && t.status  !== status)  return false
    if (search && !t.name.toLowerCase().includes(search.toLowerCase()) &&
                  !t.code.toLowerCase().includes(search.toLowerCase())) return false
    return true
  }), [zone, company, scheme, status, search])

  const groups = useMemo(() => {
    const map = new Map<string, Trainee[]>()
    filtered.forEach(t => {
      const key = t[groupBy]
      if (!map.has(key)) map.set(key, [])
      map.get(key)!.push(t)
    })
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0]))
  }, [filtered, groupBy])

  const toggle = (key: string) => setCollapsed(s => {
    const n = new Set(s); n.has(key) ? n.delete(key) : n.add(key); return n
  })

  const approved  = filtered.filter(t => t.status === 'Approved').length
  const pending   = filtered.filter(t => t.status === 'Pending').length
  const rejected  = filtered.filter(t => t.status === 'Rejected').length
  const onPayroll = filtered.filter(t => t.payroll).length
  const avgAtt    = filtered.length ? Math.round(filtered.reduce((s,t) => s+t.attendance, 0) / filtered.length) : 0
  const avgScore  = filtered.length ? Math.round(filtered.reduce((s,t) => s+t.score,      0) / filtered.length) : 0

  return (
    <div className="space-y-6">

      {/* Banner */}
      <div className="rounded-2xl p-5 relative overflow-hidden"
        style={{ background: 'linear-gradient(120deg,#5b21b6 0%,#7c3aed 50%,#1565C0 100%)', boxShadow: '0 0 60px rgba(124,58,237,0.25), 0 8px 32px rgba(21,101,192,0.20)', border: '1px solid rgba(255,255,255,0.20)' }}>
        <div className="absolute right-0 top-0 w-56 h-56 rounded-full opacity-10" style={{ background: 'white', transform: 'translate(30%,-40%)' }} />
        <div className="relative z-10 flex items-start justify-between gap-4 flex-wrap">
          <div>
            <p className="text-xs font-medium mb-1" style={{ color: 'rgba(255,255,255,0.80)', fontFamily: "'Exo 2',sans-serif" }}>Branch Center · Analytics & Reports</p>
            <h1 className="text-2xl font-black text-white" style={{ fontFamily: 'Rajdhani,sans-serif' }}>Trainee Reports</h1>
            <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.85)', fontFamily: "'Exo 2',sans-serif" }}>
              {filtered.length} trainees · Avg attendance {avgAtt}% · Avg score {avgScore}%
            </p>
          </div>
          <div className="flex gap-3 flex-wrap">
            {[
              { label: 'Total',    val: String(filtered.length), color: '#fff',     Icon: Users },
              { label: 'Approved', val: String(approved),        color: '#bbf7d0',  Icon: CheckCircle },
              { label: 'Pending',  val: String(pending),         color: '#fde68a',  Icon: Clock },
              { label: 'Rejected', val: String(rejected),        color: '#fca5a5',  Icon: XCircle },
              { label: 'Payroll',  val: String(onPayroll),       color: '#c4b5fd',  Icon: TrendingUp },
            ].map(c => (
              <div key={c.label} className="px-4 py-2 rounded-xl text-center" style={{ background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.25)' }}>
                <div className="text-lg font-black" style={{ color: c.color, fontFamily: 'Rajdhani,sans-serif' }}>{c.val}</div>
                <div className="text-xs" style={{ color: 'rgba(255,255,255,0.75)', fontFamily: "'Exo 2',sans-serif" }}>{c.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="rounded-2xl p-4" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
        <div className="flex flex-wrap gap-3 items-center">

          {/* Group by tabs */}
          <div className="flex rounded-xl overflow-hidden" style={{ border: '1px solid rgba(21,101,192,0.20)' }}>
            {(['zone','company','scheme'] as GroupBy[]).map(g => (
              <button key={g} onClick={() => setGroupBy(g)}
                className="px-4 py-2 text-xs font-bold capitalize transition-all"
                style={{
                  background: groupBy === g ? 'linear-gradient(135deg,#7c3aed,#1565C0)' : 'transparent',
                  color: groupBy === g ? '#fff' : '#4A6080',
                  fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', border: 'none',
                }}>
                By {g.charAt(0).toUpperCase() + g.slice(1)}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 flex-1 min-w-48 px-3 py-2 rounded-xl"
            style={{ ...GLASS, border: '1px solid rgba(21,101,192,0.18)' }}>
            <Search size={13} style={{ color: '#7A90A8' }} />
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search trainee name or code…"
              className="flex-1 bg-transparent outline-none text-sm"
              style={{ color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }} />
            {search && <button onClick={() => setSearch('')}><X size={12} style={{ color: '#7A90A8', cursor: 'pointer' }} /></button>}
          </div>

          <div className="relative">
            <select value={zone} onChange={e => { setZone(e.target.value); setCompany('All Companies') }}
              className="pl-3 pr-8 py-2 rounded-xl text-sm" style={SEL}>
              <option>All Zones</option>
              {ZONE_LIST.map(z => <option key={z}>{z}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#4A6080' }} />
          </div>

          <div className="relative">
            <select value={company} onChange={e => setCompany(e.target.value)}
              className="pl-3 pr-8 py-2 rounded-xl text-sm" style={{ ...SEL, maxWidth: 220 }}>
              {companyOptions.map(c => <option key={c}>{c}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#4A6080' }} />
          </div>

          <div className="relative">
            <select value={scheme} onChange={e => setScheme(e.target.value)}
              className="pl-3 pr-8 py-2 rounded-xl text-sm" style={SEL}>
              {SCHEMES.map(s => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#4A6080' }} />
          </div>

          <div className="relative">
            <select value={status} onChange={e => setStatus(e.target.value as typeof STATUSES[number])}
              className="pl-3 pr-8 py-2 rounded-xl text-sm" style={SEL}>
              {STATUSES.map(s => <option key={s}>{s}</option>)}
            </select>
            <ChevronDown size={12} className="absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" style={{ color: '#4A6080' }} />
          </div>

          <button onClick={() => { setZone('All Zones'); setCompany('All Companies'); setScheme('All Schemes'); setStatus('All'); setSearch('') }}
            className="px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5"
            style={{ background: 'rgba(249,115,22,0.09)', color: '#C2470A', border: '1px solid rgba(249,115,22,0.20)', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            <Filter size={11} /> Reset
          </button>

          <button onClick={() => exportCSV(filtered, `${groupBy}-grouped`)}
            className="px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 text-white"
            style={{ background: 'linear-gradient(135deg,#15803D,#16a34a)', boxShadow: '0 3px 10px rgba(22,163,74,0.25)', border: 'none', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif" }}>
            <Download size={11} /> Export CSV
          </button>
        </div>
      </div>

      {/* Summary stat tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Total Trainees',  val: filtered.length,  unit: '',  color: '#1565C0', bg: 'rgba(21,101,192,0.10)'  },
          { label: 'Approved',        val: approved,          unit: '',  color: '#15803D', bg: 'rgba(22,163,74,0.10)'   },
          { label: 'Pending',         val: pending,           unit: '',  color: '#A16207', bg: 'rgba(202,138,4,0.10)'   },
          { label: 'Rejected',        val: rejected,          unit: '',  color: '#B91C1C', bg: 'rgba(229,57,53,0.10)'   },
          { label: 'Avg Attendance',  val: avgAtt,            unit: '%', color: '#7c3aed', bg: 'rgba(124,58,237,0.10)'  },
          { label: 'Avg Score',       val: avgScore,          unit: '%', color: '#C2470A', bg: 'rgba(249,115,22,0.10)'  },
        ].map(s => (
          <div key={s.label} className="rounded-2xl p-4 text-center" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
            <div className="text-2xl font-black mb-1" style={{ color: s.color, fontFamily: 'Rajdhani,sans-serif' }}>{s.val}{s.unit}</div>
            <div className="text-xs font-semibold" style={{ color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Grouped tables */}
      {groups.length === 0 ? (
        <div className="rounded-2xl p-12 text-center" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
          <BarChart2 size={36} style={{ color: '#B0BECE', margin: '0 auto 12px' }} />
          <div className="text-base font-bold" style={{ color: '#4A6080', fontFamily: 'Rajdhani,sans-serif' }}>No records match the current filters</div>
        </div>
      ) : groups.map(([groupKey, members]) => {
        const isOpen = !collapsed.has(groupKey)
        const grpApproved  = members.filter(t => t.status === 'Approved').length
        const grpPending   = members.filter(t => t.status === 'Pending').length
        const grpRejected  = members.filter(t => t.status === 'Rejected').length
        const grpAvgAtt    = Math.round(members.reduce((s,t) => s+t.attendance, 0) / members.length)

        return (
          <div key={groupKey} className="rounded-2xl overflow-hidden" style={{ ...GLASS, boxShadow: CARD_SHADOW }}>
            {/* Group header */}
            <div className="flex items-center justify-between px-5 py-4"
              style={{ background: 'rgba(124,58,237,0.05)', borderBottom: isOpen ? '1px solid rgba(21,101,192,0.10)' : 'none' }}>
              <div className="flex items-center gap-3 flex-wrap flex-1 cursor-pointer" onClick={() => toggle(groupKey)}>
                <FolderOpen size={16} style={{ color: '#7c3aed' }} />
                <span className="font-bold text-base" style={{ color: '#0D2B5E', fontFamily: 'Rajdhani,sans-serif' }}>{groupKey}</span>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold"
                  style={{ background: 'rgba(21,101,192,0.12)', color: '#1565C0', fontFamily: "'Exo 2',sans-serif" }}>
                  {members.length} trainees
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold"
                  style={{ background: 'rgba(22,163,74,0.12)', color: '#15803D', fontFamily: "'Exo 2',sans-serif" }}>
                  {grpApproved} approved
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold"
                  style={{ background: 'rgba(202,138,4,0.12)', color: '#A16207', fontFamily: "'Exo 2',sans-serif" }}>
                  {grpPending} pending
                </span>
                {grpRejected > 0 && (
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold"
                    style={{ background: 'rgba(229,57,53,0.12)', color: '#B91C1C', fontFamily: "'Exo 2',sans-serif" }}>
                    {grpRejected} rejected
                  </span>
                )}
                <span className="text-xs px-2.5 py-0.5 rounded-full font-semibold"
                  style={{ background: 'rgba(124,58,237,0.10)', color: '#7c3aed', fontFamily: "'Exo 2',sans-serif" }}>
                  Avg att. {grpAvgAtt}%
                </span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={() => exportCSV(members, groupKey)}
                  className="flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg text-white"
                  style={{ background: 'linear-gradient(135deg,#15803D,#16a34a)', cursor: 'pointer', fontFamily: "'Exo 2',sans-serif", border: 'none' }}>
                  <Download size={10} /> Export
                </button>
                <div onClick={() => toggle(groupKey)} style={{ cursor: 'pointer' }}>
                  <ChevronDown size={16} style={{ color: '#4A6080', transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }} />
                </div>
              </div>
            </div>

            {isOpen && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'rgba(124,58,237,0.04)' }}>
                      {['#','Code','Trainee','Zone','Company','Scheme','Course','Batch','Status','Payroll','Attendance','Score','Enrolled'].map(h => (
                        <th key={h} className="px-3 py-3 text-left text-xs font-bold uppercase tracking-wider whitespace-nowrap"
                          style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif", borderBottom: '1px solid rgba(21,101,192,0.08)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {members.map((t, idx) => {
                      const sc = STATUS_CFG[t.status]
                      const attColor = t.attendance >= 80 ? '#15803D' : t.attendance >= 60 ? '#A16207' : '#B91C1C'
                      const attBg    = t.attendance >= 80 ? 'rgba(22,163,74,0.10)' : t.attendance >= 60 ? 'rgba(202,138,4,0.10)' : 'rgba(229,57,53,0.10)'
                      return (
                        <tr key={t.id} className="border-t transition-colors"
                          style={{ borderColor: 'rgba(21,101,192,0.07)' }}
                          onMouseEnter={e => (e.currentTarget.style.background = 'rgba(124,58,237,0.03)')}
                          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                          <td className="px-3 py-3 text-xs font-mono" style={{ color: '#7A90A8' }}>{String(idx + 1).padStart(2, '0')}</td>
                          <td className="px-3 py-3">
                            <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'rgba(21,101,192,0.10)', color: '#1565C0' }}>{t.code}</span>
                          </td>
                          <td className="px-3 py-3 font-semibold whitespace-nowrap" style={{ color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif" }}>{t.name}</td>
                          <td className="px-3 py-3 text-xs whitespace-nowrap" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>{t.zone}</td>
                          <td className="px-3 py-3 text-xs" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif", maxWidth: 180 }}>{t.company}</td>
                          <td className="px-3 py-3">
                            <span className="text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'rgba(124,58,237,0.10)', color: '#7c3aed', fontFamily: "'Exo 2',sans-serif" }}>{t.scheme}</span>
                          </td>
                          <td className="px-3 py-3 text-xs whitespace-nowrap" style={{ color: '#4A6080', fontFamily: "'Exo 2',sans-serif" }}>{t.course}</td>
                          <td className="px-3 py-3 text-xs font-mono" style={{ color: '#4A6080' }}>{t.batch}</td>
                          <td className="px-3 py-3">
                            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold whitespace-nowrap"
                              style={{ background: sc.bg, color: sc.color, fontFamily: "'Exo 2',sans-serif" }}>
                              <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: sc.dot }} />{t.status}
                            </span>
                          </td>
                          <td className="px-3 py-3 text-center">
                            <span className="text-xs font-bold px-2 py-1 rounded-lg"
                              style={{ background: t.payroll ? 'rgba(22,163,74,0.10)' : 'rgba(229,57,53,0.08)', color: t.payroll ? '#15803D' : '#B91C1C', fontFamily: "'Exo 2',sans-serif" }}>
                              {t.payroll ? 'Yes' : 'No'}
                            </span>
                          </td>
                          <td className="px-3 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-16 h-1.5 rounded-full" style={{ background: 'rgba(21,101,192,0.10)' }}>
                                <div className="h-1.5 rounded-full" style={{ width: `${t.attendance}%`, background: attColor }} />
                              </div>
                              <span className="text-xs font-bold" style={{ color: attColor, fontFamily: "'Exo 2',sans-serif" }}>{t.attendance}%</span>
                            </div>
                          </td>
                          <td className="px-3 py-3">
                            <span className="text-xs font-bold px-2 py-1 rounded-lg" style={{ background: attBg, color: attColor, fontFamily: "'Exo 2',sans-serif" }}>{t.score}%</span>
                          </td>
                          <td className="px-3 py-3 text-xs font-mono" style={{ color: '#7A90A8' }}>{t.enrolled}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

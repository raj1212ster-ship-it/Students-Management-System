import { useState } from 'react'
import { Download, BarChart3 as BarChart3Icon, Activity, TrendingUp } from 'lucide-react'
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts'

interface ManagementDashboardProps {
  onViewTrainee: (code: string) => void
}

const KPI = [
  { label: 'Total Trainees',       value: '1,24,530', delta: '+2,340 this month', color: 'var(--ysf-blue)',   border: '#1565C0' },
  { label: 'Active Enrollment',    value: '89,420',   delta: '71.8% of total',   color: '#2563EB',           border: '#2563EB' },
  { label: 'Pending Verification', value: '8,234',    delta: '6.6% pending',     color: 'var(--ysf-orange)', border: '#F97316' },
  { label: 'Placements',           value: '72,150',   delta: '57.9% rate',       color: '#16a34a',           border: '#16a34a' },
  { label: 'Rejected',             value: '4,890',    delta: '3.9%',             color: 'var(--ysf-red)',    border: '#E53935' },
  { label: 'Active Batches',       value: '847',      delta: '234 job roles',    color: '#7c3aed',           border: '#7c3aed' },
]

const MONTHLY = [
  { month: 'Feb', registrations: 8200,  completions: 6100,  placements: 5400  },
  { month: 'Mar', registrations: 9100,  completions: 7200,  placements: 6100  },
  { month: 'Apr', registrations: 10400, completions: 8300,  placements: 7200  },
  { month: 'May', registrations: 11200, completions: 9100,  placements: 8000  },
  { month: 'Jun', registrations: 12100, completions: 10200, placements: 8900  },
  { month: 'Jul', registrations: 13400, completions: 11100, placements: 9800  },
  { month: 'Aug', registrations: 14200, completions: 12000, placements: 10500 },
]

const BRANCH_DATA = [
  { branch: 'Hyderabad', trainees: 18240, completed: 15200, pending: 3040 },
  { branch: 'Mumbai',    trainees: 16800, completed: 14100, pending: 2700 },
  { branch: 'Delhi',     trainees: 15400, completed: 12900, pending: 2500 },
  { branch: 'Chennai',   trainees: 14200, completed: 11800, pending: 2400 },
  { branch: 'Bengaluru', trainees: 13900, completed: 11500, pending: 2400 },
  { branch: 'Kolkata',   trainees: 12100, completed: 10200, pending: 1900 },
]

const GENDER_DATA = [
  { name: 'Male',   value: 68420 },
  { name: 'Female', value: 54320 },
  { name: 'Other',  value: 1790  },
]

const SCHEME_DATA = [
  { name: 'WILP',  value: 52000 },
  { name: 'BVOC',  value: 28000 },
  { name: 'DVOC',  value: 22000 },
  { name: 'FLEXI', value: 14000 },
  { name: 'MSBTE', value: 8530  },
]

const GENDER_COLORS = ['#1565C0', '#F97316', '#7c3aed']
const SCHEME_COLORS = ['#1565C0', '#2563EB', '#0ea5e9', '#16a34a', '#F5B800']

const TRAINEES = [
  { code: 'TRN001234', name: 'Rahul Sharma',  branch: 'Hyderabad', course: 'Electrician',            scheme: 'WILP',  status: 'Completed',            batch: 'HYD-B12' },
  { code: 'TRN001199', name: 'Priya Reddy',   branch: 'Hyderabad', course: 'Data Entry Operator',    scheme: 'BVOC',  status: 'Active',               batch: 'HYD-B11' },
  { code: 'TRN000892', name: 'Mohammed Ali',  branch: 'Mumbai',    course: 'Solar PV Technician',    scheme: 'DVOC',  status: 'Placed',               batch: 'MUM-B09' },
  { code: 'TRN000745', name: 'Sunita Devi',   branch: 'Delhi',     course: 'Beauty Therapist',       scheme: 'FLEXI', status: 'Active',               batch: 'DEL-B07' },
  { code: 'TRN000621', name: 'Arun Kumar',    branch: 'Chennai',   course: 'Plumber General',        scheme: 'MSBTE', status: 'Verification Pending',  batch: '—'       },
  { code: 'TRN000589', name: 'Kavita Singh',  branch: 'Bengaluru', course: 'Retail Sales Associate', scheme: 'WILP',  status: 'Placed',               batch: 'BLR-B06' },
]

const STATUS_STYLE: Record<string, { bg: string; color: string; dot: string }> = {
  'Completed':            { bg: 'rgba(220,252,231,0.8)', color: '#065f46', dot: '#16a34a' },
  'Active':               { bg: 'var(--ysf-blue-light)', color: '#1e40af', dot: '#1565C0' },
  'Placed':               { bg: 'rgba(237,233,254,0.8)', color: '#4c1d95', dot: '#7c3aed' },
  'Verification Pending': { bg: 'rgba(254,243,199,0.8)', color: '#92400e', dot: '#F5B800' },
}

function Panel({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-xl ${className}`}
      style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)' }}
    >
      {children}
    </div>
  )
}

export default function ManagementDashboard({ onViewTrainee }: ManagementDashboardProps) {
  const [searchQ, setSearchQ] = useState('')
  const filtered = TRAINEES.filter(t =>
    !searchQ || t.name.toLowerCase().includes(searchQ.toLowerCase()) || t.code.includes(searchQ)
  )

  return (
    <div className="space-y-5">

      {/* Welcome Banner — blue leading, orange accent */}
      <div
        className="rounded-2xl p-5 md:p-6 overflow-hidden relative"
        style={{
          background: 'linear-gradient(120deg, #0D47A1 0%, var(--ysf-blue) 50%, #1976D2 100%)',
          boxShadow: '0 4px 24px rgba(21,101,192,0.28)',
        }}
      >
        {/* Decorative elements */}
        <div className="absolute right-0 top-0 w-72 h-72 rounded-full opacity-10 hidden sm:block"
          style={{ background: 'white', transform: 'translate(25%, -45%)' }} />
        <div className="absolute right-24 bottom-0 w-48 h-48 rounded-full opacity-10 hidden sm:block"
          style={{ background: 'white', transform: 'translateY(55%)' }} />
        <div className="absolute right-12 top-1/2 w-20 h-20 rounded-full opacity-25 hidden sm:block"
          style={{ background: 'var(--ysf-orange)', transform: 'translateY(-50%)', filter: 'blur(16px)' }} />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span
                className="text-xs font-bold px-2 py-0.5 rounded-full"
                style={{ background: 'rgba(249,115,22,0.30)', color: '#FED7AA', fontFamily: "'Exo 2', sans-serif" }}
              >
                EXECUTIVE PORTAL
              </span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-white mb-1" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
              Good Morning, Rajesh 👋
            </h1>
            <p className="text-sm hidden sm:block" style={{ color: 'rgba(255,255,255,0.75)', fontFamily: "'Exo 2', sans-serif" }}>
              Pan-India overview across 847 training centers.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
            <div
              className="text-xs px-3 py-1.5 rounded-lg hidden md:block"
              style={{ background: 'rgba(255,255,255,0.15)', color: '#fff', border: '1px solid rgba(255,255,255,0.25)', fontFamily: "'Exo 2', sans-serif" }}
            >
              Feb – Aug 2024
            </div>
            <button
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl font-bold text-sm"
              style={{
                background: 'white',
                color: 'var(--ysf-blue)',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                fontFamily: 'Rajdhani, sans-serif',
              }}
            >
              <BarChart3Icon size={14} /> Analytics
            </button>
            <button
              className="hidden sm:flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold"
              style={{ background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.25)', color: '#fff', fontFamily: "'Exo 2', sans-serif" }}
            >
              <Download size={14} /> Export
            </button>
          </div>
        </div>
      </div>

      {/* Status strip */}
      <div
        className="flex items-center rounded-xl overflow-x-auto scrollbar-hide text-xs"
        style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)' }}
      >
        <div
          className="flex items-center gap-2 px-4 py-2.5 font-bold flex-shrink-0"
          style={{ background: 'var(--ysf-blue)', color: '#fff', fontFamily: "'Exo 2', sans-serif" }}
        >
          <Activity size={12} /> Pan-India Live
        </div>
        {['1,24,530 active trainees', '847 training centers', '89,200 placed', '8,234 pending verification', '234 job roles'].map((s, i) => (
          <span
            key={i}
            className="px-4 py-2.5 flex-shrink-0"
            style={{ color: 'var(--muted-foreground)', borderLeft: '1px solid var(--border)', fontFamily: "'Exo 2', sans-serif" }}
          >
            {s}
          </span>
        ))}
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {KPI.map(k => (
          <div
            key={k.label}
            className="rounded-xl p-4 transition-all duration-200"
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border)',
              borderTop: `3px solid ${k.border}`,
              boxShadow: 'var(--card-shadow)',
            }}
          >
            <div className="text-xs font-medium mb-2 leading-snug" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{k.label}</div>
            <div className="text-2xl font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{k.value}</div>
            <div className="flex items-center gap-1 text-xs font-semibold" style={{ color: k.color, fontFamily: "'Exo 2', sans-serif" }}>
              <TrendingUp size={11} />
              {k.delta}
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel>
          <div
            className="px-5 pt-4 pb-1 flex items-center justify-between"
            style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-blue)', borderTopLeftRadius: 12, borderTopRightRadius: 12 }}
          >
            <div className="pb-3">
              <h3 className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Registration & Placement Trend</h3>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Feb–Aug 2024 pan-India</p>
            </div>
            <div className="flex items-center gap-4 pb-3 text-xs" style={{ fontFamily: "'Exo 2', sans-serif", color: 'var(--muted-foreground)' }}>
              <span className="flex items-center gap-1.5"><span className="w-3 h-1.5 rounded-full inline-block" style={{ background: '#1565C0' }} />Registrations</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-1.5 rounded-full inline-block" style={{ background: '#16a34a' }} />Completions</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-1.5 rounded-full inline-block" style={{ background: '#F97316' }} />Placements</span>
            </div>
          </div>
          <div className="p-5">
            <div style={{ position: 'relative', width: '100%', height: 200 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={MONTHLY}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(21,101,192,0.07)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: '1px solid rgba(21,101,192,0.12)', background: 'rgba(255,255,255,0.96)', boxShadow: '0 8px 24px rgba(0,0,0,0.08)' }} />
                  <Line type="monotone" dataKey="registrations" stroke="#1565C0" strokeWidth={2.5} dot={false} name="Registrations" />
                  <Line type="monotone" dataKey="completions"   stroke="#16a34a" strokeWidth={2.5} dot={false} name="Completions" />
                  <Line type="monotone" dataKey="placements"    stroke="#F97316" strokeWidth={2.5} dot={false} name="Placements" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Panel>

        <Panel>
          <div
            className="px-5 pt-4 pb-1"
            style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-orange)', borderTopLeftRadius: 12, borderTopRightRadius: 12 }}
          >
            <div className="pb-3">
              <h3 className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Branch-wise Enrollment</h3>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Completed vs. pending</p>
            </div>
          </div>
          <div className="p-5">
            <div style={{ position: 'relative', width: '100%', height: 200 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={BRANCH_DATA} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(21,101,192,0.07)" horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                  <YAxis dataKey="branch" type="category" tick={{ fontSize: 11, fill: '#475569' }} axisLine={false} tickLine={false} width={75} />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 12, border: '1px solid rgba(21,101,192,0.12)', background: 'rgba(255,255,255,0.96)' }} />
                  <Bar dataKey="completed" fill="#1565C0" radius={[0, 0, 0, 0]} name="Completed" stackId="a" />
                  <Bar dataKey="pending"   fill="#F97316" radius={[0, 4, 4, 0]} name="Pending"   stackId="a" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </Panel>
      </div>

      {/* Pie Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Panel>
          <div
            className="px-5 pt-4 pb-3"
            style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-blue)', borderTopLeftRadius: 12, borderTopRightRadius: 12 }}
          >
            <h3 className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Gender Distribution</h3>
          </div>
          <div className="p-5 flex items-center gap-6">
            <div style={{ position: 'relative', width: 150, height: 150, flexShrink: 0 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={GENDER_DATA} cx={70} cy={70} innerRadius={45} outerRadius={70} dataKey="value">
                    {GENDER_DATA.map((_, i) => <Cell key={i} fill={GENDER_COLORS[i]} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-3">
              {GENDER_DATA.map((g, i) => (
                <div key={g.name} className="flex items-center gap-2.5 text-sm">
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: GENDER_COLORS[i] }} />
                  <span style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{g.name}</span>
                  <span className="font-bold ml-auto" style={{ color: 'var(--foreground)', fontFamily: 'JetBrains Mono, monospace' }}>{g.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </Panel>

        <Panel>
          <div
            className="px-5 pt-4 pb-3"
            style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-orange)', borderTopLeftRadius: 12, borderTopRightRadius: 12 }}
          >
            <h3 className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Scheme-wise Distribution</h3>
          </div>
          <div className="p-5 flex items-center gap-6">
            <div style={{ position: 'relative', width: 150, height: 150, flexShrink: 0 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={SCHEME_DATA} cx={70} cy={70} innerRadius={45} outerRadius={70} dataKey="value">
                    {SCHEME_DATA.map((_, i) => <Cell key={i} fill={SCHEME_COLORS[i]} />)}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-2.5">
              {SCHEME_DATA.map((s, i) => (
                <div key={s.name} className="flex items-center gap-2.5 text-xs">
                  <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: SCHEME_COLORS[i] }} />
                  <span style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{s.name}</span>
                  <span className="font-bold ml-auto" style={{ color: 'var(--foreground)', fontFamily: 'JetBrains Mono, monospace' }}>{s.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>

      {/* Trainee Table */}
      <Panel>
        <div
          className="px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-3"
          style={{ borderBottom: '1px solid var(--border)', borderTop: '3px solid var(--ysf-blue)', borderTopLeftRadius: 12, borderTopRightRadius: 12 }}
        >
          <div className="flex-1">
            <h2 className="font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Trainee Registry</h2>
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Click "View 360°" to open full profile</p>
          </div>
          <input
            className="px-3 py-2 rounded-xl text-sm outline-none transition-all w-full sm:w-60"
            style={{ border: '1px solid var(--border)', background: 'var(--muted)', color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}
            placeholder="Search by name or code..."
            value={searchQ}
            onChange={e => setSearchQ(e.target.value)}
            onFocus={e => (e.target.style.borderColor = 'var(--ysf-blue)')}
            onBlur={e => (e.target.style.borderColor = 'var(--border)')}
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr style={{ background: 'var(--muted)' }}>
                {['Trainee Code', 'Name', 'Branch', 'Course', 'Scheme', 'Batch', 'Status', 'Action'].map(h => (
                  <th key={h} className="px-5 py-3 text-left text-xs font-bold uppercase tracking-widest" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(t => {
                const s = STATUS_STYLE[t.status] || {}
                return (
                  <tr
                    key={t.code}
                    className="border-t transition-colors"
                    style={{ borderColor: 'var(--border)' }}
                    onMouseEnter={e => (e.currentTarget.style.background = 'var(--muted)')}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <td className="px-5 py-3.5">
                      <span className="font-mono text-xs font-bold px-2 py-1 rounded-lg" style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)' }}>
                        {t.code}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 font-semibold text-sm" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{t.name}</td>
                    <td className="px-5 py-3.5 text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{t.branch}</td>
                    <td className="px-5 py-3.5 text-xs" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{t.course}</td>
                    <td className="px-5 py-3.5 text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{t.scheme}</td>
                    <td className="px-5 py-3.5 font-mono text-xs" style={{ color: 'var(--muted-foreground)' }}>{t.batch}</td>
                    <td className="px-5 py-3.5">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: s.bg, color: s.color, fontFamily: "'Exo 2', sans-serif" }}>
                        <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: s.dot }} />
                        {t.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <button
                        onClick={() => onViewTrainee(t.code)}
                        className="text-xs font-bold transition-all px-3 py-1.5 rounded-lg"
                        style={{ color: 'var(--ysf-blue)', background: 'var(--ysf-blue-light)', fontFamily: "'Exo 2', sans-serif" }}
                        onMouseEnter={e => { e.currentTarget.style.background = 'rgba(21,101,192,0.18)' }}
                        onMouseLeave={e => { e.currentTarget.style.background = 'var(--ysf-blue-light)' }}
                      >
                        View 360° →
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  )
}

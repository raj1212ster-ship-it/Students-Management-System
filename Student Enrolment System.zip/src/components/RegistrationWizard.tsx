import { useState, useRef } from 'react'
import { STATES, DISTRICTS, ZONE_COMPANIES, ZONE_LIST, ALL_ZONE_COMPANIES } from '@/data/indiaGeo'
import type React from 'react'
import {
  Check, User, GraduationCap, FileText, CheckCircle, FolderOpen,
  Upload, AlertTriangle, XCircle, ClipboardList, Mail, Building2,
  Plus, Trash2, ChevronDown, Layers, BookOpen, CloudUpload, Scan,
  MousePointerClick, Info, Clock, BadgeCheck, ChevronRight, Sparkles,
} from 'lucide-react'

/* ── Types ─────────────────────────────────────────────────────────── */
export interface RecentRegistration {
  id: string
  tempCode: string        // cleared ('') once approved
  fixedCode?: string      // set when status changes to 'approved'
  fullName: string
  mobile: string
  scheme: string
  company: string
  zone: string
  submittedAt: string
  status: 'pending' | 'approved' | 'rejected'
  source: 'online' | 'hard-copy'
  formData: Partial<FormData>
}

interface EduRecord { id: number; qualification: string; board: string; totalMarks: string; obtainedMarks: string; percentage: string; year: string }
interface DocRecord  { uploaded: boolean; name: string }

export interface FormData {
  scheme: string; zone: string; company: string; sector: string; location: string; stipend: string
  fullName: string; fatherName: string; motherName: string; fatherOcc: string; motherOcc: string
  mobile: string; altMobile: string; email: string; dob: string; birthPlace: string
  aadhaar: string; aadhaarConfirm: string; gender: string
  religion: string; caste: string; nationality: string; country: string
  state: string; district: string; city: string; address: string; pincode: string
  marital: string; bloodGroup: string; motherTongue: string; disability: string
  courseName: string; jobRole: string; nsqfLevel: string; courseStart: string; courseEnd: string
  bankName: string; accountNo: string; ifsc: string
  education: EduRecord[]
  docs: Record<string, DocRecord>
  // NAPS-specific
  tradeName?: string; establishmentType?: string
}

/* ── Scheme Configuration ──────────────────────────────────────────── */
interface SchemeConfig {
  badge: string
  description: string
  duration: string
  eligibility: string
  stipendOptions: string[]
  requiresCompany: boolean
  showSector: boolean
  extra?: 'naps-fields' | 'ddu-fields'
  accentColor: string
  bgClass: string
}

const SCHEME_CONFIG: Record<string, SchemeConfig> = {
  'WILP': {
    badge: 'WILP', description: 'Work Integrated Learning Programme — Combines on-the-job industry training with academic learning for working professionals.',
    duration: '1–3 years', eligibility: 'Age 18+ · Employed candidate · Class 12 / Diploma pass',
    stipendOptions: ['Category B – ₹10,000/month', 'Category C – ₹12,000/month'],
    requiresCompany: true, showSector: true, accentColor: 'var(--ysf-blue)', bgClass: '',
  },
  'BVOC': {
    badge: 'BVOC', description: 'Bachelor of Vocation — UGC-approved degree programme integrating skill training with higher education for industry-ready graduates.',
    duration: '3 years', eligibility: 'Age 17–25 · Class 12 pass · Any stream',
    stipendOptions: ['Category A – ₹8,000/month', 'Category B – ₹10,000/month', 'Category C – ₹12,000/month'],
    requiresCompany: true, showSector: true, accentColor: '#7c3aed', bgClass: '',
  },
  'DVOC': {
    badge: 'DVOC', description: 'Diploma of Vocation — Short-duration vocational diploma combining sector-specific skills with workplace experience.',
    duration: '1–2 years', eligibility: 'Age 16–30 · Class 10 pass · Industry aptitude',
    stipendOptions: ['Category A – ₹8,000/month', 'Category B – ₹10,000/month'],
    requiresCompany: true, showSector: true, accentColor: 'var(--ysf-orange)', bgClass: '',
  },
  'FLEXI': {
    badge: 'FLEXI', description: 'Flexi MOU Scheme — Flexible industry partnership model allowing customised training aligned to company-specific skill requirements.',
    duration: 'As per MOU', eligibility: 'Age 18+ · Company-nominated · Class 10 pass preferred',
    stipendOptions: ['Category B – ₹10,000/month', 'Category C – ₹12,000/month', 'Category D – ₹15,000/month'],
    requiresCompany: true, showSector: true, extra: 'naps-fields', accentColor: '#0891b2', bgClass: '',
  },
  'MSBTE': {
    badge: 'MSBTE', description: 'Maharashtra State Board of Technical Education — State-certified technical and vocational training programmes for Maharashtra-based candidates.',
    duration: '6 months – 3 years', eligibility: 'Age 15–35 · Maharashtra domicile · Class 10 pass',
    stipendOptions: ['Category A – ₹8,000/month', 'Category B – ₹10,000/month'],
    requiresCompany: false, showSector: true, accentColor: '#16a34a', bgClass: '',
  },
}

/* ── Constants ─────────────────────────────────────────────────────── */
const STEPS = [
  { label: 'Scheme & Company', short: 'Scheme',    icon: Building2   },
  { label: 'Personal Details', short: 'Personal',  icon: User        },
  { label: 'Education',        short: 'Education', icon: GraduationCap },
  { label: 'Documents',        short: 'Documents', icon: FolderOpen  },
  { label: 'Review & Submit',  short: 'Review',    icon: CheckCircle },
]

const ZONES         = ZONE_LIST.filter(z => z !== 'All Zones')
const ALL_COMPANIES = ALL_ZONE_COMPANIES.filter(c => c !== 'All Companies')
const SECTORS       = ['Manufacturing', 'Automobile', 'Engineering', 'IT/ITES', 'Retail', 'Healthcare', 'Construction', 'Logistics', 'Green Energy']
const LOCATIONS     = ['Hyderabad Center A', 'Hyderabad Center B', 'Mumbai Center', 'Delhi Center', 'Chennai Center', 'Bengaluru Center']
const RELIGIONS     = ['Hindu', 'Muslim', 'Christian', 'Sikh', 'Buddhist', 'Jain', 'Other']
const CASTES        = ['General', 'OBC', 'SC', 'ST', 'EWS']

const BLOOD_GROUPS  = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']
const MARITAL       = ['Single', 'Married', 'Widowed', 'Divorced']
const MOTHER_TONGUE = ['Telugu', 'Hindi', 'Tamil', 'Kannada', 'Marathi', 'Bengali', 'Gujarati', 'Punjabi', 'Malayalam', 'Other']
const COURSES       = ['Electrician General', 'Solar PV Technician', 'Plumber General', 'Data Entry Operator', 'Beauty Therapist', 'CNC Operator', 'Retail Sales Associate', 'Welder (FCAW)', 'AC & Refrigeration Technician']
const JOB_ROLES     = ['Electrician General', 'Solar PV Installer', 'Plumber General', 'DEO (Data Entry)', 'Beauty Therapist', 'CNC Machine Operator', 'Retail Trainee Associate', 'Welder FCAW', 'AC Technician']
const NSQF_LEVELS   = ['Level 1', 'Level 2', 'Level 3', 'Level 4', 'Level 5', 'Level 6']
const QUALIFICATIONS = ['10th Standard', '12th Standard', 'ITI', 'Diploma', 'Graduate (B.A.)', 'Graduate (B.Sc.)', 'Graduate (B.Com.)', 'Graduate (B.E./B.Tech.)', 'Other']
const YEARS         = Array.from({ length: 30 }, (_, i) => String(new Date().getFullYear() - i))
const TRADE_NAMES   = ['Electrician', 'Fitter', 'Welder', 'Plumber', 'Machinist', 'Draughtsman Civil', 'Electronics Mechanic', 'Computer Operator & Programming Assistant']
const ESTAB_TYPES   = ['Central Public Sector', 'State Public Sector', 'Private Sector', 'Proprietary', 'Partnership', 'LLP', 'Company']

const REQUIRED_DOCS = [
  { key: 'photo',      label: 'Passport Photo',             required: true,  hint: 'Recent, white background' },
  { key: 'aadhaar',    label: 'Aadhaar Card',               required: true,  hint: 'Front & back scan/photo' },
  { key: 'marksheet',  label: '10th Marksheet',             required: true,  hint: 'Board exam marksheet' },
  { key: 'certificate',label: 'Qualification Certificate',  required: true,  hint: 'Highest qualification' },
  { key: 'dob_proof',  label: 'Date of Birth Proof',        required: true,  hint: 'LC / 10th / 12th certificate' },
  { key: 'sidh',       label: 'SIDH Profile Screenshot',    required: true,  hint: 'Skill India portal screenshot' },
  { key: 'undertaking',label: 'Undertaking (Auto Generated)',required: true,  hint: 'Generated in Step 5' },
  { key: 'passbook',   label: 'Bank Passbook / Cheque',     required: true,  hint: 'Front page with account details' },
  { key: 'other',      label: 'Other Documents',            required: false, hint: 'Any additional supporting docs' },
]

/* Mock hard-copy extraction payload */
const MOCK_EXTRACTED: Partial<FormData> = {
  scheme: 'WILP', zone: 'Pune', company: 'Minda Corporation Limited', sector: 'Automotive',
  location: 'Hyderabad Center A', stipend: 'Category B – ₹10,000/month',
  fullName: 'Amit Kumar Singh', fatherName: 'Ramesh Kumar Singh', motherName: 'Sunita Devi Singh',
  fatherOcc: 'Farmer', mobile: '9876543210', email: 'amit.singh@gmail.com',
  dob: '2001-03-15', birthPlace: 'Nalgonda',
  aadhaar: '2345 6789 0123', aadhaarConfirm: '2345 6789 0123',
  gender: 'Male', religion: 'Hindu', caste: 'OBC', nationality: 'Indian', country: 'India',
  state: 'Telangana', district: 'Hyderabad', city: 'Kukatpally',
  address: '12, Gandhi Nagar, Kukatpally, Hyderabad', pincode: '500072',
  marital: 'Single', bloodGroup: 'B+', motherTongue: 'Telugu', disability: 'No',
  courseName: 'Electrician General', jobRole: 'Electrician General', nsqfLevel: 'Level 4',
  courseStart: '2026-02-01', courseEnd: '2026-05-31',
  bankName: 'State Bank of India', accountNo: '32145678901', ifsc: 'SBIN0021234',
  education: [{ id: 1, qualification: '10th Standard', board: 'BSEAP', totalMarks: '500', obtainedMarks: '392', percentage: '78.4', year: '2017' }],
}

const initForm = (): FormData => ({
  scheme: '', zone: '', company: '', sector: '', location: '', stipend: '',
  fullName: '', fatherName: '', motherName: '', fatherOcc: '', motherOcc: '',
  mobile: '', altMobile: '', email: '', dob: '', birthPlace: '',
  aadhaar: '', aadhaarConfirm: '', gender: '',
  religion: '', caste: '', nationality: 'Indian', country: 'India',
  state: '', district: '', city: '', address: '', pincode: '',
  marital: '', bloodGroup: '', motherTongue: '', disability: '',
  courseName: '', jobRole: '', nsqfLevel: '', courseStart: '', courseEnd: '',
  bankName: '', accountNo: '', ifsc: '',
  education: [{ id: 1, qualification: '10th Standard', board: '', totalMarks: '', obtainedMarks: '', percentage: '', year: '' }],
  docs: Object.fromEntries(REQUIRED_DOCS.map(d => [d.key, { uploaded: false, name: '' }])),
  tradeName: '', establishmentType: '',
})

/* ── Shared primitives ─────────────────────────────────────────────── */
const IS = { width: '100%', padding: '10px 14px', borderRadius: 10, fontSize: 13,
  border: '1.5px solid var(--border)', background: 'var(--card)', outline: 'none',
  color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif", transition: 'border-color 0.18s, box-shadow 0.18s', boxSizing: 'border-box' as const }

function Inp({ value, onChange, placeholder, type = 'text', readOnly = false }:
  { value: string; onChange?: (v: string) => void; placeholder?: string; type?: string; readOnly?: boolean }) {
  return (
    <input type={type} value={value} readOnly={readOnly}
      onChange={e => onChange?.(e.target.value)} placeholder={placeholder}
      style={{ ...IS, background: readOnly ? 'var(--muted)' : 'var(--card)', color: readOnly ? 'var(--muted-foreground)' : 'var(--foreground)' }}
      onFocus={e => { if (!readOnly) { e.target.style.borderColor = 'var(--ysf-blue)'; e.target.style.boxShadow = '0 0 0 3px rgba(21,101,192,0.09)' } }}
      onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = 'none' }}
    />
  )
}

function Sel({ value, onChange, options, placeholder }:
  { value: string; onChange: (v: string) => void; options: string[]; placeholder?: string }) {
  return (
    <div style={{ position: 'relative' }}>
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ ...IS, appearance: 'none', paddingRight: 32, color: value ? 'var(--foreground)' : 'var(--muted-foreground)' }}
        onFocus={e => { e.target.style.borderColor = 'var(--ysf-blue)'; e.target.style.boxShadow = '0 0 0 3px rgba(21,101,192,0.09)' }}
        onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = 'none' }}
      >
        <option value="">{placeholder || 'Select…'}</option>
        {options.map(o => <option key={o} value={o}>{o}</option>)}
      </select>
      <ChevronDown size={13} style={{ position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--muted-foreground)', pointerEvents: 'none' }} />
    </div>
  )
}

function Fld({ label, required, hint, children }: { label: string; required?: boolean; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-bold mb-1.5 uppercase tracking-widest" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
        {label}{required && <span style={{ color: 'var(--ysf-red)', marginLeft: 3 }}>*</span>}
      </label>
      {children}
      {hint && <div className="text-xs mt-1" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{hint}</div>}
    </div>
  )
}

function Section({ label, accent = 'var(--ysf-blue)', children }: { label: string; accent?: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
        <span className="text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest"
          style={{ background: `${accent}10`, color: accent, border: `1px solid ${accent}25`, fontFamily: "'Exo 2', sans-serif" }}>
          {label}
        </span>
        <div className="h-px flex-1" style={{ background: 'var(--border)' }} />
      </div>
      <div className="rounded-xl p-4" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
        {children}
      </div>
    </div>
  )
}

/* ── Main Wizard ───────────────────────────────────────────────────── */
interface WizardProps {
  onNavigate: (screen: string) => void
  onComplete?: (reg: RecentRegistration) => void
  prefillData?: Partial<FormData>
  prefillSource?: 'hard-copy'
}

type WizardMode = 'entry' | 'online' | 'upload'
type UploadPhase = 'idle' | 'uploading' | 'processing' | 'done' | 'bulk-preview'
type UploadFileType = 'image' | 'spreadsheet' | 'database' | null

interface BulkRow {
  idx: number; name: string; mobile: string; scheme: string; company: string; zone: string
  course: string; state: string; gender: string; dob: string; aadhaar: string; email: string
  bank: string; ifsc: string; accountNo: string
}

const MOCK_BULK_ROWS: BulkRow[] = [
  { idx: 0, name: 'Amit Kumar Singh',   mobile: '9876543210', scheme: 'WILP',   company: 'TechMahindra', zone: 'NCR Noida',  course: 'Electrician General',          state: 'Telangana',    gender: 'Male',   dob: '2001-03-15', aadhaar: '234567890123', email: 'amit.singh@gmail.com',    bank: 'SBI',     ifsc: 'SBIN0021234', accountNo: '32145678901' },
  { idx: 1, name: 'Priya Reddy',        mobile: '9876501234', scheme: 'BVOC',   company: 'Wipro',        zone: 'Pune',       course: 'Data Entry Operator',          state: 'Telangana',    gender: 'Female', dob: '2002-07-22', aadhaar: '345678901234', email: 'priya.r@gmail.com',       bank: 'HDFC',    ifsc: 'HDFC0001234', accountNo: '50100123456' },
  { idx: 2, name: 'Ravi Kumar Sharma',  mobile: '9845678901', scheme: 'DVOC',   company: 'Infosys',      zone: 'NCR Haryana',course: 'Solar PV Technician',          state: 'Karnataka',    gender: 'Male',   dob: '2000-11-09', aadhaar: '456789012345', email: 'ravi.sharma@gmail.com',   bank: 'Canara',  ifsc: 'CNRB0001234', accountNo: '1234567890' },
  { idx: 3, name: 'Sunita Devi',        mobile: '9912345678', scheme: 'MSBTE',  company: '',             zone: 'Nashik',     course: 'Beauty Therapist',             state: 'Maharashtra',  gender: 'Female', dob: '2003-02-14', aadhaar: '567890123456', email: 'sunita.d@gmail.com',      bank: 'PNB',     ifsc: 'PUNB0012345', accountNo: '0123456789' },
  { idx: 4, name: 'Kiran Nair',         mobile: '9800112233', scheme: 'FLEXI',  company: 'Endurance Technologies Limited', zone: 'Ranjangaon', course: 'CNC Operator', state: 'Maharashtra',  gender: 'Male',   dob: '1999-05-30', aadhaar: '678901234567', email: 'kiran.nair@gmail.com',    bank: 'BOI',     ifsc: 'BKID0001234', accountNo: '8765432109' },
  { idx: 5, name: 'Anjali Singh',       mobile: '9934561230', scheme: 'WILP',   company: 'Minda Corporation Limited', zone: 'Haridwar',   course: 'AC & Refrigeration Technician', state: 'Maharashtra', gender: 'Female', dob: '2001-09-18', aadhaar: '789012345678', email: 'anjali.s@gmail.com', bank: 'Axis', ifsc: 'UTIB0001234', accountNo: '9876543210' },
  { idx: 6, name: 'Mohammed Rafiq',     mobile: '9765432100', scheme: 'BVOC',   company: 'Gilbarco Veeder Root India Pvt. Ltd.', zone: 'Coimbatore', course: 'Welder (FCAW)', state: 'Tamil Nadu', gender: 'Male', dob: '2000-04-05', aadhaar: '890123456789', email: 'rafiq.m@gmail.com', bank: 'IOB', ifsc: 'IOBA0001234', accountNo: '6789012345' },
  { idx: 7, name: 'Deepa Yadav',        mobile: '9654321098', scheme: 'MSBTE',  company: 'Tata Motors',  zone: 'Pune',       course: 'Plumber General',              state: 'Maharashtra',  gender: 'Female', dob: '2002-12-28', aadhaar: '901234567890', email: 'deepa.y@gmail.com',       bank: 'UBI',     ifsc: 'UBIN0001234', accountNo: '5678901234' },
]

function rowToFormData(r: BulkRow): Partial<FormData> {
  return {
    scheme: r.scheme, zone: r.zone, company: r.company, sector: 'Manufacturing', location: `${r.zone} Center A`, stipend: 'Category B – ₹10,000/month',
    fullName: r.name, mobile: r.mobile, email: r.email, dob: r.dob, aadhaar: r.aadhaar, aadhaarConfirm: r.aadhaar,
    gender: r.gender, state: r.state, nationality: 'Indian', country: 'India', district: r.state, city: r.zone, pincode: '500001',
    courseName: r.course, jobRole: r.course.replace(' (FCAW)', ''), nsqfLevel: 'Level 4', courseStart: '2026-02-01', courseEnd: '2026-05-31',
    bankName: r.bank === 'SBI' ? 'State Bank of India' : r.bank === 'HDFC' ? 'HDFC Bank' : r.bank === 'Canara' ? 'Canara Bank' : r.bank + ' Bank',
    accountNo: r.accountNo, ifsc: r.ifsc,
    education: [{ id: 1, qualification: '10th Standard', board: 'State Board', totalMarks: '500', obtainedMarks: '380', percentage: '76.0', year: '2018' }],
  }
}

export default function RegistrationWizard({ onNavigate, onComplete, prefillData, prefillSource }: WizardProps) {
  const [mode, setMode]         = useState<WizardMode>(prefillData ? 'online' : 'entry')
  const [step, setStep]         = useState(0)
  const [form, setForm]         = useState<FormData>(() => prefillData ? { ...initForm(), ...prefillData } : initForm())
  const [done, setDone]         = useState(false)
  const [source]                = useState<'online' | 'hard-copy'>(prefillSource || 'online')
  const [uploadPhase, setUploadPhase] = useState<UploadPhase>('idle')
  const [uploadFileName, setUploadFileName] = useState('')
  const [uploadFileType, setUploadFileType] = useState<UploadFileType>(null)
  const [bulkRows]              = useState<BulkRow[]>(MOCK_BULK_ROWS)
  const [selectedBulkIdx, setSelectedBulkIdx] = useState<number | null>(null)
  const fileRef                 = useRef<HTMLInputElement>(null)

  const [tempCode] = useState(() => {
    const y = new Date().getFullYear()
    const n = String(Math.floor(Math.random() * 90000) + 10000)
    return `TEMP/HYD/PMKVY/${y}/${n}`
  })

  const set = (k: keyof FormData) => (v: string) => setForm(f => ({ ...f, [k]: v }))

  const toggleDoc = (key: string) =>
    setForm(f => ({ ...f, docs: { ...f.docs, [key]: { uploaded: !f.docs[key].uploaded, name: f.docs[key].uploaded ? '' : `${key.toUpperCase()}_${Date.now()}.pdf` } } }))

  const addEdu = () => setForm(f => ({ ...f, education: [...f.education, { id: Date.now(), qualification: '', board: '', totalMarks: '', obtainedMarks: '', percentage: '', year: '' }] }))
  const removeEdu = (id: number) => setForm(f => ({ ...f, education: f.education.filter(e => e.id !== id) }))
  const updateEdu = (id: number, field: keyof EduRecord, val: string) =>
    setForm(f => ({ ...f, education: f.education.map(e => {
      if (e.id !== id) return e
      const upd = { ...e, [field]: val }
      if (field === 'totalMarks' || field === 'obtainedMarks') {
        const tot = parseFloat(field === 'totalMarks' ? val : e.totalMarks)
        const obt = parseFloat(field === 'obtainedMarks' ? val : e.obtainedMarks)
        if (!isNaN(tot) && !isNaN(obt) && tot > 0) upd.percentage = ((obt / tot) * 100).toFixed(1)
      }
      return upd
    }) }))

  const next   = () => { if (step < 4) setStep(s => s + 1) }
  const back   = () => setStep(s => Math.max(s - 1, 0))

  const submit = () => {
    const reg: RecentRegistration = {
      id: `REG_${Date.now()}`,
      tempCode,
      fullName: form.fullName || 'Unknown Trainee',
      mobile: form.mobile || '',
      scheme: form.scheme || '',
      company: form.company || '',
      zone: form.zone || '',
      submittedAt: new Date().toISOString(),
      status: 'pending',
      source,
      formData: form,
    }
    onComplete?.(reg)
    setDone(true)
  }

  /* Upload flow */
  const getFileType = (name: string): UploadFileType => {
    const ext = name.split('.').pop()?.toLowerCase() || ''
    if (['xlsx', 'xls', 'csv'].includes(ext)) return 'spreadsheet'
    if (['mdb', 'accdb'].includes(ext)) return 'database'
    return 'image'
  }

  const handleFileSelect = (file: File) => {
    const ftype = getFileType(file.name)
    setUploadFileName(file.name)
    setUploadFileType(ftype)
    setUploadPhase('uploading')
    setTimeout(() => setUploadPhase('processing'), 1000)
    setTimeout(() => {
      if (ftype === 'spreadsheet' || ftype === 'database') {
        setUploadPhase('bulk-preview')
      } else {
        setForm({ ...initForm(), ...MOCK_EXTRACTED })
        setUploadPhase('done')
      }
    }, 2400)
  }

  const handleBulkRowSelect = (idx: number) => {
    setSelectedBulkIdx(idx)
  }

  const handleBulkImport = () => {
    if (selectedBulkIdx === null) return
    const row = bulkRows[selectedBulkIdx]
    setForm({ ...initForm(), ...rowToFormData(row) })
    setMode('online')
  }

  const cfg = SCHEME_CONFIG[form.scheme] || null
  const uploadedCount  = Object.values(form.docs).filter(d => d.uploaded).length

  if (done) return (
    <SuccessScreen tempCode={tempCode} source={source}
      onReset={() => { setDone(false); setStep(0); setForm(initForm()); setMode('entry') }}
      onNavigate={onNavigate} form={form} />
  )

  /* ── Entry screen ─────────────────────────────────────────── */
  if (mode === 'entry') return (
    <div className="max-w-2xl mx-auto space-y-5">
      <div className="flex items-center gap-3">

        <button onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-xl transition-all flex-shrink-0"
          style={{ color: 'var(--ysf-blue)', background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.20)', fontFamily: "'Exo 2', sans-serif" }}>
          ← Dashboard
        </button>
        <div>
          <h1 className="text-xl font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>New Trainee Registration</h1>
          <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Choose how you want to register the trainee</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Online registration */}

        <button onClick={() => setMode('online')}
          className="rounded-2xl p-6 text-left transition-all group"
          style={{ background: 'var(--card)', border: '2px solid var(--border)', boxShadow: 'var(--card-shadow)', cursor: 'pointer' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--ysf-blue)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(21,101,192,0.12)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'var(--card-shadow)' }}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
            style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', boxShadow: '0 6px 18px rgba(21,101,192,0.28)' }}>
            <MousePointerClick size={24} color="white" />
          </div>
          <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Online Registration</h3>
          <p className="text-sm mb-4" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Fill out the 5-step form digitally. All fields validated in real time.</p>
          <div className="flex flex-wrap gap-1.5">
            {['5 Steps', 'Auto-validation', 'Instant Temp Code'].map(t => (
              <span key={t} className="text-xs px-2 py-0.5 rounded-full"
                style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)', fontFamily: "'Exo 2', sans-serif" }}>{t}</span>
            ))}
          </div>
        </button>

        {/* Upload / Import */}

        <button onClick={() => setMode('upload')}
          className="rounded-2xl p-6 text-left transition-all group"
          style={{ background: 'var(--card)', border: '2px solid var(--border)', boxShadow: 'var(--card-shadow)', cursor: 'pointer' }}
          onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--ysf-orange)'; e.currentTarget.style.boxShadow = '0 8px 24px rgba(249,115,22,0.12)' }}
          onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.boxShadow = 'var(--card-shadow)' }}>
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
            style={{ background: 'linear-gradient(135deg,var(--ysf-orange),#ea580c)', boxShadow: '0 6px 18px rgba(249,115,22,0.28)' }}>
            <Scan size={24} color="white" />
          </div>
          <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Upload / Import File</h3>
          <p className="text-sm mb-4" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
            Upload a scanned hard copy or import bulk data from a spreadsheet or database file.
          </p>
          <div className="flex flex-wrap gap-1.5">
            {['PDF · JPG · PNG', 'Excel · CSV', 'MS Access', 'Bulk Import'].map(t => (
              <span key={t} className="text-xs px-2 py-0.5 rounded-full"
                style={{ background: 'rgba(249,115,22,0.10)', color: 'var(--ysf-orange)', fontFamily: "'Exo 2', sans-serif" }}>{t}</span>
            ))}
          </div>
        </button>
      </div>

      {/* Info strip */}
      <div className="rounded-xl p-4 flex items-start gap-3" style={{ background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.18)' }}>
        <Info size={15} style={{ color: 'var(--ysf-blue)', flexShrink: 0, marginTop: 2 }} />
        <p className="text-xs" style={{ color: '#1e3a5f', fontFamily: "'Exo 2', sans-serif" }}>
          Both methods generate a <strong>Temporary Code</strong> on submission and route the application for Admin verification. A permanent Fixed Company Code is issued on approval.
        </p>
      </div>
    </div>
  )

  /* ── Upload mode ──────────────────────────────────────────── */
  if (mode === 'upload') {
    const ftExt = uploadFileName ? uploadFileName.split('.').pop()?.toLowerCase() : ''
    const isSpreadsheet = uploadFileType === 'spreadsheet'
    const isDatabase    = uploadFileType === 'database'
    const isBulk        = isSpreadsheet || isDatabase

    // File-type badge config
    const ftConfig: Record<string, { label: string; color: string; bg: string; icon: string }> = {
      pdf:   { label: 'PDF',      color: 'var(--ysf-red)',    bg: 'rgba(229,57,53,0.08)',  icon: '📄' },
      jpg:   { label: 'JPG',      color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)', icon: '🖼️' },
      jpeg:  { label: 'JPEG',     color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)', icon: '🖼️' },
      png:   { label: 'PNG',      color: 'var(--ysf-blue)',   bg: 'var(--ysf-blue-light)', icon: '🖼️' },
      xlsx:  { label: 'Excel',    color: '#16a34a',            bg: 'rgba(22,163,74,0.08)',  icon: '📊' },
      xls:   { label: 'Excel',    color: '#16a34a',            bg: 'rgba(22,163,74,0.08)',  icon: '📊' },
      csv:   { label: 'CSV',      color: '#16a34a',            bg: 'rgba(22,163,74,0.08)',  icon: '📋' },
      mdb:   { label: 'Access',   color: '#7c3aed',            bg: 'rgba(124,58,237,0.08)', icon: '🗄️' },
      accdb: { label: 'Access',   color: '#7c3aed',            bg: 'rgba(124,58,237,0.08)', icon: '🗄️' },
    }
    const ftInfo = ftExt ? ftConfig[ftExt] : null

    return (
      <div className="max-w-3xl mx-auto space-y-5">
        <div className="flex items-center gap-3">
          <button onClick={() => { setMode('entry'); setUploadPhase('idle'); setUploadFileName(''); setUploadFileType(null); setSelectedBulkIdx(null) }}
            className="flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-xl"
            style={{ color: 'var(--ysf-blue)', background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.20)', fontFamily: "'Exo 2', sans-serif" }}>
            ← Back
          </button>
          <div>
            <h1 className="text-xl font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Upload / Import File</h1>
            <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
              PDF · JPG · PNG (scan) &nbsp;·&nbsp; Excel .xlsx/.xls · CSV &nbsp;·&nbsp; MS Access .mdb/.accdb
            </p>
          </div>
        </div>

        <div className="rounded-2xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow-md)' }}>

          {/* ── Idle: drop zone + format tiles ── */}
          {uploadPhase === 'idle' && (
            <>
              <div
                className="m-6 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all"
                style={{ border: '2px dashed var(--border)', padding: '40px 24px', background: 'var(--muted)' }}
                onDragOver={e => e.preventDefault()}
                onDrop={e => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) handleFileSelect(f) }}
                onClick={() => fileRef.current?.click()}
                onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--ysf-orange)'; e.currentTarget.style.background = 'rgba(249,115,22,0.04)' }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.background = 'var(--muted)' }}>
                <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-3"
                  style={{ background: 'rgba(249,115,22,0.10)' }}>
                  <CloudUpload size={28} style={{ color: 'var(--ysf-orange)' }} />
                </div>
                <h3 className="text-base font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Drag & Drop or Click to Browse</h3>
                <p className="text-sm mb-4" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                  Supports scanned forms and data files — max 25MB
                </p>
                <input ref={fileRef} type="file"
                  accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.csv,.mdb,.accdb"
                  style={{ display: 'none' }}
                  onChange={e => { const f = e.target.files?.[0]; if (f) handleFileSelect(f) }} />
                <div className="flex flex-wrap gap-2 justify-center">
                  {[
                    { ext: 'PDF',   color: 'var(--ysf-red)',  icon: '📄' },
                    { ext: 'JPG',   color: 'var(--ysf-blue)', icon: '🖼️' },
                    { ext: 'PNG',   color: 'var(--ysf-blue)', icon: '🖼️' },
                    { ext: 'XLSX',  color: '#16a34a',          icon: '📊' },
                    { ext: 'XLS',   color: '#16a34a',          icon: '📊' },
                    { ext: 'CSV',   color: '#16a34a',          icon: '📋' },
                    { ext: 'MDB',   color: '#7c3aed',          icon: '🗄️' },
                    { ext: 'ACCDB', color: '#7c3aed',          icon: '🗄️' },
                  ].map(f => (
                    <span key={f.ext} className="text-xs px-2.5 py-1 rounded-lg font-bold flex items-center gap-1"
                      style={{ background: `${f.color}12`, color: f.color, border: `1px solid ${f.color}25`, fontFamily: "'Exo 2', sans-serif" }}>
                      {f.icon} {f.ext}
                    </span>
                  ))}
                </div>
              </div>

              {/* Format guide */}
              <div className="px-6 pb-6 grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { icon: '📄', title: 'Scanned Hard Copy', desc: 'PDF or image of a filled registration form. Data auto-extracted field by field.', exts: '.pdf .jpg .png', color: 'var(--ysf-orange)' },
                  { icon: '📊', title: 'Excel / CSV Spreadsheet', desc: 'Bulk import multiple trainees from a structured data file. Preview rows before importing.', exts: '.xlsx .xls .csv', color: '#16a34a' },
                  { icon: '🗄️', title: 'MS Access Database', desc: 'Import trainees from an Access database export. Supports .mdb and .accdb formats.', exts: '.mdb .accdb', color: '#7c3aed' },
                ].map(g => (
                  <div key={g.title} className="rounded-xl p-4" style={{ background: `${g.color}08`, border: `1px solid ${g.color}18` }}>
                    <div className="text-2xl mb-2">{g.icon}</div>
                    <div className="text-sm font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{g.title}</div>
                    <p className="text-xs mb-2" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{g.desc}</p>
                    <div className="text-xs font-mono font-bold" style={{ color: g.color }}>{g.exts}</div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ── Uploading / Processing spinner ── */}
          {(uploadPhase === 'uploading' || uploadPhase === 'processing') && (
            <div className="p-12 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mb-5 relative"
                style={{ background: isBulk ? 'rgba(22,163,74,0.10)' : 'rgba(249,115,22,0.10)' }}>
                <div className="absolute inset-0 rounded-full border-4 border-transparent animate-spin"
                  style={{ borderTopColor: isBulk ? '#16a34a' : 'var(--ysf-orange)' }} />
                {uploadPhase === 'uploading'
                  ? <Upload size={22} style={{ color: isBulk ? '#16a34a' : 'var(--ysf-orange)' }} />
                  : <Scan size={22} style={{ color: isBulk ? '#16a34a' : 'var(--ysf-orange)' }} />}
              </div>
              <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                {uploadPhase === 'uploading' ? 'Uploading File…' : isBulk ? 'Parsing Records…' : 'Extracting Data…'}
              </h3>
              <p className="text-sm mb-1" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                {uploadPhase === 'uploading'
                  ? `Reading "${uploadFileName}"`
                  : isBulk ? `Reading rows from ${isDatabase ? 'database table' : 'spreadsheet'}…`
                  : 'Extracting trainee fields from the scanned form…'}
              </p>
              {ftInfo && (
                <span className="text-xs px-2.5 py-1 rounded-lg font-bold mt-2"
                  style={{ background: ftInfo.bg, color: ftInfo.color, border: `1px solid ${ftInfo.color}25`, fontFamily: "'Exo 2', sans-serif" }}>
                  {ftInfo.icon} {ftInfo.label}
                </span>
              )}
              <div className="w-64 h-1.5 rounded-full mt-5" style={{ background: 'var(--border)' }}>
                <div className="h-1.5 rounded-full transition-all duration-500"
                  style={{ width: uploadPhase === 'uploading' ? '40%' : '82%', background: isBulk ? 'linear-gradient(90deg,#16a34a,#22c55e)' : 'linear-gradient(90deg,var(--ysf-orange),#f59e0b)' }} />
              </div>
            </div>
          )}

          {/* ── Single-form done ── */}
          {uploadPhase === 'done' && (
            <div className="p-8 flex flex-col items-center text-center">
              <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4"
                style={{ background: 'rgba(22,163,74,0.12)' }}>
                <CheckCircle size={28} style={{ color: '#16a34a' }} />
              </div>
              <h3 className="text-lg font-bold mb-1" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>Data Extracted Successfully</h3>
              <p className="text-sm mb-2" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                Found <strong>28 fields</strong> from "{uploadFileName}"
              </p>
              <div className="flex flex-wrap justify-center gap-1.5 mb-6">
                {['Name ✓', 'Aadhaar ✓', 'DOB ✓', 'Address ✓', 'Education ✓', 'Banking ✓'].map(t => (
                  <span key={t} className="text-xs px-2.5 py-1 rounded-full"
                    style={{ background: 'rgba(22,163,74,0.10)', color: '#16a34a', fontFamily: "'Exo 2', sans-serif" }}>{t}</span>
                ))}
              </div>
              <button onClick={() => setMode('online')}
                className="flex items-center gap-2 px-6 py-3 rounded-xl text-white font-bold transition-all"
                style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', boxShadow: '0 6px 20px rgba(21,101,192,0.28)', fontFamily: 'Rajdhani, sans-serif' }}>
                Review & Complete Form <ChevronRight size={15} />
              </button>
            </div>
          )}

          {/* ── Bulk preview: Excel / CSV / Access ── */}
          {uploadPhase === 'bulk-preview' && (
            <div className="p-5 space-y-4">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-base font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                      {isDatabase ? '🗄️ Database Import' : '📊 Spreadsheet Import'}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full font-bold"
                      style={{ background: isDatabase ? 'rgba(124,58,237,0.10)' : 'rgba(22,163,74,0.10)', color: isDatabase ? '#7c3aed' : '#16a34a', fontFamily: "'Exo 2', sans-serif" }}>
                      {ftInfo?.icon} {ftInfo?.label}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full"
                      style={{ background: 'var(--muted)', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                      {bulkRows.length} records found
                    </span>
                  </div>
                  <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                    Select a row to import as a new registration. You can edit all fields before submitting.
                  </p>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button onClick={() => { setUploadPhase('idle'); setUploadFileName(''); setUploadFileType(null); setSelectedBulkIdx(null) }}
                    className="text-xs px-3 py-2 rounded-xl font-semibold"
                    style={{ background: 'var(--muted)', color: 'var(--foreground)', border: '1px solid var(--border)', fontFamily: "'Exo 2', sans-serif" }}>
                    Upload Different File
                  </button>
                </div>
              </div>

              {/* Column headers */}
              <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)' }}>
                <div className="overflow-x-auto">
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                    <thead>
                      <tr style={{ background: 'var(--muted)', borderBottom: '1px solid var(--border)' }}>
                        <th style={{ width: 40, padding: '10px 12px', textAlign: 'center', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em' }}>#</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Name</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Mobile</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Scheme</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Company</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Zone</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Course</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>Gender</th>
                        <th style={{ padding: '10px 12px', textAlign: 'left', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em', whiteSpace: 'nowrap' }}>DOB</th>
                        <th style={{ width: 80, padding: '10px 12px', textAlign: 'center', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontWeight: 700, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Select</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bulkRows.map((row, i) => {
                        const isSelected = selectedBulkIdx === row.idx
                        return (
                          <tr key={row.idx}
                            style={{ borderBottom: '1px solid var(--border)', background: isSelected ? 'rgba(21,101,192,0.06)' : i % 2 === 0 ? 'var(--card)' : 'var(--muted)', cursor: 'pointer', transition: 'background 0.12s' }}
                            onClick={() => handleBulkRowSelect(row.idx)}
                            onMouseEnter={e => !isSelected && (e.currentTarget.style.background = 'rgba(21,101,192,0.04)')}
                            onMouseLeave={e => !isSelected && (e.currentTarget.style.background = i % 2 === 0 ? 'var(--card)' : 'var(--muted)')}>
                            <td style={{ padding: '10px 12px', textAlign: 'center', color: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace', fontSize: 11 }}>{i + 1}</td>
                            <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>
                              <div style={{ fontWeight: 600, color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif", fontSize: 13 }}>{row.name}</div>
                            </td>
                            <td style={{ padding: '10px 12px', color: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, whiteSpace: 'nowrap' }}>{row.mobile}</td>
                            <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>
                              <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 6, background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)', fontFamily: "'Exo 2', sans-serif", fontWeight: 600 }}>
                                {row.scheme}
                              </span>
                            </td>
                            <td style={{ padding: '10px 12px', color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif", fontSize: 12, whiteSpace: 'nowrap' }}>{row.company || '—'}</td>
                            <td style={{ padding: '10px 12px', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontSize: 12, whiteSpace: 'nowrap' }}>{row.zone}</td>
                            <td style={{ padding: '10px 12px', color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif", fontSize: 12, whiteSpace: 'nowrap', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis' }}>{row.course}</td>
                            <td style={{ padding: '10px 12px', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif", fontSize: 12 }}>{row.gender}</td>
                            <td style={{ padding: '10px 12px', color: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace', fontSize: 11, whiteSpace: 'nowrap' }}>{row.dob}</td>
                            <td style={{ padding: '10px 12px', textAlign: 'center' }}>
                              <div className="w-5 h-5 rounded-full flex items-center justify-center mx-auto"
                                style={{ background: isSelected ? 'var(--ysf-blue)' : 'transparent', border: `2px solid ${isSelected ? 'var(--ysf-blue)' : 'var(--border)'}`, transition: 'all 0.15s' }}>
                                {isSelected && <Check size={10} color="white" />}
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Selected row preview + import button */}
              {selectedBulkIdx !== null && (
                <div className="rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-4"
                  style={{ background: 'rgba(21,101,192,0.06)', border: '1.5px solid rgba(21,101,192,0.20)' }}>
                  <div className="flex-1">
                    <div className="text-sm font-bold mb-0.5" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                      Selected: {bulkRows[selectedBulkIdx].name}
                    </div>
                    <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                      {bulkRows[selectedBulkIdx].scheme} · {bulkRows[selectedBulkIdx].company || 'No company'} · {bulkRows[selectedBulkIdx].zone} · {bulkRows[selectedBulkIdx].course}
                    </div>
                  </div>
                  <button onClick={handleBulkImport}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-white font-bold text-sm flex-shrink-0"
                    style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', boxShadow: '0 4px 14px rgba(21,101,192,0.28)', fontFamily: 'Rajdhani, sans-serif' }}>
                    Import & Fill Form <ChevronRight size={14} />
                  </button>
                </div>
              )}

              {selectedBulkIdx === null && (
                <div className="rounded-xl p-3 flex items-center gap-2" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
                  <Info size={13} style={{ color: 'var(--muted-foreground)' }} />
                  <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                    Click any row to select a trainee record to import
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    )
  }

  /* ── Online wizard ────────────────────────────────────────── */
  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">

        <button onClick={() => setMode('entry')}
          className="flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-xl transition-all flex-shrink-0"
          style={{ color: 'var(--ysf-blue)', background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.20)', fontFamily: "'Exo 2', sans-serif" }}>
          ← Back
        </button>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>New Trainee Registration</h1>
            {source === 'hard-copy' && (
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                style={{ background: 'rgba(249,115,22,0.12)', color: 'var(--ysf-orange)', border: '1px solid rgba(249,115,22,0.25)', fontFamily: "'Exo 2', sans-serif" }}>
                Hard Copy
              </span>
            )}
          </div>
          <p className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
            5 steps · Fields marked <span style={{ color: 'var(--ysf-red)' }}>*</span> are mandatory
          </p>
        </div>
      </div>

      {/* Step progress */}
      <div className="rounded-xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow)' }}>
        <div className="flex items-center">
          {STEPS.map((s, i) => (
            <div key={s.short} className="flex items-center" style={{ flex: i < STEPS.length - 1 ? 1 : 'none' }}>

              <button onClick={() => i < step && setStep(i)}
                className="flex flex-col items-center gap-1.5"
                style={{ cursor: i < step ? 'pointer' : 'default', background: 'none', border: 'none', padding: 0 }}>
                <div className="w-10 h-10 rounded-full flex items-center justify-center transition-all"
                  style={i < step
                    ? { background: 'linear-gradient(135deg,#16a34a,#22c55e)', color: '#fff', boxShadow: '0 4px 12px rgba(22,163,74,0.30)' }
                    : i === step
                    ? { background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', color: '#fff', boxShadow: '0 4px 14px rgba(21,101,192,0.30)' }
                    : { background: 'var(--muted)', color: 'var(--muted-foreground)', border: '1.5px solid var(--border)' }}>
                  {i < step ? <Check size={14} /> : <s.icon size={15} />}
                </div>
                <span className="text-xs font-semibold hidden sm:block whitespace-nowrap"
                  style={{ color: i === step ? 'var(--ysf-blue)' : i < step ? '#16a34a' : 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                  {s.short}
                </span>
              </button>
              {i < STEPS.length - 1 && (
                <div className="flex-1 h-1.5 mx-2 rounded-full transition-all"
                  style={{ background: i < step ? 'linear-gradient(90deg,#16a34a,#22c55e)' : 'var(--border)' }} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Step card */}
      <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow-md)' }}>

        {/* STEP 1 — Scheme & Company */}
        {step === 0 && (
          <div className="p-6 space-y-5">
            <StepHdr Icon={Building2} title="Scheme & Company Details" subtitle="Select the scheme first — the form adapts based on your selection." color="var(--ysf-blue)" step={1} />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Scheme selector — drives the rest */}
              <div className="sm:col-span-2">
                <Fld label="Scheme" required hint="Selecting a scheme loads its specific requirements and stipend options below">
                  <Sel value={form.scheme} onChange={v => { set('scheme')(v); set('stipend')('') }} options={Object.keys(SCHEME_CONFIG)} placeholder="Select Scheme…" />
                </Fld>
              </div>

              {/* Scheme info card — appears when scheme is selected */}
              {cfg && (
                <div className="sm:col-span-2 rounded-xl overflow-hidden" style={{ border: `1px solid ${cfg.accentColor}25` }}>
                  <div className="px-4 py-3 flex items-center gap-3" style={{ background: `${cfg.accentColor}10` }}>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full"
                      style={{ background: cfg.accentColor, color: '#fff', fontFamily: "'Exo 2', sans-serif" }}>
                      {cfg.badge}
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{cfg.description}</p>
                    </div>
                  </div>
                  <div className="px-4 py-3 grid grid-cols-2 sm:grid-cols-3 gap-3" style={{ background: 'var(--card)', borderTop: `1px solid ${cfg.accentColor}15` }}>
                    <div>
                      <div className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Duration</div>
                      <div className="text-sm font-semibold flex items-center gap-1" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                        <Clock size={12} style={{ color: cfg.accentColor }} /> {cfg.duration}
                      </div>
                    </div>
                    <div className="sm:col-span-2">
                      <div className="text-xs font-bold uppercase tracking-widest mb-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Eligibility</div>
                      <div className="text-sm font-semibold flex items-center gap-1" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                        <BadgeCheck size={12} style={{ color: cfg.accentColor }} /> {cfg.eligibility}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <Fld label="Zone Name" required>
                <Sel value={form.zone} onChange={v => { set('zone')(v); set('company')('') }} options={ZONES} placeholder="Select Zone…" />
              </Fld>

              {/* Company fields — conditionally required based on scheme */}
              {(!cfg || cfg.requiresCompany) && (
                <Fld label="Company Name" required={!cfg || cfg.requiresCompany}>
                  <Sel value={form.company} onChange={set('company')}
                    options={form.zone && ZONE_COMPANIES[form.zone] ? ZONE_COMPANIES[form.zone] : ALL_COMPANIES}
                    placeholder="Select Company…" />
                </Fld>
              )}

              {(!cfg || cfg.showSector) && (
                <Fld label="Company Sector" required={!cfg || cfg.showSector}>
                  <Sel value={form.sector} onChange={set('sector')} options={SECTORS} placeholder="Select Sector…" />
                </Fld>
              )}

              <Fld label="Training Location" required>
                <Sel value={form.location} onChange={set('location')} options={LOCATIONS} placeholder="Select Location…" />
              </Fld>

              {/* Stipend — filtered options per scheme */}
              <Fld label="Stipend Category" required hint={cfg ? `Options for ${form.scheme}` : 'Select a scheme first'}>
                {!form.scheme
                  ? <div className="text-xs italic px-3 py-2.5 rounded-xl"
                      style={{ background: 'var(--muted)', border: '1.5px solid var(--border)', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                      Please select a Scheme first
                    </div>
                  : <Sel value={form.stipend} onChange={set('stipend')} options={cfg?.stipendOptions || []} placeholder="Select Stipend…" />
                }
              </Fld>

              {/* NAPS extra fields */}
              {cfg?.extra === 'naps-fields' && (
                <>
                  <Fld label="Trade Name" required hint="Apprenticeship trade designation">
                    <Sel value={form.tradeName || ''} onChange={v => setForm(f => ({ ...f, tradeName: v }))} options={TRADE_NAMES} placeholder="Select Trade…" />
                  </Fld>
                  <Fld label="Establishment Type" required>
                    <Sel value={form.establishmentType || ''} onChange={v => setForm(f => ({ ...f, establishmentType: v }))} options={ESTAB_TYPES} placeholder="Select Type…" />
                  </Fld>
                </>
              )}

              {cfg?.extra === 'naps-fields' && (
                <div className="sm:col-span-2 rounded-xl p-3 flex items-start gap-2"
                  style={{ background: 'rgba(8,145,178,0.06)', border: '1px solid rgba(8,145,178,0.18)' }}>
                  <Info size={13} style={{ color: '#0891b2', flexShrink: 0, marginTop: 1 }} />
                  <p className="text-xs" style={{ color: '#164e63', fontFamily: "'Exo 2', sans-serif" }}>
                    FLEXI MOU requires a signed <strong>MOU copy</strong> from the industry partner. Ensure it is uploaded under "Other Documents" in Step 4.
                  </p>
                </div>
              )}
            </div>

            {/* Summary chip after selections */}
            {form.scheme && form.zone && (
              <div className="rounded-xl p-3 flex items-center gap-2" style={{ background: 'var(--ysf-blue-light)', border: '1px solid rgba(21,101,192,0.18)' }}>
                <CheckCircle size={14} style={{ color: 'var(--ysf-blue)', flexShrink: 0 }} />
                <p className="text-xs font-semibold" style={{ color: '#1e3a5f', fontFamily: "'Exo 2', sans-serif" }}>
                  {form.scheme} · {form.zone}{form.company ? ` · ${form.company}` : ''}{form.stipend ? ` · ${form.stipend}` : ''}
                </p>
              </div>
            )}
          </div>
        )}

        {/* STEP 2 — Personal Details */}
        {step === 1 && (
          <div className="p-6 space-y-6">
            <StepHdr Icon={User} title="Personal Details" subtitle="Fill in personal, address, course, and banking information." color="var(--ysf-orange)" step={2} />
            <Section label="Basic Information" accent="var(--ysf-blue)">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Fld label="Full Name" required hint="As per 10th Marksheet / Aadhaar card">
                  <Inp value={form.fullName} onChange={set('fullName')} placeholder="e.g. Rahul Kumar Sharma" />
                </Fld>
                <Fld label="Date of Birth" required><Inp type="date" value={form.dob} onChange={set('dob')} /></Fld>
                <Fld label="Aadhaar Number" required hint="12-digit Aadhaar number">
                  <Inp value={form.aadhaar} onChange={set('aadhaar')} placeholder="XXXX XXXX XXXX" />
                </Fld>
                <Fld label="Re-enter Aadhaar" required>
                  <Inp value={form.aadhaarConfirm} onChange={set('aadhaarConfirm')} placeholder="XXXX XXXX XXXX" />
                </Fld>
                <Fld label="Mobile Number" required><Inp type="tel" value={form.mobile} onChange={set('mobile')} placeholder="10-digit mobile" /></Fld>
                <Fld label="Alternate Mobile"><Inp type="tel" value={form.altMobile} onChange={set('altMobile')} placeholder="Optional" /></Fld>
                <Fld label="Email ID" required><Inp type="email" value={form.email} onChange={set('email')} placeholder="example@email.com" /></Fld>
                <Fld label="Birth Place" required><Inp value={form.birthPlace} onChange={set('birthPlace')} placeholder="City / Village of birth" /></Fld>
                <Fld label="Gender" required>
                  <div className="flex gap-3">
                    {['Male', 'Female', 'Other'].map(g => (

                      <button key={g} onClick={() => set('gender')(g)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all"
                        style={form.gender === g
                          ? { background: 'var(--ysf-blue)', color: '#fff', border: 'none', boxShadow: '0 4px 12px rgba(21,101,192,0.25)', fontFamily: "'Exo 2', sans-serif" }
                          : { background: 'var(--card)', color: 'var(--muted-foreground)', border: '1.5px solid var(--border)', fontFamily: "'Exo 2', sans-serif" }}>
                        {g}
                      </button>
                    ))}
                  </div>
                </Fld>
                <Fld label="Physical Disability" required>
                  <div className="flex gap-3">
                    {['No', 'Yes'].map(v => (

                      <button key={v} onClick={() => set('disability')(v)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all"
                        style={form.disability === v
                          ? { background: v === 'Yes' ? 'var(--ysf-orange)' : 'var(--ysf-blue)', color: '#fff', border: 'none', fontFamily: "'Exo 2', sans-serif" }
                          : { background: 'var(--card)', color: 'var(--muted-foreground)', border: '1.5px solid var(--border)', fontFamily: "'Exo 2', sans-serif" }}>
                        {v}
                      </button>
                    ))}
                  </div>
                </Fld>
              </div>
            </Section>
            <Section label="Family Details" accent="var(--ysf-blue)">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Fld label="Father's Name" required><Inp value={form.fatherName} onChange={set('fatherName')} placeholder="Father's full name" /></Fld>
                <Fld label="Mother's Name" required><Inp value={form.motherName} onChange={set('motherName')} placeholder="Mother's full name" /></Fld>
                <Fld label="Father's Occupation"><Inp value={form.fatherOcc} onChange={set('fatherOcc')} placeholder="e.g. Farmer, Labourer" /></Fld>
                <Fld label="Mother's Occupation"><Inp value={form.motherOcc} onChange={set('motherOcc')} placeholder="e.g. Homemaker" /></Fld>
              </div>
            </Section>
            <Section label="Personal Profile" accent="var(--ysf-blue)">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Fld label="Religion" required><Sel value={form.religion} onChange={set('religion')} options={RELIGIONS} /></Fld>
                <Fld label="Caste Category" required><Sel value={form.caste} onChange={set('caste')} options={CASTES} /></Fld>
                <Fld label="Marital Status" required><Sel value={form.marital} onChange={set('marital')} options={MARITAL} /></Fld>
                <Fld label="Blood Group" required><Sel value={form.bloodGroup} onChange={set('bloodGroup')} options={BLOOD_GROUPS} /></Fld>
                <Fld label="Mother Tongue" required><Sel value={form.motherTongue} onChange={set('motherTongue')} options={MOTHER_TONGUE} /></Fld>
                <Fld label="Nationality" hint="Auto-filled"><Inp value={form.nationality} readOnly /></Fld>
                <Fld label="Country" hint="Auto-filled"><Inp value={form.country} readOnly /></Fld>
              </div>
            </Section>
            <Section label="Address" accent="var(--ysf-blue)">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <Fld label="Full Address" required>

                    <textarea value={form.address} onChange={e => set('address')(e.target.value)}
                      placeholder="House No., Street, Locality, Village/Town…" rows={2}
                      style={{ ...IS, resize: 'vertical' }}
                      onFocus={e => { e.target.style.borderColor = 'var(--ysf-blue)'; e.target.style.boxShadow = '0 0 0 3px rgba(21,101,192,0.09)' }}
                      onBlur={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.boxShadow = 'none' }}
                    />
                  </Fld>
                </div>
                <Fld label="State" required><Sel value={form.state} onChange={v => { set('state')(v); set('district')('') }} options={STATES} /></Fld>
                <Fld label="District" required>
                  <Sel value={form.district} onChange={set('district')}
                    options={form.state && DISTRICTS[form.state] ? DISTRICTS[form.state] : []}
                    placeholder={form.state ? 'Select district' : 'Select state first'}
                  />
                </Fld>
                <Fld label="City / Town" required><Inp value={form.city} onChange={set('city')} placeholder="City or Town" /></Fld>
                <Fld label="PIN Code" required><Inp value={form.pincode} onChange={set('pincode')} placeholder="6-digit PIN Code" /></Fld>
              </div>
            </Section>
            <Section label="Course Information" accent="var(--ysf-orange)">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <Fld label="Course Name" required><Sel value={form.courseName} onChange={set('courseName')} options={COURSES} /></Fld>
                <Fld label="NSQF Job Role" required><Sel value={form.jobRole} onChange={set('jobRole')} options={JOB_ROLES} /></Fld>
                <Fld label="NSQF Level" required><Sel value={form.nsqfLevel} onChange={set('nsqfLevel')} options={NSQF_LEVELS} /></Fld>
                <Fld label="Course Start Date" required><Inp type="date" value={form.courseStart} onChange={set('courseStart')} /></Fld>
                <Fld label="Course End Date" required hint="Auto-fetched based on duration"><Inp type="date" value={form.courseEnd} onChange={set('courseEnd')} /></Fld>
              </div>
            </Section>
            <Section label="Banking Details" accent="var(--ysf-orange)">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Fld label="Bank Name" required><Inp value={form.bankName} onChange={set('bankName')} placeholder="e.g. State Bank of India" /></Fld>
                <Fld label="Account Number" required><Inp value={form.accountNo} onChange={set('accountNo')} placeholder="Account number" /></Fld>
                <Fld label="IFSC Code" required hint="11-character code"><Inp value={form.ifsc} onChange={set('ifsc')} placeholder="e.g. SBIN0001234" /></Fld>
              </div>
            </Section>
          </div>
        )}

        {/* STEP 3 — Education */}
        {step === 2 && (
          <div className="p-6 space-y-5">
            <StepHdr Icon={GraduationCap} title="Education Details" subtitle="Add all qualifications. Percentage is auto-calculated." color="#7c3aed" step={3} />
            <div className="space-y-4">
              {form.education.map((edu, idx) => (
                <div key={edu.id} className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', background: 'var(--card)' }}>
                  <div className="flex items-center justify-between px-4 py-3" style={{ background: 'var(--muted)', borderBottom: '1px solid var(--border)' }}>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white"
                        style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)' }}>{idx + 1}</div>
                      <span className="font-bold text-sm" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>
                        {edu.qualification || `Qualification ${idx + 1}`}
                      </span>
                      {edu.percentage && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-bold"
                          style={{ background: 'rgba(22,163,74,0.10)', color: '#16a34a', fontFamily: "'Exo 2', sans-serif" }}>{edu.percentage}%</span>
                      )}
                    </div>
                    {form.education.length > 1 && (

                      <button onClick={() => removeEdu(edu.id)}
                        className="text-xs flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all"
                        style={{ color: 'var(--ysf-red)', background: 'var(--ysf-red-light)', border: '1px solid rgba(229,57,53,0.20)', fontFamily: "'Exo 2', sans-serif" }}>
                        <Trash2 size={11} /> Remove
                      </button>
                    )}
                  </div>
                  <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <Fld label="Qualification" required><Sel value={edu.qualification} onChange={v => updateEdu(edu.id, 'qualification', v)} options={QUALIFICATIONS} /></Fld>
                    <Fld label="Board / University" required><Inp value={edu.board} onChange={v => updateEdu(edu.id, 'board', v)} placeholder="e.g. CBSE / Osmania Univ." /></Fld>
                    <Fld label="Passing Year" required><Sel value={edu.year} onChange={v => updateEdu(edu.id, 'year', v)} options={YEARS} placeholder="Select Year…" /></Fld>
                    <Fld label="Total Marks" required><Inp value={edu.totalMarks} onChange={v => updateEdu(edu.id, 'totalMarks', v)} placeholder="e.g. 500" /></Fld>
                    <Fld label="Obtained Marks" required><Inp value={edu.obtainedMarks} onChange={v => updateEdu(edu.id, 'obtainedMarks', v)} placeholder="e.g. 425" /></Fld>
                    <Fld label="Percentage" hint="Auto-calculated">
                      <div style={{ position: 'relative' }}>
                        <Inp value={edu.percentage ? `${edu.percentage}%` : ''} readOnly placeholder="Auto-calculated" />
                        {edu.percentage && (
                          <div style={{ position: 'absolute', insetBlock: 0, right: 8, display: 'flex', alignItems: 'center' }}>
                            <div className="w-14 h-1.5 rounded-full" style={{ background: 'var(--border)' }}>
                              <div className="h-1.5 rounded-full"
                                style={{ width: `${Math.min(parseFloat(edu.percentage), 100)}%`, background: parseFloat(edu.percentage) >= 75 ? '#16a34a' : parseFloat(edu.percentage) >= 50 ? 'var(--ysf-blue)' : 'var(--ysf-orange)' }} />
                            </div>
                          </div>
                        )}
                      </div>
                    </Fld>
                  </div>
                </div>
              ))}
            </div>

            <button onClick={addEdu}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all"
              style={{ background: 'var(--ysf-blue-light)', color: 'var(--ysf-blue)', border: '1.5px dashed rgba(21,101,192,0.30)', fontFamily: "'Exo 2', sans-serif" }}>
              <Plus size={15} /> Add Another Qualification
            </button>
          </div>
        )}

        {/* STEP 4 — Documents */}
        {step === 3 && (
          <div className="p-6 space-y-5">
            <StepHdr Icon={FolderOpen} title="Document Upload" subtitle="Upload all required documents. Supported: JPG, PNG, PDF (max 2MB each)." color="#7c3aed" step={4} />
            <div className="rounded-xl p-4 flex items-center gap-4" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-bold" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>Upload Progress</span>
                  <span className="text-xs font-bold" style={{ color: uploadedCount >= 8 ? '#16a34a' : 'var(--ysf-orange)', fontFamily: 'Rajdhani, sans-serif' }}>
                    {uploadedCount} / {REQUIRED_DOCS.length}
                  </span>
                </div>

                <div className="h-2 rounded-full" style={{ background: 'var(--border)' }}>
                  <div className="h-2 rounded-full transition-all"
                    style={{ width: `${(uploadedCount / REQUIRED_DOCS.length) * 100}%`, background: uploadedCount >= 8 ? 'linear-gradient(90deg,#16a34a,#22c55e)' : 'linear-gradient(90deg,var(--ysf-blue),var(--ysf-orange))' }} />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {REQUIRED_DOCS.map(doc => {
                const info = form.docs[doc.key]
                return (

                  <button key={doc.key} onClick={() => toggleDoc(doc.key)}
                    className="rounded-xl p-4 text-left transition-all"
                    style={info.uploaded
                      ? { background: 'rgba(220,252,231,0.7)', border: '1.5px solid rgba(22,163,74,0.30)' }
                      : { background: 'var(--card)', border: `1.5px dashed ${doc.required ? 'rgba(21,101,192,0.30)' : 'var(--border)'}` }}
                    onMouseEnter={e => !info.uploaded && (e.currentTarget.style.borderColor = 'var(--ysf-blue)')}
                    onMouseLeave={e => !info.uploaded && (e.currentTarget.style.borderColor = doc.required ? 'rgba(21,101,192,0.30)' : 'var(--border)')}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                        style={{ background: info.uploaded ? 'rgba(22,163,74,0.15)' : 'var(--ysf-blue-light)', color: info.uploaded ? '#16a34a' : 'var(--ysf-blue)' }}>
                        {info.uploaded ? <CheckCircle size={18} /> : <Upload size={16} />}
                      </div>
                      <span className="text-xs px-2 py-0.5 rounded-full font-semibold"
                        style={doc.required
                          ? { background: 'rgba(249,115,22,0.10)', color: 'var(--ysf-orange)', fontFamily: "'Exo 2', sans-serif" }
                          : { background: 'var(--muted)', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
                        {doc.required ? 'Required' : 'Optional'}
                      </span>
                    </div>
                    <div className="font-bold text-sm mb-0.5" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{doc.label}</div>
                    {info.uploaded
                      ? <div className="text-xs font-mono truncate" style={{ color: '#16a34a' }}>{info.name}</div>
                      : <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{doc.hint}</div>}
                  </button>
                )
              })}
            </div>
          </div>
        )}

        {/* STEP 5 — Review & Submit */}
        {step === 4 && (
          <div className="p-6 space-y-5">
            <StepHdr Icon={CheckCircle} title="Review & Submit" subtitle="Verify all details. Generate Undertaking / OJT Offer Letter, then submit." color="#16a34a" step={5} />
            <div className="rounded-xl p-4 flex flex-col sm:flex-row sm:items-center gap-3"
              style={{ background: 'linear-gradient(120deg,var(--ysf-blue),#1976D2)', color: '#fff' }}>
              <div className="flex-1">
                <div className="font-bold text-sm mb-1" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Generate Undertaking / OJT Offer Letter</div>
                <div className="text-xs opacity-80" style={{ fontFamily: "'Exo 2', sans-serif" }}>Auto-generated PDF with trainee details. Required before submission.</div>
              </div>

              <button className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm flex-shrink-0"
                style={{ background: 'white', color: 'var(--ysf-blue)', fontFamily: 'Rajdhani, sans-serif' }}>
                <FileText size={14} /> Generate PDF
              </button>
            </div>
            <RevSection title="Scheme & Company" accent="var(--ysf-blue)">
              <RevGrid items={[
                { label: 'Scheme', value: form.scheme || '—' },
                { label: 'Zone', value: form.zone || '—' },
                { label: 'Company', value: form.company || '—' },
                { label: 'Location', value: form.location || '—' },
                { label: 'Stipend', value: form.stipend || '—' },
                ...(form.tradeName ? [{ label: 'Trade', value: form.tradeName }] : []),
              ]} onEdit={() => setStep(0)} />
            </RevSection>
            <RevSection title="Personal Information" accent="var(--ysf-blue)">
              <RevGrid items={[
                { label: 'Full Name', value: form.fullName || '—' },
                { label: 'DOB', value: form.dob || '—' },
                { label: 'Aadhaar', value: form.aadhaar || '—' },
                { label: 'Mobile', value: form.mobile || '—' },
                { label: 'Gender', value: form.gender || '—' },
                { label: 'State', value: form.state || '—' },
              ]} onEdit={() => setStep(1)} />
            </RevSection>
            <RevSection title="Education" accent="#7c3aed">
              <div className="space-y-2">
                {form.education.map(edu => (
                  <div key={edu.id} className="flex items-center justify-between p-3 rounded-xl"
                    style={{ background: edu.board ? 'rgba(220,252,231,0.5)' : 'var(--muted)', border: '1px solid var(--border)' }}>
                    <div>
                      <div className="text-sm font-semibold" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{edu.qualification || '—'}</div>
                      <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{edu.board || '—'} · {edu.year || '—'}</div>
                    </div>
                    {edu.percentage && <span className="font-bold text-sm px-3 py-1 rounded-full"
                      style={{ background: 'rgba(22,163,74,0.12)', color: '#16a34a', fontFamily: 'Rajdhani, sans-serif' }}>{edu.percentage}%</span>}
                  </div>
                ))}
              </div>

              <button className="text-xs mt-2 font-semibold" style={{ color: 'var(--ysf-blue)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Exo 2', sans-serif" }}
                onClick={() => setStep(2)}>Edit Education →</button>
            </RevSection>
            <div className="rounded-xl p-4 flex items-start gap-3" style={{ background: 'rgba(245,158,11,0.07)', border: '1px solid rgba(245,158,11,0.22)' }}>
              <AlertTriangle size={15} style={{ color: '#92400e', flexShrink: 0, marginTop: 2 }} />
              <p className="text-xs" style={{ color: '#92400e', fontFamily: "'Exo 2', sans-serif" }}>
                By submitting, you confirm all information is accurate. Any false information may lead to rejection. A temporary code will be issued immediately.
              </p>
            </div>
          </div>
        )}

        {/* Nav buttons */}
        <div className="px-6 py-4 flex items-center justify-between" style={{ borderTop: '1px solid var(--border)', background: 'var(--muted)' }}>

          <button onClick={back} disabled={step === 0}
            className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all"
            style={{ border: '1.5px solid var(--border)', color: step === 0 ? 'var(--muted-foreground)' : 'var(--foreground)', cursor: step === 0 ? 'not-allowed' : 'pointer', background: 'var(--card)', fontFamily: "'Exo 2', sans-serif", opacity: step === 0 ? 0.5 : 1 }}>
            ← Back
          </button>
          <span className="text-xs font-semibold" style={{ color: 'var(--muted-foreground)', fontFamily: 'JetBrains Mono, monospace' }}>
            Step {step + 1} / {STEPS.length}
          </span>
          {step < 4
            ? <button onClick={next}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-white font-bold text-sm transition-all"
                style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', boxShadow: '0 6px 20px rgba(21,101,192,0.28)', fontFamily: 'Rajdhani, sans-serif' }}>
                Save & Continue →
              </button>
            : <button onClick={submit}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-white font-bold text-sm transition-all"
                style={{ background: 'linear-gradient(135deg,#16a34a,#22c55e)', boxShadow: '0 6px 20px rgba(22,163,74,0.28)', fontFamily: 'Rajdhani, sans-serif' }}>
                <Check size={15} /> Submit Application
              </button>}
        </div>
      </div>
    </div>
  )
}

/* ── Success screen ────────────────────────────────────────────────── */
function SuccessScreen({ tempCode, onReset, onNavigate, form, source }:
  { tempCode: string; onReset: () => void; onNavigate: (s: string) => void; form: FormData; source: string }) {
  const now = new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <div className="rounded-2xl overflow-hidden text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)', boxShadow: 'var(--card-shadow-lg)' }}>
        <div style={{ background: 'linear-gradient(135deg,#16a34a,#22c55e)', padding: '36px 24px 28px' }}>
          <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4"
            style={{ background: 'rgba(255,255,255,0.25)' }}>
            <CheckCircle size={40} color="white" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: 'Rajdhani, sans-serif' }}>Registration Submitted!</h2>
          <p className="text-sm text-white opacity-80" style={{ fontFamily: "'Exo 2', sans-serif" }}>
            Application routed for Admin verification · {source === 'hard-copy' ? 'Uploaded hard-copy form' : 'Online registration'}
          </p>
        </div>
        <div className="p-8">
          <div className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Temporary Registration Code</div>
          <div className="rounded-xl p-5 mb-2 inline-block" style={{ background: 'var(--ysf-blue-light)', border: '2px solid rgba(21,101,192,0.25)' }}>
            <div className="text-2xl font-bold tracking-wider" style={{ color: 'var(--ysf-blue)', fontFamily: 'JetBrains Mono, monospace' }}>{tempCode}</div>
          </div>
          <div className="text-xs mb-2" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>Generated: {now}</div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold"
            style={{ background: 'rgba(245,158,11,0.10)', color: '#92400e', border: '1px solid rgba(245,158,11,0.25)', fontFamily: "'Exo 2', sans-serif" }}>
            <span className="w-2 h-2 rounded-full" style={{ background: 'var(--ysf-yellow)' }} /> Status: Pending Verification
          </div>
          <div className="grid grid-cols-3 gap-3 mt-6">
            {[
              { Icon: ClipboardList, label: 'Trainee',  value: form.fullName || 'Registered' },
              { Icon: Layers,        label: 'Scheme',   value: form.scheme   || 'N/A'        },
              { Icon: Mail,          label: 'SMS to',   value: form.mobile   || 'N/A'        },
            ].map(s => (
              <div key={s.label} className="rounded-xl p-3" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
                <div className="flex justify-center mb-1.5" style={{ color: 'var(--ysf-blue)' }}><s.Icon size={16} /></div>
                <div className="text-xs" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{s.label}</div>
                <div className="text-xs font-bold truncate" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{s.value}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="px-8 pb-8 flex flex-col sm:flex-row gap-3 justify-center">

          <button onClick={onReset}
            className="px-6 py-2.5 rounded-xl font-semibold text-sm"
            style={{ border: '1.5px solid var(--border)', color: 'var(--foreground)', background: 'var(--card)', fontFamily: "'Exo 2', sans-serif" }}>
            Register Another
          </button>
          <button onClick={() => onNavigate('recent-registrations')}
            className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl text-white font-bold text-sm"
            style={{ background: 'linear-gradient(135deg,var(--ysf-blue),#1976D2)', boxShadow: '0 6px 20px rgba(21,101,192,0.28)', fontFamily: 'Rajdhani, sans-serif' }}>
            View Recent Registrations →
          </button>
        </div>
      </div>
    </div>
  )
}

/* ── Helpers ───────────────────────────────────────────────────────── */
function StepHdr({ Icon, title, subtitle, color, step }: { Icon: React.ElementType; title: string; subtitle: string; color: string; step: number }) {
  return (
    <div className="flex items-start gap-4 pb-5" style={{ borderBottom: '1px solid var(--border)' }}>
      <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}14`, border: `1.5px solid ${color}25`, color }}>
        <Icon size={20} />
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-0.5">
          <h2 className="text-lg font-bold" style={{ color: 'var(--foreground)', fontFamily: 'Rajdhani, sans-serif' }}>{title}</h2>
          <span className="text-xs font-bold px-2 py-0.5 rounded-full"
            style={{ background: `${color}12`, color, fontFamily: "'Exo 2', sans-serif" }}>Step {step}</span>
        </div>
        <p className="text-sm" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{subtitle}</p>
      </div>
    </div>
  )
}

function RevSection({ title, accent = 'var(--ysf-blue)', children }: { label?: string; title: string; accent?: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl overflow-hidden" style={{ border: '1px solid var(--border)', borderTop: `3px solid ${accent}` }}>
      <div className="px-4 py-3 text-xs font-bold uppercase tracking-widest"
        style={{ background: 'var(--muted)', borderBottom: '1px solid var(--border)', color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>
        {title}
      </div>
      <div className="p-4">{children}</div>
    </div>
  )
}

function RevGrid({ items, onEdit }: { items: { label: string; value: string }[]; onEdit: () => void }) {
  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 mb-2">
        {items.map(it => (
          <div key={it.label}>
            <div className="text-xs mb-0.5" style={{ color: 'var(--muted-foreground)', fontFamily: "'Exo 2', sans-serif" }}>{it.label}</div>
            <div className="text-sm font-semibold truncate" style={{ color: 'var(--foreground)', fontFamily: "'Exo 2', sans-serif" }}>{it.value}</div>
          </div>
        ))}
      </div>

      <button onClick={onEdit} className="text-xs font-semibold"
        style={{ color: 'var(--ysf-blue)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: "'Exo 2', sans-serif" }}>
        Edit this section →
      </button>
    </div>
  )
}

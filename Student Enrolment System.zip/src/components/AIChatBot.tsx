import { useState, useRef, useEffect, useCallback } from 'react'
import { X, Send, Bot, ChevronDown, Sparkles, RotateCcw, Mic, MicOff, Volume2, VolumeX, Globe } from 'lucide-react'

/* ── Web Speech API types ──────────────────────────────────────── */
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList
  resultIndex: number
}
interface SpeechRecognitionResult { isFinal: boolean; 0: { transcript: string } }
interface SpeechRecognitionResultList {
  length: number; item(i: number): SpeechRecognitionResult; [i: number]: SpeechRecognitionResult
}
interface SpeechRecognitionErrorEvent extends Event {
  error: 'not-allowed' | 'no-speech' | 'audio-capture' | 'network' | 'aborted' | 'service-not-allowed' | string
}
interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean; interimResults: boolean; lang: string
  start(): void; stop(): void; abort(): void
  onresult: ((e: SpeechRecognitionEvent) => void) | null
  onerror: ((e: SpeechRecognitionErrorEvent) => void) | null
  onend: (() => void) | null
}
declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance
  }
}

/* ── Types ─────────────────────────────────────────────────────── */
interface Message { id: number; role: 'user' | 'bot'; text: string; time: string; isVoice?: boolean }

/* ── Language config ───────────────────────────────────────────── */
interface LangStrings {
  greeting: string
  quickPrompts: [string, string, string, string]
  placeholder: string
  listenHint: string
  stopSend: string
  cancel: string
  autoSpeakOn: string
  autoSpeakOff: string
  voiceEnabled: string
  micDenied: string
  noMic: string
  networkErr: string
  noSpeech: string
  fallback: string
  kb: {
    register: string
    documents: string
    batch: string
    payroll: string
    verification: string
    code: string
    search: string
    scheme: string
    form: string
    help: string
    login: string
    export: string
    pending: string
  }
}

const LANGS: Record<string, { name: string; native: string; locale: string; s: LangStrings }> = {
  'en-IN': {
    name: 'English', native: 'English', locale: 'en-IN',
    s: {
      greeting: "Hi! I'm **SES Assistant** — your AI guide.\n\nAsk me anything or tap the **mic** to speak. I can help with registration, batches, documents, payroll and more.",
      quickPrompts: ['How do I register a trainee?', 'What documents are required?', 'How do I create a monthly batch?', 'How does verification work?'],
      placeholder: 'Type or tap mic to ask…',
      listenHint: "Speak now — I'm hearing you",
      stopSend: 'Stop & Send', cancel: 'Cancel',
      autoSpeakOn: 'Auto-speak on', autoSpeakOff: 'Auto-speak off',
      voiceEnabled: 'Voice enabled',
      micDenied: "Microphone access was denied. Click the 🔒 icon in your browser's address bar, allow microphone access, then try again.",
      noMic: 'No microphone found. Please connect a microphone and try again.',
      networkErr: 'Network error during voice recognition. Please check your connection.',
      noSpeech: '',
      fallback: "I'm not sure about that. I can help with:\n• Trainee registration & forms\n• Document uploads\n• Batch creation & allocation\n• Payroll eligibility\n• Verification workflow\n\nTry rephrasing your question!",
      kb: {
        register: `To register a new trainee:\n1. Click **Register Trainee** in the left sidebar.\n2. Fill the **Personal Info** tab — full name, date of birth, gender, Aadhaar, mobile.\n3. Upload required documents (Aadhaar, photo, 10th certificate, bank passbook, offer letter).\n4. Select the scheme, company, and batch.\n5. Click **Submit** — a temporary trainee code is generated.\n\nThe application enters the Verification Queue for approval.`,
        documents: `Required documents:\n• **Aadhaar Card** — front and back scan\n• **Passport Photo** — recent, plain background\n• **10th Certificate** — age & education proof\n• **Bank Passbook** — first page with IFSC & account number\n• **Offer Letter** — from the company\n\nUpload as PDF or JPG, max 5 MB each.`,
        batch: `To create a monthly batch:\n1. Go to **Batch Management** in the sidebar.\n2. Click **+ Create Monthly Batch**.\n3. Select Month, Scheme, Zone, and Company.\n4. Enter a **Payroll Batch Name** and expected trainee count.\n5. Click **Generate Batch** — payroll-eligible trainees appear.\n6. Select trainees and click **Assign Selected Trainees**.`,
        payroll: `A trainee is **Payroll Eligible** when:\n• Aadhaar and bank details are verified\n• Company has confirmed the offer letter\n• Status is **Approved** in the system\n\nUse the **Payroll Eligible Only** filter in Batch Management to list them.`,
        verification: `Verification steps:\n1. Registered applications appear in the **Verification Queue**.\n2. Branch manager reviews documents and personal info.\n3. Click **Approve** — a permanent fixed code is generated.\n4. Click **Reject** if details are incorrect — trainee must re-submit.\n\nFilter by Pending, Approved, or Rejected in the queue.`,
        code: `Every trainee gets two codes:\n• **Temp Code** — assigned at registration (e.g. TRN000154)\n• **Fixed Code** — assigned after approval: COMPANY/SCHEME/YEAR/SERIAL\n\nSearch by either code in Search Trainee or Batch Allocation.`,
        search: `To find a trainee:\n• **Branch role:** Search Trainee in the sidebar\n• **Management role:** Search Trainee in the management menu\n\nSearch by: Trainee Code, Aadhaar, Mobile, or Name.\nClick any result to open the full Trainee Profile.`,
        scheme: `Supported schemes:\n• **PMKVY** — Pradhan Mantri Kaushal Vikas Yojana\n• **DDUGKY** — Deen Dayal Upadhyaya Grameen Kaushalya Yojana\n• **WILP** — Work Integrated Learning Programme\n• **BVOC** — Bachelor of Vocational Education\n• **DVOC** — Diploma in Vocational Education\n• **FLEXI** — Flexible MOU-based training\n• **MSBTE** — Maharashtra State Board of Technical Education`,
        form: `Registration form has 4 sections:\n**1. Personal Info** — Name, DOB, Gender, Aadhaar, Mobile, Email, Address\n**2. Employment Info** — Company, Designation, DOJ, Scheme, Zone\n**3. Documents** — Upload all 5 required files\n**4. Review & Submit** — Confirm before submission\n\nFields marked * are mandatory.`,
        help: `I can help with:\n• Registering trainees & filling forms\n• Document requirements & uploads\n• Batch creation & trainee allocation\n• Payroll eligibility & status\n• Verification & approval workflow\n• Searching trainee profiles\n• KPI dashboard & reports\n• Login roles & access`,
        login: `SES has two login roles:\n• **Branch** — center staff for registration, documents, verification\n• **Management** — head-office staff for analytics, search, batch oversight\n\nSelect your role on the login screen and enter your credentials.`,
        export: `To export data:\n• In **Batch Management** — Export Report button downloads a CSV\n• In **Reports** — generate scheme/company/date-range reports as PDF or Excel\n\nFiles are named with the current date.`,
        pending: `For incomplete registrations:\n1. See the **Payroll Alert** banner in Batch Management.\n2. Click **View Pending Registration** or **Complete Reg.** in the trainee table.\n3. Open each trainee profile, upload missing documents, correct details.\n4. Re-submit for verification.`,
      },
    },
  },

  'hi-IN': {
    name: 'Hindi', native: 'हिन्दी', locale: 'hi-IN',
    s: {
      greeting: "नमस्ते! मैं **SES सहायक** हूँ — आपका AI मार्गदर्शक।\n\nकुछ भी पूछें या **माइक** टैप करके बोलें। मैं पंजीकरण, बैच, दस्तावेज़, वेतन और अधिक में मदद कर सकता हूँ।",
      quickPrompts: ['प्रशिक्षु कैसे पंजीकृत करें?', 'कौन से दस्तावेज़ चाहिए?', 'मासिक बैच कैसे बनाएं?', 'सत्यापन कैसे होता है?'],
      placeholder: 'टाइप करें या माइक से पूछें…',
      listenHint: 'अभी बोलें — मैं सुन रहा हूँ',
      stopSend: 'रोकें और भेजें', cancel: 'रद्द करें',
      autoSpeakOn: 'ऑटो-बोलना चालू', autoSpeakOff: 'ऑटो-बोलना बंद',
      voiceEnabled: 'आवाज़ सक्रिय',
      micDenied: 'माइक्रोफोन की अनुमति अस्वीकार की गई। ब्राउज़र के 🔒 पते पर क्लिक करें, माइक्रोफोन अनुमति दें, फिर दोबारा प्रयास करें।',
      noMic: 'कोई माइक्रोफोन नहीं मिला। कृपया माइक्रोफोन कनेक्ट करें।',
      networkErr: 'नेटवर्क त्रुटि। कृपया अपना कनेक्शन जांचें।',
      noSpeech: '',
      fallback: "मुझे इस सवाल का उत्तर नहीं पता। मैं इनमें मदद कर सकता हूँ:\n• प्रशिक्षु पंजीकरण\n• दस्तावेज़ अपलोड\n• बैच बनाना\n• वेतन पात्रता\n• सत्यापन प्रक्रिया\n\nकृपया अपना सवाल दोबारा पूछें!",
      kb: {
        register: `नया प्रशिक्षु पंजीकृत करने के लिए:\n1. बाईं साइडबार में **प्रशिक्षु पंजीकृत करें** पर क्लिक करें।\n2. **व्यक्तिगत जानकारी** टैब भरें — पूरा नाम, जन्म तिथि, लिंग, आधार, मोबाइल।\n3. आवश्यक दस्तावेज़ अपलोड करें।\n4. योजना, कंपनी और बैच चुनें।\n5. **सबमिट** पर क्लिक करें — अस्थायी कोड बनेगा।\n\nआवेदन सत्यापन कतार में जाएगा।`,
        documents: `आवश्यक दस्तावेज़:\n• **आधार कार्ड** — आगे और पीछे की स्कैन\n• **पासपोर्ट फोटो** — हालिया, सादे पृष्ठभूमि पर\n• **10वीं प्रमाण पत्र** — आयु और शिक्षा प्रमाण\n• **बैंक पासबुक** — पहला पृष्ठ IFSC और खाता नंबर सहित\n• **ऑफर लेटर** — कंपनी से\n\nPDF या JPG फॉर्मेट में, अधिकतम 5 MB।`,
        batch: `मासिक बैच बनाने के लिए:\n1. साइडबार से **बैच प्रबंधन** खोलें।\n2. **+ मासिक बैच बनाएं** पर क्लिक करें।\n3. माह, योजना, क्षेत्र और कंपनी चुनें।\n4. **पेरोल बैच नाम** और अपेक्षित प्रशिक्षु संख्या दर्ज करें।\n5. **बैच तैयार करें** पर क्लिक करें।\n6. प्रशिक्षुओं को चुनें और **चुने हुए प्रशिक्षुओं को असाइन करें** पर क्लिक करें।`,
        payroll: `प्रशिक्षु **वेतन पात्र** होता है जब:\n• उनका आधार और बैंक विवरण सत्यापित हो\n• कंपनी ने ऑफर लेटर की पुष्टि की हो\n• स्थिति **स्वीकृत** हो\n\nबैच प्रबंधन में **केवल वेतन पात्र** फ़िल्टर का उपयोग करें।`,
        verification: `सत्यापन प्रक्रिया:\n1. पंजीकृत आवेदन **सत्यापन कतार** में जाते हैं।\n2. शाखा प्रबंधक दस्तावेज़ और जानकारी जांचता है।\n3. **स्वीकृत करें** पर क्लिक करें — स्थायी कोड बनता है।\n4. **अस्वीकार करें** पर क्लिक करें यदि जानकारी गलत है।`,
        code: `हर प्रशिक्षु को दो कोड मिलते हैं:\n• **अस्थायी कोड** — पंजीकरण पर (जैसे TRN000154)\n• **स्थायी कोड** — स्वीकृति के बाद: COMPANY/SCHEME/YEAR/SERIAL\n\nखोज में किसी भी कोड का उपयोग करें।`,
        search: `प्रशिक्षु खोजने के लिए:\n• **शाखा भूमिका:** साइडबार में प्रशिक्षु खोजें\n• **प्रबंधन भूमिका:** प्रबंधन मेनू में खोजें\n\nप्रशिक्षु कोड, आधार, मोबाइल या नाम से खोजें।`,
        scheme: `समर्थित योजनाएं:\n• PMKVY — प्रधान मंत्री कौशल विकास योजना\n• DDUGKY — दीन दयाल उपाध्याय ग्रामीण कौशल्या योजना\n• WILP — कार्य एकीकृत शिक्षण कार्यक्रम\n• BVOC, DVOC, FLEXI, MSBTE`,
        form: `पंजीकरण फॉर्म में 4 भाग हैं:\n**1. व्यक्तिगत जानकारी** — नाम, जन्म तिथि, लिंग, आधार, मोबाइल\n**2. रोजगार जानकारी** — कंपनी, पद, योजना\n**3. दस्तावेज़** — सभी 5 फाइलें अपलोड करें\n**4. समीक्षा और सबमिट करें**\n\n* से चिह्नित फ़ील्ड अनिवार्य हैं।`,
        help: `मैं इनमें मदद कर सकता हूँ:\n• प्रशिक्षु पंजीकरण और फॉर्म भरना\n• दस्तावेज़ आवश्यकताएं\n• बैच बनाना और असाइन करना\n• वेतन पात्रता\n• सत्यापन और अनुमोदन\n• प्रशिक्षु प्रोफ़ाइल खोज\n• KPI डैशबोर्ड और रिपोर्ट`,
        login: `SES में दो भूमिकाएं हैं:\n• **शाखा** — केंद्र स्टाफ (पंजीकरण, दस्तावेज़, सत्यापन)\n• **प्रबंधन** — मुख्यालय स्टाफ (विश्लेषण, खोज, बैच)\n\nलॉगिन स्क्रीन पर अपनी भूमिका चुनें।`,
        export: `डेटा निर्यात करने के लिए:\n• **बैच प्रबंधन** में — CSV डाउनलोड करें\n• **रिपोर्ट** में — PDF या Excel फॉर्मेट में`,
        pending: `अधूरे पंजीकरण के लिए:\n1. बैच प्रबंधन में **पेरोल अलर्ट** बैनर देखें।\n2. **लंबित पंजीकरण देखें** पर क्लिक करें।\n3. प्रशिक्षु की प्रोफ़ाइल खोलें, दस्तावेज़ अपलोड करें।\n4. सत्यापन के लिए पुनः सबमिट करें।`,
      },
    },
  },

  'mr-IN': {
    name: 'Marathi', native: 'मराठी', locale: 'mr-IN',
    s: {
      greeting: "नमस्कार! मी **SES सहायक** आहे — तुमचा AI मार्गदर्शक।\n\nकाहीही विचारा किंवा **मायक्रोफोन** टॅप करून बोला. नोंदणी, तुकडी, कागदपत्रे, वेतन आणि अधिकमध्ये मदत करतो।",
      quickPrompts: ['प्रशिक्षणार्थी कसे नोंदवायचे?', 'कोणती कागदपत्रे लागतात?', 'मासिक तुकडी कशी तयार करायची?', 'पडताळणी कशी होते?'],
      placeholder: 'टाइप करा किंवा मायक्रोफोनने विचारा…',
      listenHint: 'आता बोला — मी ऐकतो आहे',
      stopSend: 'थांबा आणि पाठवा', cancel: 'रद्द करा',
      autoSpeakOn: 'स्वयं-बोलणे चालू', autoSpeakOff: 'स्वयं-बोलणे बंद',
      voiceEnabled: 'आवाज सक्रिय',
      micDenied: 'मायक्रोफोनची परवानगी नाकारली गेली. ब्राउझरच्या 🔒 चिन्हावर क्लिक करा, मायक्रोफोन परवानगी द्या आणि पुन्हा प्रयत्न करा.',
      noMic: 'मायक्रोफोन आढळला नाही. कृपया मायक्रोफोन जोडा.',
      networkErr: 'नेटवर्क त्रुटी. कृपया आपले कनेक्शन तपासा.',
      noSpeech: '',
      fallback: "या प्रश्नाचे उत्तर मला माहीत नाही. मी यात मदत करू शकतो:\n• प्रशिक्षणार्थी नोंदणी\n• कागदपत्रे अपलोड\n• तुकडी तयार करणे\n• वेतन पात्रता\n• पडताळणी प्रक्रिया\n\nकृपया प्रश्न पुन्हा विचारा!",
      kb: {
        register: `नवीन प्रशिक्षणार्थी नोंदणी करण्यासाठी:\n1. डाव्या साइडबारमध्ये **प्रशिक्षणार्थी नोंद करा** वर क्लिक करा.\n2. **वैयक्तिक माहिती** टॅब भरा — पूर्ण नाव, जन्म तारीख, लिंग, आधार, मोबाईल.\n3. आवश्यक कागदपत्रे अपलोड करा.\n4. योजना, कंपनी आणि तुकडी निवडा.\n5. **सबमिट** करा — तात्पुरता कोड तयार होईल.\n\nअर्ज पडताळणी रांगेत जाईल.`,
        documents: `आवश्यक कागदपत्रे:\n• **आधार कार्ड** — समोर आणि मागे स्कॅन\n• **पासपोर्ट फोटो** — अलीकडील, साध्या पार्श्वभूमीवर\n• **10वी प्रमाणपत्र** — वय आणि शिक्षणाचा पुरावा\n• **बँक पासबुक** — IFSC आणि खाते क्रमांकासह पहिले पान\n• **ऑफर लेटर** — कंपनीकडून\n\nPDF किंवा JPG मध्ये, जास्तीत जास्त 5 MB.`,
        batch: `मासिक तुकडी तयार करण्यासाठी:\n1. साइडबारमधून **तुकडी व्यवस्थापन** उघडा.\n2. **+ मासिक तुकडी तयार करा** वर क्लिक करा.\n3. महिना, योजना, क्षेत्र आणि कंपनी निवडा.\n4. **पेरोल तुकडीचे नाव** आणि अपेक्षित प्रशिक्षणार्थी संख्या प्रविष्ट करा.\n5. **तुकडी तयार करा** वर क्लिक करा.\n6. प्रशिक्षणार्थी निवडा आणि **निवडलेल्यांना नियुक्त करा** वर क्लिक करा.`,
        payroll: `प्रशिक्षणार्थी **वेतन पात्र** असतो जेव्हा:\n• आधार आणि बँक तपशील पडताळलेले असतात\n• कंपनीने ऑफर लेटरची पुष्टी केली असते\n• स्थिती **मंजूर** असते\n\nतुकडी व्यवस्थापनात **केवळ वेतन पात्र** फिल्टर वापरा.`,
        verification: `पडताळणी प्रक्रिया:\n1. नोंदणी केलेले अर्ज **पडताळणी रांगेत** जातात.\n2. शाखा व्यवस्थापक कागदपत्रे आणि माहिती तपासतो.\n3. **मंजूर करा** वर क्लिक करा — कायमस्वरूपी कोड तयार होतो.\n4. माहिती चुकीची असल्यास **नाकारा** वर क्लिक करा.`,
        code: `प्रत्येक प्रशिक्षणार्थ्याला दोन कोड मिळतात:\n• **तात्पुरता कोड** — नोंदणीवेळी (उदा. TRN000154)\n• **कायमस्वरूपी कोड** — मंजुरीनंतर: COMPANY/SCHEME/YEAR/SERIAL\n\nशोधात दोन्हीपैकी कोणताही कोड वापरा.`,
        search: `प्रशिक्षणार्थी शोधण्यासाठी:\n• **शाखा भूमिका:** साइडबारमध्ये प्रशिक्षणार्थी शोधा\n• **व्यवस्थापन भूमिका:** व्यवस्थापन मेनूमध्ये शोधा\n\nकोड, आधार, मोबाईल किंवा नावाने शोधा.`,
        scheme: `समर्थित योजना:\n• PMKVY — प्रधानमंत्री कौशल्य विकास योजना\n• DDUGKY — दीन दयाल उपाध्याय ग्रामीण कौशल्या योजना\n• WILP — कार्य एकात्मिक शिक्षण कार्यक्रम\n• BVOC, DVOC, FLEXI, MSBTE`,
        form: `नोंदणी फॉर्मचे 4 भाग:\n**1. वैयक्तिक माहिती** — नाव, जन्म तारीख, लिंग, आधार, मोबाईल\n**2. रोजगार माहिती** — कंपनी, पद, योजना\n**3. कागदपत्रे** — 5 फायली अपलोड करा\n**4. पुनरावलोकन आणि सबमिट**\n\n* असलेले सर्व फील्ड अनिवार्य आहेत.`,
        help: `मी यात मदत करू शकतो:\n• प्रशिक्षणार्थी नोंदणी आणि फॉर्म भरणे\n• कागदपत्रे आवश्यकता\n• तुकडी तयार करणे\n• वेतन पात्रता\n• पडताळणी प्रक्रिया\n• प्रशिक्षणार्थी प्रोफाइल शोध\n• KPI डॅशबोर्ड आणि अहवाल`,
        login: `SES मध्ये दोन भूमिका:\n• **शाखा** — केंद्र कर्मचारी (नोंदणी, कागदपत्रे, पडताळणी)\n• **व्यवस्थापन** — मुख्यालय कर्मचारी (विश्लेषण, शोध, तुकडी)\n\nलॉगिन स्क्रीनवर आपली भूमिका निवडा.`,
        export: `डेटा निर्यात करण्यासाठी:\n• **तुकडी व्यवस्थापन** — CSV डाउनलोड करा\n• **अहवाल** — PDF किंवा Excel मध्ये`,
        pending: `अपूर्ण नोंदणीसाठी:\n1. तुकडी व्यवस्थापनात **पेरोल सतर्कता** बॅनर पहा.\n2. **प्रलंबित नोंदणी पहा** वर क्लिक करा.\n3. प्रशिक्षणार्थीची प्रोफाइल उघडा, कागदपत्रे अपलोड करा.\n4. पडताळणीसाठी पुन्हा सबमिट करा.`,
      },
    },
  },

  'gu-IN': {
    name: 'Gujarati', native: 'ગુજરાતી', locale: 'gu-IN',
    s: {
      greeting: "નમસ્તે! હું **SES સહાયક** છું — તમારો AI માર્ગદર્શક.\n\nકંઈ પણ પૂછો અથવા **માઇક** ટૅપ કરીને બોલો. નોંધણી, બૅચ, દસ્તાવેજ, પગાર અને વધુમાં મદદ કરીશ.",
      quickPrompts: ['પ્રશિક્ષણાર્થી કેવી રીતે નોંધણી કરવી?', 'કયા દસ્તાવેજ જોઈએ?', 'માસિક બૅચ કેવી રીતે બનાવવો?', 'ચકાસણી કેવી રીતે થાય?'],
      placeholder: 'ટાઇપ કરો અથવા માઇકથી પૂછો…',
      listenHint: 'હવે બોલો — હું સાંભળું છું',
      stopSend: 'રોકો અને મોકલો', cancel: 'રદ કરો',
      autoSpeakOn: 'ઑટો-બોલ ચાલુ', autoSpeakOff: 'ઑટો-બોલ બંધ',
      voiceEnabled: 'વૉઇસ સક્રિય',
      micDenied: 'માઇક્રોફોન ઍક્સેસ નકારી. 🔒 ચિહ્ન પર ક્લિક કરી, માઇક્રોફોન પરવાનગી આપો.',
      noMic: 'કોઈ માઇક્રોફોન મળ્યો નહીં.',
      networkErr: 'નેટવર્ક ભૂલ. કૃપા કરી કનેક્શન તપાસો.',
      noSpeech: '',
      fallback: "આ પ્રશ્નનો જવાબ મને ખ્યાલ નથી. હું આ બાબતોમાં મદદ કરી શકું છું:\n• નોંધણી\n• દસ્તાવેજ\n• બૅચ\n• પગાર\n• ચકાસણી\n\nફરીથી પ્રયત્ન કરો!",
      kb: {
        register: `નવો પ્રશિક્ષણાર્થી નોંધવા:\n1. ડાબી સાઇડબારમાં **પ્રશિક્ષણાર્થી નોંધો** ક્લિક કરો.\n2. **વ્યક્તિગત માહિતી** ટૅબ ભરો — નામ, જન્મ તારીખ, લિંગ, આધાર, મોબાઇલ.\n3. જરૂરી દસ્તાવેજ અપલોડ કરો.\n4. યોજના, કંપની અને બૅચ પસંદ કરો.\n5. **સબમિટ** ક્લિક કરો — અસ્થાયી કોડ બનશે.`,
        documents: `જરૂરી દસ્તાવેજ:\n• આધાર કાર્ડ (આગળ-પાછળ)\n• પાસપોર્ટ ફોટો\n• 10મી પ્રમાણપત્ર\n• બૅન્ક પાસબુક (IFSC સહિત)\n• ઑફર લેટર\n\nPDF/JPG, મહત્તમ 5 MB.`,
        batch: `માસિક બૅચ:\n1. **બૅચ મૅનેજમૅન્ટ** ખોલો.\n2. **+ માસિક બૅચ** ક્લિક કરો.\n3. મહિનો, યોજના, ઝોન, કંપની પસંદ કરો.\n4. નામ અને અપેક્ષિત સ્ટ્રૅઇની ભરો.\n5. **બૅચ બનાવો** ક્લિક કરો, પ્રશિક્ષણાર્થી પસંદ કરો, **સ્ટ્રૅઇની ઑર્ડ કરો** ક્લિક કરો.`,
        payroll: `**પગારપ્રાપ્ય** ત્યારે:\n• આધાર અને બૅન્ક ચકાસાયેલ\n• ઑફર લેટર પુષ્ટિ\n• સ્ટેટસ **મંજૂર**\n\nફિલ્ટર: **ફક્ત પગારપ્રાપ્ય**.`,
        verification: `ચકાસણી:\n1. અરજ **ચકાસણી કતાર**માં.\n2. શાખા વ્યવસ્થાપક ચકાસે.\n3. **મંજૂર** → કાયમી કોડ.\n4. **નકાર** → ફરી અપ્લાય.`,
        code: `• **અસ્થાયી કોડ**: નોંધણી સમયે (TRN000154)\n• **કાયમી કોડ**: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `**શાખા**: સાઇડબારમાં શોધો\n**મૅનેજ**: મૅનેજ મૅનૂ\n\nકોડ, આધાર, મોબાઇલ, નામ.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 ભાગ:\n1. વ્યક્તિગત\n2. રોજગાર\n3. દસ્તાવેજ\n4. સમીક્ષા\n\n* ચિહ્ન ફરજિયાત.`,
        help: `• નોંધણી\n• દસ્તાવેજ\n• બૅચ\n• પગાર\n• ચકાસણી\n• પ્રોફાઇલ\n• KPI\n• ભૂમિકાઓ`,
        login: `**શાખા**: સ્ટાફ (નોંધ, ચકાસ)\n**મૅનેજ**: HO (વિશ્લેષણ, શોધ)`,
        export: `CSV (બૅચ) / PDF/Excel (રિપોર્ટ)`,
        pending: `1. **પગાર સૂચના** જૂઓ.\n2. **અધૂરી નોંધ** ક્લિક કરો.\n3. દસ્તાવેજ અપલોડ.\n4. ફરી સબ્મિટ.`,
      },
    },
  },

  'kn-IN': {
    name: 'Kannada', native: 'ಕನ್ನಡ', locale: 'kn-IN',
    s: {
      greeting: "ನಮಸ್ಕಾರ! ನಾನು **SES ಸಹಾಯಕ** — ನಿಮ್ಮ AI ಮಾರ್ಗದರ್ಶಿ.\n\nಏನಾದರೂ ಕೇಳಿ ಅಥವಾ **ಮೈಕ್** ಟ್ಯಾಪ್ ಮಾಡಿ ಮಾತನಾಡಿ.",
      quickPrompts: ['ತರಬೇತಿ ಪಡೆದವರನ್ನು ಹೇಗೆ ನೋಂದಾಯಿಸಬೇಕು?', 'ಯಾವ ದಾಖಲೆಗಳು ಬೇಕು?', 'ಮಾಸಿಕ ಬ್ಯಾಚ್ ಹೇಗೆ ರಚಿಸಬೇಕು?', 'ಪರಿಶೀಲನೆ ಹೇಗೆ ಕಾರ್ಯನಿರ್ವಹಿಸುತ್ತದೆ?'],
      placeholder: 'ಟೈಪ್ ಮಾಡಿ ಅಥವಾ ಮೈಕ್ ಮೂಲಕ ಕೇಳಿ…',
      listenHint: 'ಈಗ ಮಾತನಾಡಿ — ನಾನು ಕೇಳುತ್ತಿದ್ದೇನೆ',
      stopSend: 'ನಿಲ್ಲಿಸಿ ಮತ್ತು ಕಳುಹಿಸಿ', cancel: 'ರದ್ದುಮಾಡಿ',
      autoSpeakOn: 'ಸ್ವಯಂ-ಮಾತು ಆನ್', autoSpeakOff: 'ಸ್ವಯಂ-ಮಾತು ಆಫ್',
      voiceEnabled: 'ಧ್ವನಿ ಸಕ್ರಿಯ',
      micDenied: 'ಮೈಕ್ರೋಫೋನ್ ಅನುಮತಿ ನಿರಾಕರಿಸಲಾಗಿದೆ. 🔒 ಮೇಲೆ ಕ್ಲಿಕ್ ಮಾಡಿ ಮತ್ತು ಅನುಮತಿ ನೀಡಿ.',
      noMic: 'ಮೈಕ್ರೋಫೋನ್ ಕಂಡುಬಂದಿಲ್ಲ.',
      networkErr: 'ನೆಟ್‌ವರ್ಕ್ ದೋಷ. ಸಂಪರ್ಕ ಪರಿಶೀಲಿಸಿ.',
      noSpeech: '',
      fallback: "ಈ ಪ್ರಶ್ನೆಗೆ ನನಗೆ ಉತ್ತರ ಗೊತ್ತಿಲ್ಲ. ನಾನು ಸಹಾಯ ಮಾಡಬಹುದು:\n• ನೋಂದಣಿ\n• ದಾಖಲೆಗಳು\n• ಬ್ಯಾಚ್\n• ವೇತನ\n• ಪರಿಶೀಲನೆ",
      kb: {
        register: `ಹೊಸ ತರಬೇತಿ ಪಡೆದವರನ್ನು ನೋಂದಾಯಿಸಲು:\n1. ಎಡ ಸೈಡ್‌ಬಾರ್‌ನಲ್ಲಿ **ತರಬೇತಿ ಪಡೆದವರನ್ನು ನೋಂದಾಯಿಸಿ** ಕ್ಲಿಕ್ ಮಾಡಿ.\n2. ಹೆಸರು, DOB, ಲಿಂಗ, ಆಧಾರ್, ಮೊಬೈಲ್ ತುಂಬಿ.\n3. ದಾಖಲೆಗಳನ್ನು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.\n4. ಯೋಜನೆ, ಕಂಪನಿ, ಬ್ಯಾಚ್ ಆಯ್ಕೆ ಮಾಡಿ.\n5. **ಸಲ್ಲಿಸಿ** ಕ್ಲಿಕ್ ಮಾಡಿ.`,
        documents: `ಅಗತ್ಯ ದಾಖಲೆಗಳು:\n• ಆಧಾರ್ ಕಾರ್ಡ್\n• ಪಾಸ್‌ಪೋರ್ಟ್ ಫೋಟೋ\n• 10ನೇ ಪ್ರಮಾಣಪತ್ರ\n• ಬ್ಯಾಂಕ್ ಪಾಸ್‌ಬುಕ್\n• ಆಫರ್ ಲೆಟರ್`,
        batch: `ಮಾಸಿಕ ಬ್ಯಾಚ್:\n1. **ಬ್ಯಾಚ್ ನಿರ್ವಹಣೆ** ತೆರೆಯಿರಿ.\n2. **+ ಮಾಸಿಕ ಬ್ಯಾಚ್** ಕ್ಲಿಕ್ ಮಾಡಿ.\n3. ತಿಂಗಳು, ಯೋಜನೆ, ಕ್ಷೇತ್ರ, ಕಂಪನಿ ಆಯ್ಕೆ ಮಾಡಿ.\n4. ಹೆಸರು ಮತ್ತು ಸಂಖ್ಯೆ ನಮೂದಿಸಿ.\n5. **ಬ್ಯಾಚ್ ರಚಿಸಿ** ಕ್ಲಿಕ್ ಮಾಡಿ.`,
        payroll: `ವೇತನ ಅರ್ಹತೆ:\n• ಆಧಾರ್ ಮತ್ತು ಬ್ಯಾಂಕ್ ಪರಿಶೀಲಿಸಲಾಗಿದೆ\n• ಆಫರ್ ಲೆಟರ್ ದೃಢೀಕರಿಸಲಾಗಿದೆ\n• ಸ್ಥಿತಿ **ಅನುಮೋದಿಸಲಾಗಿದೆ**`,
        verification: `ಪರಿಶೀಲನೆ:\n1. ಅರ್ಜಿ ಪರಿಶೀಲನಾ ಸಾಲಿಗೆ ಹೋಗುತ್ತದೆ.\n2. ಶಾಖೆ ವ್ಯವಸ್ಥಾಪಕ ದಾಖಲೆಗಳನ್ನು ತಪಾಸಿಸುತ್ತಾರೆ.\n3. **ಅನುಮೋದಿಸಿ** → ಶಾಶ್ವತ ಕೋಡ್.\n4. **ತಿರಸ್ಕರಿಸಿ** → ಮರು-ಸಲ್ಲಿಸಿ.`,
        code: `• ತಾತ್ಕಾಲಿಕ ಕೋಡ್: TRN000154\n• ಶಾಶ್ವತ ಕೋಡ್: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `ಕೋಡ್, ಆಧಾರ್, ಮೊಬೈಲ್ ಅಥವಾ ಹೆಸರಿನಿಂದ ಹುಡುಕಿ.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 ವಿಭಾಗಗಳು:\n1. ವೈಯಕ್ತಿಕ ಮಾಹಿತಿ\n2. ಉದ್ಯೋಗ ಮಾಹಿತಿ\n3. ದಾಖಲೆಗಳು\n4. ಪರಿಶೀಲಿಸಿ ಮತ್ತು ಸಲ್ಲಿಸಿ`,
        help: `• ನೋಂದಣಿ\n• ದಾಖಲೆಗಳು\n• ಬ್ಯಾಚ್\n• ವೇತನ\n• ಪರಿಶೀಲನೆ\n• ಹುಡುಕಾಟ\n• KPI`,
        login: `**ಶಾಖೆ**: ಸಿಬ್ಬಂದಿ\n**ನಿರ್ವಹಣೆ**: HO`,
        export: `CSV / PDF / Excel`,
        pending: `1. ವೇತನ ಎಚ್ಚರಿಕೆ ನೋಡಿ.\n2. ತರಬೇತಿ ಪಡೆದವರ ಪ್ರೊಫೈಲ್ ತೆರೆಯಿರಿ.\n3. ದಾಖಲೆಗಳು ಅಪ್‌ಲೋಡ್ ಮಾಡಿ.\n4. ಮರು-ಸಲ್ಲಿಸಿ.`,
      },
    },
  },

  'te-IN': {
    name: 'Telugu', native: 'తెలుగు', locale: 'te-IN',
    s: {
      greeting: "నమస్కారం! నేను **SES సహాయకుడు** — మీ AI మార్గదర్శి.\n\nఏదైనా అడగండి లేదా **మైక్** నొక్కి మాట్లాడండి.",
      quickPrompts: ['శిక్షణార్థిని ఎలా నమోదు చేయాలి?', 'ఏ పత్రాలు అవసరం?', 'నెలవారీ బ్యాచ్ ఎలా సృష్టించాలి?', 'ధృవీకరణ ఎలా జరుగుతుంది?'],
      placeholder: 'టైప్ చేయండి లేదా మైక్ ద్వారా అడగండి…',
      listenHint: 'ఇప్పుడు మాట్లాడండి — నేను వింటున్నాను',
      stopSend: 'ఆపు & పంపు', cancel: 'రద్దు',
      autoSpeakOn: 'స్వయంచాలక మాట ఆన్', autoSpeakOff: 'స్వయంచాలక మాట ఆఫ్',
      voiceEnabled: 'వాయిస్ సక్రియం',
      micDenied: 'మైక్రోఫోన్ అనుమతి నిరాకరించబడింది. 🔒 నొక్కి అనుమతి ఇవ్వండి.',
      noMic: 'మైక్రోఫోన్ కనుగొనబడలేదు.',
      networkErr: 'నెట్‌వర్క్ లోపం.',
      noSpeech: '',
      fallback: "ఈ ప్రశ్నకు నాకు సమాధానం తెలియదు. నేను ఈ విషయాల్లో సహాయం చేయగలను:\n• నమోదు\n• పత్రాలు\n• బ్యాచ్\n• జీతం\n• ధృవీకరణ",
      kb: {
        register: `కొత్త శిక్షణార్థిని నమోదు చేయడానికి:\n1. ఎడమ సైడ్‌బార్‌లో **శిక్షణార్థిని నమోదు చేయి** నొక్కండి.\n2. పేరు, DOB, లింగం, ఆధార్, మొబైల్ నింపండి.\n3. పత్రాలు అప్‌లోడ్ చేయండి.\n4. పథకం, కంపెనీ, బ్యాచ్ ఎంచుకోండి.\n5. **సమర్పించు** నొక్కండి.`,
        documents: `అవసరమైన పత్రాలు:\n• ఆధార్ కార్డ్\n• పాస్‌పోర్ట్ ఫోటో\n• 10వ తరగతి సర్టిఫికేట్\n• బ్యాంక్ పాస్‌బుక్\n• ఆఫర్ లెటర్`,
        batch: `నెలవారీ బ్యాచ్:\n1. **బ్యాచ్ నిర్వహణ** తెరవండి.\n2. **+ నెలవారీ బ్యాచ్** నొక్కండి.\n3. నెల, పథకం, జోన్, కంపెనీ ఎంచుకోండి.\n4. పేరు, సంఖ్య నమోదు చేయండి.\n5. **బ్యాచ్ సృష్టించు** నొక్కండి.`,
        payroll: `జీతం అర్హత:\n• ఆధార్, బ్యాంక్ ధృవీకరించబడ్డాయి\n• ఆఫర్ లెటర్ నిర్ధారించబడింది\n• స్థితి **ఆమోదించబడింది**`,
        verification: `ధృవీకరణ:\n1. దరఖాస్తు ధృవీకరణ క్యూలో వెళ్తుంది.\n2. శాఖా నిర్వాహకుడు తనిఖీ చేస్తాడు.\n3. **ఆమోదించు** → శాశ్వత కోడ్.\n4. **తిరస్కరించు** → మళ్ళీ దరఖాస్తు.`,
        code: `• తాత్కాలిక కోడ్: TRN000154\n• శాశ్వత కోడ్: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `కోడ్, ఆధార్, మొబైల్ లేదా పేరు ద్వారా శోధించండి.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 విభాగాలు:\n1. వ్యక్తిగత సమాచారం\n2. ఉద్యోగ సమాచారం\n3. పత్రాలు\n4. సమీక్ష & సమర్పణ`,
        help: `• నమోదు\n• పత్రాలు\n• బ్యాచ్\n• జీతం\n• ధృవీకరణ\n• శోధన\n• KPI`,
        login: `**శాఖ**: సిబ్బంది\n**నిర్వహణ**: HO`,
        export: `CSV / PDF / Excel`,
        pending: `1. జీతం హెచ్చరిక చూడండి.\n2. ప్రొఫైల్ తెరవండి.\n3. పత్రాలు అప్‌లోడ్ చేయండి.\n4. మళ్ళీ సమర్పించండి.`,
      },
    },
  },

  'ml-IN': {
    name: 'Malayalam', native: 'മലയാളം', locale: 'ml-IN',
    s: {
      greeting: "നമസ്കാരം! ഞാൻ **SES അസിസ്റ്റന്റ്** — നിങ്ങളുടെ AI ഗൈഡ്.\n\nഎന്തെങ്കിലും ചോദിക്കൂ അല്ലെങ്കിൽ **മൈക്ക്** ടാപ്പ് ചെയ്ത് സംസാരിക്കൂ.",
      quickPrompts: ['പരിശീലനാർത്ഥിയെ എങ്ങനെ രജിസ്റ്റർ ചെയ്യാം?', 'എന്ത് രേഖകൾ വേണം?', 'മാസിക ബാച്ച് ഉണ്ടാക്കുന്നത് എങ്ങനെ?', 'വെരിഫിക്കേഷൻ എങ്ങനെ നടക്കുന്നു?'],
      placeholder: 'ടൈപ്പ് ചെയ്യൂ അല്ലെങ്കിൽ മൈക്ക് ഉപയോഗിക്കൂ…',
      listenHint: 'ഇപ്പോൾ സംസാരിക്കൂ — ഞാൻ കേൾക്കുന്നു',
      stopSend: 'നിർത്തി അയക്കൂ', cancel: 'റദ്ദ് ചെയ്യൂ',
      autoSpeakOn: 'ഓട്ടോ-സ്പീക്ക് ഓൺ', autoSpeakOff: 'ഓട്ടോ-സ്പീക്ക് ഓഫ്',
      voiceEnabled: 'വോയ്സ് സജീവം',
      micDenied: 'മൈക്രോഫോൺ അനുമതി നിരസിക്കപ്പെട്ടു. 🔒 ക്ലിക്ക് ചെയ്ത് അനുമതി നൽകൂ.',
      noMic: 'മൈക്രോഫോൺ കണ്ടെത്തിയില്ല.',
      networkErr: 'നെറ്റ്‌വർക്ക് പിശക്.',
      noSpeech: '',
      fallback: "ഈ ചോദ്യത്തിന്റെ ഉത്തരം എനിക്കറിയില്ല. ഞാൻ ഇവയിൽ സഹായിക്കാം:\n• രജിസ്ട്രേഷൻ\n• രേഖകൾ\n• ബാച്ച്\n• ശമ്പളം\n• വെരിഫിക്കേഷൻ",
      kb: {
        register: `പുതിയ പരിശീലനാർത്ഥിയെ രജിസ്റ്റർ ചെയ്യാൻ:\n1. ഇടത് സൈഡ്‌ബാറിൽ **ട്രെയ്‌നിയെ രജിസ്റ്റർ ചെയ്യൂ** ക്ലിക്ക് ചെയ്യൂ.\n2. പേര്, DOB, ലിംഗം, ആധാർ, മൊബൈൽ നൽകൂ.\n3. രേഖകൾ അപ്‌ലോഡ് ചെയ്യൂ.\n4. സ്കീം, കമ്പനി, ബാച്ച് തിരഞ്ഞെടുക്കൂ.\n5. **സബ്‌മിറ്റ്** ക്ലിക്ക് ചെയ്യൂ.`,
        documents: `ആവശ്യമായ രേഖകൾ:\n• ആധാർ കാർഡ്\n• പാസ്‌പോർട്ട് ഫോട്ടോ\n• 10-ാം ക്ലാസ് സർട്ടിഫിക്കറ്റ്\n• ബാങ്ക് പാസ്‌ബുക്ക്\n• ഓഫർ ലെറ്റർ`,
        batch: `മാസിക ബാച്ച്:\n1. **ബാച്ച് മാനേജ്മെന്റ്** തുറക്കൂ.\n2. **+ മാസിക ബാച്ച്** ക്ലിക്ക് ചെയ്യൂ.\n3. മാസം, സ്കീം, സോൺ, കമ്പനി തിരഞ്ഞെടുക്കൂ.\n4. പേരും എണ്ണവും നൽകൂ.\n5. **ബാച്ച് ഉണ്ടാക്കൂ** ക്ലിക്ക് ചെയ്യൂ.`,
        payroll: `ശമ്പള യോഗ്യത:\n• ആധാർ, ബാങ്ക് വെരിഫൈ ചെയ്തിരിക്കണം\n• ഓഫർ ലെറ്റർ സ്ഥിരീകരിച്ചിരിക്കണം\n• സ്റ്റാറ്റസ് **അംഗീകൃതം**`,
        verification: `വെരിഫിക്കേഷൻ:\n1. അപേക്ഷ ക്യൂവിൽ.\n2. ബ്രാഞ്ച് മാനേജർ രേഖകൾ പരിശോധിക്കും.\n3. **അംഗീകരിക്കൂ** → സ്ഥിര കോഡ്.\n4. **നിരസിക്കൂ** → വീണ്ടും സബ്‌മിറ്റ്.`,
        code: `• താൽക്കാലിക കോഡ്: TRN000154\n• സ്ഥിര കോഡ്: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `കോഡ്, ആധാർ, മൊബൈൽ അല്ലെങ്കിൽ പേര് ഉപയോഗിച്ച് തിരയൂ.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 ഭാഗങ്ങൾ:\n1. വ്യക്തിഗത വിവരം\n2. തൊഴിൽ വിവരം\n3. രേഖകൾ\n4. അവലോകനം & സബ്‌മിഷൻ`,
        help: `• രജിസ്ട്രേഷൻ\n• രേഖകൾ\n• ബാച്ച്\n• ശമ്പളം\n• വെരിഫിക്കേഷൻ\n• തിരയൽ\n• KPI`,
        login: `**ബ്രാഞ്ച്**: സ്റ്റാഫ്\n**മാനേജ്മെന്റ്**: HO`,
        export: `CSV / PDF / Excel`,
        pending: `1. ശമ്പള മുന്നറിയിപ്പ് കാണൂ.\n2. പ്രൊഫൈൽ തുറക്കൂ.\n3. രേഖകൾ അപ്‌ലോഡ് ചെയ്യൂ.\n4. വീണ്ടും സബ്‌മിഷൻ.`,
      },
    },
  },

  'bn-IN': {
    name: 'Bengali', native: 'বাংলা', locale: 'bn-IN',
    s: {
      greeting: "নমস্কার! আমি **SES সহকারী** — আপনার AI গাইড।\n\nযেকোনো প্রশ্ন করুন অথবা **মাইক** চাপুন এবং কথা বলুন।",
      quickPrompts: ['প্রশিক্ষণার্থী কীভাবে নিবন্ধন করবেন?', 'কোন নথি প্রয়োজন?', 'মাসিক ব্যাচ কীভাবে তৈরি করবেন?', 'যাচাইকরণ কীভাবে কাজ করে?'],
      placeholder: 'টাইপ করুন বা মাইক দিয়ে জিজ্ঞাসা করুন…',
      listenHint: 'এখন কথা বলুন — আমি শুনছি',
      stopSend: 'থামুন ও পাঠান', cancel: 'বাতিল',
      autoSpeakOn: 'অটো-কথা চালু', autoSpeakOff: 'অটো-কথা বন্ধ',
      voiceEnabled: 'ভয়েস সক্রিয়',
      micDenied: 'মাইক্রোফোন অনুমতি প্রত্যাখ্যাত। 🔒 ক্লিক করুন এবং অনুমতি দিন।',
      noMic: 'মাইক্রোফোন পাওয়া যায়নি।',
      networkErr: 'নেটওয়ার্ক ত্রুটি।',
      noSpeech: '',
      fallback: "এই প্রশ্নের উত্তর আমার জানা নেই। আমি সাহায্য করতে পারি:\n• নিবন্ধন\n• নথি\n• ব্যাচ\n• বেতন\n• যাচাইকরণ",
      kb: {
        register: `নতুন প্রশিক্ষণার্থী নিবন্ধন করতে:\n1. বাম সাইডবারে **প্রশিক্ষণার্থী নিবন্ধন** ক্লিক করুন।\n2. নাম, জন্মতারিখ, লিঙ্গ, আধার, মোবাইল পূরণ করুন।\n3. নথি আপলোড করুন।\n4. স্কিম, কোম্পানি, ব্যাচ বেছে নিন।\n5. **জমা দিন** ক্লিক করুন।`,
        documents: `প্রয়োজনীয় নথি:\n• আধার কার্ড\n• পাসপোর্ট ফোটো\n• ১০ম সনদ\n• ব্যাংক পাসবুক\n• অফার লেটার`,
        batch: `মাসিক ব্যাচ:\n1. **ব্যাচ ম্যানেজমেন্ট** খুলুন।\n2. **+ মাসিক ব্যাচ** ক্লিক করুন।\n3. মাস, স্কিম, জোন, কোম্পানি বেছে নিন।\n4. নাম ও সংখ্যা দিন।\n5. **ব্যাচ তৈরি করুন** ক্লিক করুন।`,
        payroll: `বেতন যোগ্যতা:\n• আধার ও ব্যাংক যাচাই\n• অফার লেটার নিশ্চিত\n• স্ট্যাটাস **অনুমোদিত**`,
        verification: `যাচাইকরণ:\n1. আবেদন সারিতে যায়।\n2. শাখা ব্যবস্থাপক পরীক্ষা করেন।\n3. **অনুমোদন** → স্থায়ী কোড।\n4. **প্রত্যাখ্যান** → পুনরায় জমা।`,
        code: `• অস্থায়ী কোড: TRN000154\n• স্থায়ী কোড: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `কোড, আধার, মোবাইল বা নাম দিয়ে অনুসন্ধান করুন।`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `৪টি বিভাগ:\n1. ব্যক্তিগত তথ্য\n2. কর্মসংস্থান তথ্য\n3. নথি\n4. পর্যালোচনা ও জমা`,
        help: `• নিবন্ধন\n• নথি\n• ব্যাচ\n• বেতন\n• যাচাইকরণ\n• অনুসন্ধান\n• KPI`,
        login: `**শাখা**: কর্মীদের জন্য\n**ম্যানেজমেন্ট**: HO`,
        export: `CSV / PDF / Excel`,
        pending: `1. বেতন সতর্কতা দেখুন।\n2. প্রোফাইল খুলুন।\n3. নথি আপলোড করুন।\n4. পুনরায় জমা দিন।`,
      },
    },
  },

  'ta-IN': {
    name: 'Tamil', native: 'தமிழ்', locale: 'ta-IN',
    s: {
      greeting: "வணக்கம்! நான் **SES உதவியாளர்** — உங்கள் AI வழிகாட்டி.\n\nஏதாவது கேளுங்கள் அல்லது **மைக்** தட்டி பேசுங்கள்.",
      quickPrompts: ['பயிற்சியாளரை எவ்வாறு பதிவு செய்வது?', 'என்ன ஆவணங்கள் தேவை?', 'மாதாந்திர தொகுதியை எவ்வாறு உருவாக்குவது?', 'சரிபார்ப்பு எவ்வாறு நடக்கும்?'],
      placeholder: 'தட்டச்சு செய்யுங்கள் அல்லது மைக் பயன்படுத்துங்கள்…',
      listenHint: 'இப்போது பேசுங்கள் — நான் கேட்கிறேன்',
      stopSend: 'நிறுத்தி அனுப்பு', cancel: 'ரத்து செய்',
      autoSpeakOn: 'தானாக பேசு ஆன்', autoSpeakOff: 'தானாக பேசு ஆஃப்',
      voiceEnabled: 'குரல் செயலில் உள்ளது',
      micDenied: 'மைக்ரோஃபோன் அனுமதி மறுக்கப்பட்டது. 🔒 அழுத்தி அனுமதி வழங்குக.',
      noMic: 'மைக்ரோஃபோன் கிடைக்கவில்லை.',
      networkErr: 'நெட்வொர்க் பிழை.',
      noSpeech: '',
      fallback: "இந்த கேள்விக்கு பதில் தெரியவில்லை. நான் உதவக்கூடியது:\n• பதிவு\n• ஆவணங்கள்\n• தொகுதி\n• சம்பளம்\n• சரிபார்ப்பு",
      kb: {
        register: `புதிய பயிற்சியாளரை பதிவு செய்ய:\n1. இடது பட்டியில் **பயிற்சியாளரை பதிவு செய்** கிளிக் செய்யவும்.\n2. பெயர், பிறந்த தேதி, பால், ஆதார், மொபைல் நிரப்பவும்.\n3. ஆவணங்களை பதிவேற்றவும்.\n4. திட்டம், நிறுவனம், தொகுதி தேர்ந்தெடுக்கவும்.\n5. **சமர்ப்பி** கிளிக் செய்யவும்.`,
        documents: `தேவையான ஆவணங்கள்:\n• ஆதார் அட்டை\n• பாஸ்போர்ட் புகைப்படம்\n• 10ம் வகுப்பு சான்றிதழ்\n• வங்கி பாஸ்புக்\n• சலுகை கடிதம்`,
        batch: `மாதாந்திர தொகுதி:\n1. **தொகுதி மேலாண்மை** திறக்கவும்.\n2. **+ மாதாந்திர தொகுதி** கிளிக் செய்யவும்.\n3. மாதம், திட்டம், மண்டலம், நிறுவனம் தேர்ந்தெடுக்கவும்.\n4. பெயர் மற்றும் எண்ணிக்கை நிரப்பவும்.\n5. **தொகுதி உருவாக்கு** கிளிக் செய்யவும்.`,
        payroll: `சம்பள தகுதி:\n• ஆதார் மற்றும் வங்கி சரிபார்க்கப்பட்டது\n• சலுகை கடிதம் உறுதி\n• நிலை **அங்கீகரிக்கப்பட்டது**`,
        verification: `சரிபார்ப்பு:\n1. விண்ணப்பம் வரிசையில் போகும்.\n2. கிளை மேலாளர் ஆவணங்களை சரிபார்க்கிறார்.\n3. **அங்கீகரி** → நிரந்தர குறியீடு.\n4. **நிராகரி** → மீண்டும் சமர்ப்பி.`,
        code: `• தற்காலிக குறியீடு: TRN000154\n• நிரந்தர குறியீடு: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `குறியீடு, ஆதார், மொபைல் அல்லது பெயரால் தேடவும்.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 பகுதிகள்:\n1. தனிப்பட்ட தகவல்\n2. வேலைவாய்ப்பு தகவல்\n3. ஆவணங்கள்\n4. மதிப்பாய்வு & சமர்ப்பிப்பு`,
        help: `• பதிவு\n• ஆவணங்கள்\n• தொகுதி\n• சம்பளம்\n• சரிபார்ப்பு\n• தேடல்\n• KPI`,
        login: `**கிளை**: ஊழியர்கள்\n**மேலாண்மை**: HO`,
        export: `CSV / PDF / Excel`,
        pending: `1. சம்பள எச்சரிக்கை காணவும்.\n2. சுயவிவரம் திறக்கவும்.\n3. ஆவணங்கள் பதிவேற்றவும்.\n4. மீண்டும் சமர்ப்பிக்கவும்.`,
      },
    },
  },

  'as-IN': {
    name: 'Assamese', native: 'অসমীয়া', locale: 'as-IN',
    s: {
      greeting: "নমস্কাৰ! মই **SES সহায়ক** — আপোনাৰ AI পথপ্ৰদৰ্শক।\n\nযিকোনো প্ৰশ্ন কৰক বা **মাইক** টেপ কৰক।",
      quickPrompts: ['প্ৰশিক্ষণাৰ্থী কেনেকৈ পঞ্জীয়ন কৰিব?', 'কোন নথিপত্ৰ লাগিব?', 'মাহিলী বেচ কেনেকৈ তৈয়াৰ কৰিব?', 'যাচাই কেনেকৈ হয়?'],
      placeholder: 'টাইপ কৰক বা মাইকেৰে সুধক…',
      listenHint: 'এতিয়া কথা কওক — মই শুনি আছো',
      stopSend: 'বন্ধ কৰি পঠাওক', cancel: 'বাতিল কৰক',
      autoSpeakOn: 'অটো-কথা অন', autoSpeakOff: 'অটো-কথা অফ',
      voiceEnabled: 'ভইচ সক্ৰিয়',
      micDenied: "মাইক্ৰ'ফোন অনুমতি অস্বীকাৰ কৰা হৈছে। 🔒 ক্লিক কৰি অনুমতি দিয়ক।",
      noMic: "কোনো মাইক্ৰ'ফোন পোৱা নগ'ল।",
      networkErr: 'নেটৱৰ্ক ত্ৰুটি।',
      noSpeech: '',
      fallback: "এই প্ৰশ্নৰ উত্তৰ মোৰ জনা নাই। মই সহায় কৰিব পাৰো:\n• পঞ্জীয়ন\n• নথিপত্ৰ\n• বেচ\n• দৰমহা\n• যাচাই",
      kb: {
        register: `নতুন প্ৰশিক্ষণাৰ্থী পঞ্জীয়ন কৰিবলৈ:\n1. বাওঁ চাইডবাৰত **প্ৰশিক্ষণাৰ্থী পঞ্জীয়ন কৰক** ক্লিক কৰক।\n2. নাম, জন্মতাৰিখ, লিংগ, আধাৰ, মোবাইল পূৰণ কৰক।\n3. নথিপত্ৰ আপলোড কৰক।\n4. আঁচনি, কোম্পানি, বেচ বাছক।\n5. **জমা কৰক** ক্লিক কৰক।`,
        documents: `প্ৰয়োজনীয় নথিপত্ৰ:\n• আধাৰ কাৰ্ড\n• পাছপোৰ্ট ফটো\n• দশম শ্ৰেণীৰ প্ৰমাণপত্ৰ\n• বেংক পাছবুক\n• অফাৰ লেটাৰ`,
        batch: `মাহিলী বেচ:\n1. **বেচ মেনেজমেন্ট** খোলক।\n2. **+ মাহিলী বেচ** ক্লিক কৰক।\n3. মাহ, আঁচনি, জ'ন, কোম্পানি বাছক।\n4. নাম আৰু সংখ্যা দিয়ক।\n5. **বেচ তৈয়াৰ কৰক** ক্লিক কৰক।`,
        payroll: `দৰমহা যোগ্যতা:\n• আধাৰ আৰু বেংক যাচাই\n• অফাৰ লেটাৰ নিশ্চিত\n• স্থিতি **অনুমোদিত**`,
        verification: `যাচাই:\n1. আবেদন শাৰীত যায়।\n2. শাখা মেনেজাৰে পৰীক্ষা কৰে।\n3. **অনুমোদন** → স্থায়ী ক'ড।\n4. **প্ৰত্যাখ্যান** → পুনৰ জমা।`,
        code: `• অস্থায়ী ক'ড: TRN000154\n• স্থায়ী ক'ড: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `ক'ড, আধাৰ, মোবাইল বা নামেৰে বিচাৰক।`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `৪টা অংশ:\n1. ব্যক্তিগত তথ্য\n2. নিয়োগ তথ্য\n3. নথিপত্ৰ\n4. পুনৰীক্ষণ আৰু জমা`,
        help: `• পঞ্জীয়ন\n• নথিপত্ৰ\n• বেচ\n• দৰমহা\n• যাচাই\n• সন্ধান\n• KPI`,
        login: `**শাখা**: কৰ্মী\n**মেনেজমেন্ট**: HQ`,
        export: `CSV / PDF / Excel`,
        pending: `1. দৰমহা সতৰ্কতা চাওক।\n2. প্ৰ'ফাইল খোলক।\n3. নথিপত্ৰ আপলোড কৰক।\n4. পুনৰ জমা কৰক।`,
      },
    },
  },

  'kok-IN': {
    name: 'Konkani', native: 'कोंकणी', locale: 'kok-IN',
    s: {
      greeting: "नमस्कार! हांव **SES सहाय्यक** — तुमचो AI मार्गदर्शक.\n\nकितेंय विचारात वा **मायक्रोफोन** वापरात.",
      quickPrompts: ['प्रशिक्षणार्थीक कशे नोंदायात?', 'कसले दस्तावेज लागतात?', 'मासिक बॅच कसो तयार करात?', 'पडताळणी कशी जाता?'],
      placeholder: 'टाइप करात वा मायकान विचारात…',
      listenHint: 'आतां उलयात — हांव आयकताव',
      stopSend: 'थांबयात आनी धाडात', cancel: 'रद्द करात',
      autoSpeakOn: 'ऑटो-उलवण चालू', autoSpeakOff: 'ऑटो-उलवण बंद',
      voiceEnabled: 'वॉइस सक्रिय',
      micDenied: 'मायक्रोफोनाची परवानगी नाकारली. 🔒 क्लिक करात आनी परवानगी दियात.',
      noMic: 'मायक्रोफोन मेळ्ळो ना.',
      networkErr: 'नेटवर्क चूक.',
      noSpeech: '',
      fallback: "ह्या प्रश्नाचें उत्तर म्हाका कळना. हांव ह्यांत मदत करूं येता:\n• नोंदणी\n• दस्तावेज\n• बॅच\n• पगार\n• पडताळणी",
      kb: {
        register: `नव्यान प्रशिक्षणार्थी नोंदावपाक:\n1. दाव्या साइडबारांत **प्रशिक्षणार्थी नोंदयात** क्लिक करात.\n2. नांव, जल्म तारीख, लिंग, आधार, मोबायल भरात.\n3. दस्तावेज अपलोड करात.\n4. योजना, कंपनी, बॅच वेंचात.\n5. **सबमिट** क्लिक करात.`,
        documents: `गरजेचे दस्तावेज:\n• आधार कार्ड\n• पासपोर्ट फोटो\n• 10वी प्रमाणपत्र\n• बँक पासबुक\n• ऑफर लेटर`,
        batch: `मासिक बॅच:\n1. **बॅच व्यवस्थापन** उगडात.\n2. **+ मासिक बॅच** क्लिक करात.\n3. म्हयनो, योजना, झोन, कंपनी वेंचात.\n4. नांव आनी संख्या घालात.\n5. **बॅच तयार करात** क्लिक करात.`,
        payroll: `पगाराचो हक्क:\n• आधार आनी बँक पडताळ्या\n• ऑफर लेटर निश्चित\n• स्थिती **मंजूर**`,
        verification: `पडताळणी:\n1. अर्ज रांगेंत वतां.\n2. शाखा व्यवस्थापक तपासता.\n3. **मंजूर** → कायम कोड.\n4. **नाकार** → परत सबमिट.`,
        code: `• तात्पुरतो कोड: TRN000154\n• कायम कोड: COMPANY/SCHEME/YEAR/SERIAL`,
        search: `कोड, आधार, मोबायल वा नांवान सोदात.`,
        scheme: `PMKVY, DDUGKY, WILP, BVOC, DVOC, FLEXI, MSBTE`,
        form: `4 भाग:\n1. वैयक्तिक म्हायती\n2. रोजगार म्हायती\n3. दस्तावेज\n4. पुनरावलोकन आनी सबमिट`,
        help: `• नोंदणी\n• दस्तावेज\n• बॅच\n• पगार\n• पडताळणी\n• सोद\n• KPI`,
        login: `**शाखा**: कार्यकर्ते\n**व्यवस्थापन**: HQ`,
        export: `CSV / PDF / Excel`,
        pending: `1. पगार सूचना पळयात.\n2. प्रोफाइल उगडात.\n3. दस्तावेज अपलोड करात.\n4. परत सबमिट करात.`,
      },
    },
  },
}

const DEFAULT_LOCALE = 'en-IN'

/* ── KB pattern matching ────────────────────────────────────────── */
const KB_PATTERNS: { key: keyof LangStrings['kb']; patterns: string[] }[] = [
  { key: 'register',     patterns: ['register', 'registration', 'enroll', 'नोंद', 'नोंदण', 'पंजीकृत', 'पंजीकरण', 'నమోదు', 'ನೋಂದಾಯಿಸ', 'பதிவு', 'নিবন্ধন', 'رجسٹر', 'ਦਰਜ'] },
  { key: 'documents',    patterns: ['document', 'aadhaar', 'aadhar', 'photo', 'certificate', 'bank', 'offer', 'कागदपत्र', 'दस्तावेज', 'आधार', 'నথి', 'ఆధార్', 'ਦਸਤਾਵੇਜ਼', 'আধার'] },
  { key: 'batch',        patterns: ['batch', 'monthly', 'allocate', 'allot', 'बॅच', 'तुकडी', 'बैच', 'బ్యాచ్', 'ব্যাচ', 'तৈयार', 'বেচ'] },
  { key: 'payroll',      patterns: ['payroll', 'salary', 'wage', 'वेतन', 'पगार', 'జీతం', 'ਤਨਖ਼ਾਹ', 'দরমহা', 'সম্বল'] },
  { key: 'verification', patterns: ['verif', 'approve', 'reject', 'pending', 'पडताळणी', 'सत्यापन', 'ధృవీకరణ', 'সত্যাপন', 'যাচাই'] },
  { key: 'code',         patterns: ['code', 'temp code', 'fixed code', 'कोड', 'কোড', 'குறியீடு'] },
  { key: 'search',       patterns: ['search', 'find', 'look up', 'शोध', 'খोज', 'তlash', 'தேடல்'] },
  { key: 'scheme',       patterns: ['scheme', 'pmkvy', 'ddugky', 'wilp', 'bvoc', 'dvoc', 'flexi', 'msbte', 'योजना'] },
  { key: 'form',         patterns: ['form', 'fill', 'field', 'फॉर्म', 'ফর্ম', 'படிவம்'] },
  { key: 'login',        patterns: ['login', 'sign in', 'role', 'branch', 'management', 'लॉगिन', 'भूमिका'] },
  { key: 'export',       patterns: ['export', 'download', 'csv', 'report', 'निर्यात', 'अहवाल'] },
  { key: 'pending',      patterns: ['incomplete', 'pending reg', 'अपूर्ण', 'अधूरा', 'অসম্পূর্ণ'] },
  { key: 'help',         patterns: ['help', 'assist', 'what can', 'guide', 'मदद', 'मदत', 'সাহায্য', 'உதவி', 'सहाय्य'] },
]

function getBotResponse(input: string, locale: string): string {
  const q = input.toLowerCase()
  const lang = LANGS[locale] ?? LANGS[DEFAULT_LOCALE]
  for (const { key, patterns } of KB_PATTERNS) {
    if (patterns.some(p => q.includes(p))) {
      return lang.s.kb[key]
    }
  }
  return lang.s.fallback
}

function stripMd(text: string): string {
  return text.replace(/\*\*([^*]+)\*\*/g, '$1').replace(/^[\d]+\.\s+/gm, '').replace(/^[•\-]\s+/gm, '').replace(/\n+/g, '. ')
}

function nowTime() { return new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }

const hasSR = () => typeof window !== 'undefined' && !!(window.SpeechRecognition || window.webkitSpeechRecognition)
const hasSS = () => typeof window !== 'undefined' && 'speechSynthesis' in window

/* ── Markdown renderer ──────────────────────────────────────────── */
function BotMsg({ text }: { text: string }) {
  return (
    <div style={{ fontFamily: "'Exo 2',sans-serif", fontSize: 13, lineHeight: 1.65, color: '#0D2B5E' }}>
      {text.split('\n').map((line, i) => {
        if (!line.trim()) return <div key={i} style={{ height: 6 }} />
        const isBullet = /^[•\-]/.test(line.trim())
        const content = isBullet ? line.replace(/^[\s•\-]+/, '') : line
        const bold = (s: string, j: number) => s.startsWith('**') ? <strong key={j} style={{ color: '#0D2B5E', fontWeight: 700 }}>{s.slice(2, -2)}</strong> : <span key={j}>{s}</span>
        const rendered = content.split(/(\*\*[^*]+\*\*)/).map(bold)
        if (isBullet) return <div key={i} className="flex gap-2" style={{ marginBottom: 4 }}><span style={{ color: '#1565C0', flexShrink: 0 }}>•</span><span>{rendered}</span></div>
        const num = line.match(/^(\d+)\.\s+(.*)/)
        if (num) return (
          <div key={i} className="flex gap-2" style={{ marginBottom: 4 }}>
            <span style={{ color: '#1565C0', fontWeight: 700, fontFamily: 'JetBrains Mono,monospace', fontSize: 12, flexShrink: 0, minWidth: 16 }}>{num[1]}.</span>
            <span>{num[2].split(/(\*\*[^*]+\*\*)/).map(bold)}</span>
          </div>
        )
        return <p key={i} style={{ margin: '0 0 6px' }}>{rendered}</p>
      })}
    </div>
  )
}

function TypingDots() {
  return (
    <div style={{ background: 'rgba(21,101,192,0.07)', borderRadius: '14px 14px 14px 4px', display: 'inline-flex', alignItems: 'center', gap: 4, padding: '10px 14px' }}>
      {[0, 1, 2].map(i => <span key={i} style={{ width: 7, height: 7, borderRadius: '50%', background: '#1565C0', display: 'inline-block', animation: `chatDot 1.2s ${i * 0.2}s infinite` }} />)}
    </div>
  )
}

function VoiceWaveform({ active }: { active: boolean }) {
  const heights = [3, 6, 10, 14, 11, 16, 12, 8, 13, 7, 10, 5]
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 3, height: 36 }}>
      {heights.map((h, i) => (
        <div key={i} style={{ width: 3, borderRadius: 2, background: active ? 'linear-gradient(180deg,#7c3aed,#1565C0)' : 'rgba(21,101,192,0.22)', height: active ? h * 2 : 4, animation: active ? `voiceBar 0.6s ${i * 0.06}s ease-in-out infinite alternate` : 'none', transition: 'height 0.3s, background 0.3s' }} />
      ))}
    </div>
  )
}

/* ── Language picker ────────────────────────────────────────────── */
function LangPicker({ locale, onChange }: { locale: string; onChange: (l: string) => void }) {
  const [open, setOpen] = useState(false)
  const current = LANGS[locale] ?? LANGS[DEFAULT_LOCALE]
  return (
    <div style={{ position: 'relative' }}>
      <button onClick={() => setOpen(v => !v)}
        style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '4px 10px', borderRadius: 8, background: 'rgba(255,255,255,0.18)', border: '1px solid rgba(255,255,255,0.30)', color: '#fff', cursor: 'pointer', fontSize: 12, fontFamily: "'Exo 2',sans-serif", fontWeight: 600 }}>
        <Globe size={12} />
        <span>{current.native}</span>
        <ChevronDown size={10} style={{ transition: 'transform 0.2s', transform: open ? 'rotate(180deg)' : 'none' }} />
      </button>
      {open && (
        <div style={{ position: 'absolute', top: '110%', right: 0, zIndex: 10, background: 'rgba(255,255,255,0.98)', backdropFilter: 'blur(20px)', borderRadius: 14, border: '1px solid rgba(21,101,192,0.14)', boxShadow: '0 16px 48px rgba(21,101,192,0.20)', padding: '6px 0', minWidth: 172, animation: 'chatPop 0.18s ease forwards' }}>
          {Object.entries(LANGS).map(([loc, cfg]) => (
            <button key={loc} onClick={() => { onChange(loc); setOpen(false) }}
              style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '8px 14px', background: loc === locale ? 'rgba(21,101,192,0.09)' : 'none', border: 'none', cursor: 'pointer', gap: 10 }}>
              <span style={{ fontSize: 13, color: '#0D2B5E', fontFamily: "'Exo 2',sans-serif", fontWeight: loc === locale ? 700 : 400 }}>{cfg.native}</span>
              <span style={{ fontSize: 11, color: '#7A90A8', fontFamily: "'Exo 2',sans-serif" }}>{cfg.name}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

/* ── Main widget ────────────────────────────────────────────────── */
export default function AIChatBot() {
  const [open, setOpen] = useState(false)
  const [locale, setLocale] = useState(DEFAULT_LOCALE)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<Message[]>([])
  const [typing, setTyping] = useState(false)
  const [shake, setShake] = useState(false)
  const [showBadge, setShowBadge] = useState(true)
  const [listening, setListening] = useState(false)
  const [voiceTranscript, setVoiceTranscript] = useState('')
  const [autoSpeak, setAutoSpeak] = useState(false)
  const [speakingId, setSpeakingId] = useState<number | null>(null)
  const [micError, setMicError] = useState('')

  const bottomRef    = useRef<HTMLDivElement>(null)
  const inputRef     = useRef<HTMLInputElement>(null)
  const recognizerRef = useRef<SpeechRecognitionInstance | null>(null)
  const nextId       = useRef(1)
  const autoSendTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const s = (LANGS[locale] ?? LANGS[DEFAULT_LOCALE]).s

  const makeGreeting = useCallback((loc: string): Message => ({
    id: 0, role: 'bot', text: (LANGS[loc] ?? LANGS[DEFAULT_LOCALE]).s.greeting, time: nowTime(),
  }), [])

  useEffect(() => { setMessages([makeGreeting(locale)]) }, [])

  useEffect(() => {
    if (open) { setShowBadge(false); setTimeout(() => inputRef.current?.focus(), 120) }
  }, [open])

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages, typing])

  /* ── TTS ────────────────────────────────────────────────────── */
  const speak = useCallback((text: string, msgId: number, loc: string) => {
    if (!hasSS()) return
    window.speechSynthesis.cancel()
    const utter = new SpeechSynthesisUtterance(stripMd(text))
    utter.rate = 0.92; utter.pitch = 1.05; utter.volume = 1
    const langCode = (LANGS[loc] ?? LANGS[DEFAULT_LOCALE]).locale
    utter.lang = langCode
    const voices = window.speechSynthesis.getVoices()
    const match = voices.find(v => v.lang === langCode)
      ?? voices.find(v => v.lang.startsWith(langCode.split('-')[0]))
      ?? voices.find(v => v.lang.startsWith('en'))
    if (match) utter.voice = match
    utter.onstart = () => setSpeakingId(msgId)
    utter.onend = () => setSpeakingId(null)
    utter.onerror = () => setSpeakingId(null)
    window.speechSynthesis.speak(utter)
  }, [])

  const stopSpeaking = useCallback(() => { hasSS() && window.speechSynthesis.cancel(); setSpeakingId(null) }, [])

  /* ── Send ───────────────────────────────────────────────────── */
  const sendMessage = useCallback((text: string, isVoice = false, loc?: string) => {
    const trimmed = text.trim()
    if (!trimmed) { setShake(true); setTimeout(() => setShake(false), 400); return }
    stopSpeaking()
    const activeLoc = loc ?? locale
    const userMsg: Message = { id: nextId.current++, role: 'user', text: trimmed, time: nowTime(), isVoice }
    setMessages(prev => [...prev, userMsg])
    setInput(''); setVoiceTranscript('')
    setTyping(true)
    setTimeout(() => {
      const answer = getBotResponse(trimmed, activeLoc)
      const botId = nextId.current++
      setTyping(false)
      setMessages(prev => [...prev, { id: botId, role: 'bot', text: answer, time: nowTime() }])
      if (autoSpeak || isVoice) setTimeout(() => speak(answer, botId, activeLoc), 120)
    }, 750 + Math.random() * 500)
  }, [locale, autoSpeak, speak, stopSpeaking])

  /* ── STT ────────────────────────────────────────────────────── */
  const startListening = useCallback(() => {
    if (!hasSR()) { setMicError('Speech recognition is not supported in this browser. Try Chrome or Edge.'); setTimeout(() => setMicError(''), 5000); return }
    setMicError('')
    const SR = window.SpeechRecognition ?? window.webkitSpeechRecognition!
    const rec = new SR()
    rec.continuous = true; rec.interimResults = true
    rec.lang = (LANGS[locale] ?? LANGS[DEFAULT_LOCALE]).locale
    let accumulated = ''

    rec.onresult = (e: SpeechRecognitionEvent) => {
      let final = ''; let interim = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const t = e.results[i][0].transcript
        if (e.results[i].isFinal) final += t; else interim += t
      }
      if (final) accumulated += final
      const display = accumulated + interim
      setVoiceTranscript(display); setInput(display)
      if (final) {
        if (autoSendTimer.current) clearTimeout(autoSendTimer.current)
        autoSendTimer.current = setTimeout(() => rec.stop(), 1800)
      }
    }

    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      setListening(false); setVoiceTranscript(''); setInput('')
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setMicError(s.micDenied); setTimeout(() => setMicError(''), 7000)
      } else if (e.error === 'audio-capture') {
        setMicError(s.noMic); setTimeout(() => setMicError(''), 5000)
      } else if (e.error === 'network') {
        setMicError(s.networkErr); setTimeout(() => setMicError(''), 5000)
      } else if (e.error !== 'no-speech' && e.error !== 'aborted') {
        setMicError(`Voice error: ${e.error}`); setTimeout(() => setMicError(''), 5000)
      }
    }

    rec.onend = () => {
      setListening(false)
      setVoiceTranscript(prev => {
        const toSend = prev || accumulated
        if (toSend.trim()) sendMessage(toSend, true, locale)
        return ''
      })
    }

    recognizerRef.current = rec; rec.start(); setListening(true)
  }, [locale, s, sendMessage])

  const stopListening = useCallback(() => {
    if (autoSendTimer.current) clearTimeout(autoSendTimer.current)
    recognizerRef.current?.stop(); setListening(false)
  }, [])

  useEffect(() => () => { recognizerRef.current?.abort(); hasSS() && window.speechSynthesis.cancel() }, [])

  /* ── Language switch ────────────────────────────────────────── */
  const switchLang = (loc: string) => {
    stopListening(); stopSpeaking()
    setLocale(loc)
    setInput(''); setVoiceTranscript('')
    setMessages([makeGreeting(loc)])
    nextId.current = 1
  }

  const reset = () => {
    stopListening(); stopSpeaking()
    setMessages([makeGreeting(locale)]); nextId.current = 1
    setInput(''); setVoiceTranscript('')
  }

  const handleKey = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(voiceTranscript || input) } }

  return (
    <>
      <style>{`
        @keyframes chatDot   { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }
        @keyframes chatPop   { 0%{opacity:0;transform:scale(0.88) translateY(12px)} 100%{opacity:1;transform:scale(1) translateY(0)} }
        @keyframes chatShake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-4px)} 75%{transform:translateX(4px)} }
        @keyframes chatPulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.10)} }
        @keyframes badgePop  { 0%{opacity:0;transform:scale(0)} 70%{transform:scale(1.15)} 100%{opacity:1;transform:scale(1)} }
        @keyframes voiceBar  { from{transform:scaleY(0.35)} to{transform:scaleY(1)} }
        @keyframes micPing   { 0%{transform:scale(1);opacity:1} 100%{transform:scale(2.4);opacity:0} }
        @keyframes micGlow   { 0%,100%{box-shadow:0 0 0 0 rgba(239,68,68,0.60)} 50%{box-shadow:0 0 0 10px rgba(239,68,68,0)} }
        @keyframes slideUp   { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
      `}</style>

      {/* ── FAB ──────────────────────────────────────────────── */}
      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 200 }}>
        {showBadge && !open && (
          <div style={{ position: 'absolute', top: -8, right: -6, zIndex: 1, animation: 'badgePop 0.4s ease forwards' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 18, height: 18, borderRadius: '50%', background: '#E53935', color: '#fff', fontSize: 10, fontWeight: 700, fontFamily: "'Exo 2',sans-serif", boxShadow: '0 2px 6px rgba(229,57,53,0.50)' }}>1</span>
          </div>
        )}
        {listening && <div style={{ position: 'absolute', inset: -4, borderRadius: '50%', border: '2px solid rgba(239,68,68,0.7)', animation: 'micPing 1.2s ease-out infinite' }} />}
        <button onClick={() => setOpen(v => !v)} title="SES AI Assistant"
          style={{ width: 56, height: 56, borderRadius: '50%', background: listening ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : open ? 'linear-gradient(135deg,#475569,#1E3A5F)' : 'linear-gradient(135deg,#1565C0,#7c3aed)', color: '#fff', border: '3px solid rgba(255,255,255,0.90)', boxShadow: listening ? '0 8px 32px rgba(239,68,68,0.50)' : '0 8px 32px rgba(21,101,192,0.40)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.22s ease', animation: !open && !listening ? 'chatPulse 3s 2s infinite' : 'none' }}>
          {open ? <ChevronDown size={22} /> : <Bot size={24} />}
        </button>
      </div>

      {/* ── Panel ────────────────────────────────────────────── */}
      {open && (
        <div style={{ position: 'fixed', bottom: 92, right: 24, zIndex: 199, width: 400, maxHeight: '80vh', display: 'flex', flexDirection: 'column', background: 'rgba(255,255,255,0.97)', backdropFilter: 'blur(32px) saturate(160%)', WebkitBackdropFilter: 'blur(32px) saturate(160%)', borderRadius: 20, border: '1px solid rgba(255,255,255,0.80)', boxShadow: '0 24px 64px rgba(21,101,192,0.22), 0 4px 16px rgba(0,0,0,0.12)', animation: 'chatPop 0.24s cubic-bezier(0.34,1.56,0.64,1) forwards' }}>

          {/* Header */}
          <div style={{ background: listening ? 'linear-gradient(135deg,#b91c1c,#ef4444)' : 'linear-gradient(135deg,#1565C0,#7c3aed)', borderRadius: '20px 20px 0 0', padding: '13px 14px', display: 'flex', alignItems: 'center', gap: 9, flexShrink: 0, transition: 'background 0.4s' }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(255,255,255,0.20)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, border: '1.5px solid rgba(255,255,255,0.35)' }}>
              {listening ? <Mic size={17} color="#fff" /> : <Sparkles size={17} color="#fff" />}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'Rajdhani,sans-serif', fontWeight: 700, fontSize: 15, color: '#fff', lineHeight: 1.2 }}>
                {listening ? s.listenHint : 'SES AI Assistant'}
              </div>
              <div style={{ fontFamily: "'Exo 2',sans-serif", fontSize: 11, color: 'rgba(255,255,255,0.78)', display: 'flex', alignItems: 'center', gap: 4, marginTop: 1 }}>
                <span style={{ width: 6, height: 6, borderRadius: '50%', background: listening ? '#fca5a5' : '#4ade80', display: 'inline-block', animation: listening ? 'micGlow 1s infinite' : 'none' }} />
                {listening ? s.listenHint : 'Text & Voice · Multilingual'}
              </div>
            </div>
            <LangPicker locale={locale} onChange={switchLang} />
            {hasSS() && (
              <button onClick={() => { setAutoSpeak(v => !v); if (speakingId !== null) stopSpeaking() }} title={autoSpeak ? 'Mute' : 'Enable voice responses'}
                style={{ background: autoSpeak ? 'rgba(255,255,255,0.28)' : 'rgba(255,255,255,0.13)', border: '1px solid rgba(255,255,255,0.30)', borderRadius: 8, color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, flexShrink: 0 }}>
                {autoSpeak ? <Volume2 size={13} /> : <VolumeX size={13} />}
              </button>
            )}
            <button onClick={reset} title="Clear" style={{ background: 'rgba(255,255,255,0.13)', border: '1px solid rgba(255,255,255,0.25)', borderRadius: 8, color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, flexShrink: 0 }}><RotateCcw size={13} /></button>
            <button onClick={() => { setOpen(false); stopListening() }} style={{ background: 'rgba(255,255,255,0.13)', border: '1px solid rgba(255,255,255,0.25)', borderRadius: 8, color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, flexShrink: 0 }}><X size={14} /></button>
          </div>

          {/* Voice overlay */}
          {listening && (
            <div style={{ padding: '18px 18px 14px', background: 'linear-gradient(180deg,rgba(239,68,68,0.06),transparent)', borderBottom: '1px solid rgba(239,68,68,0.12)', animation: 'slideUp 0.2s ease', flexShrink: 0 }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
                <VoiceWaveform active={listening} />
                <div style={{ width: '100%', minHeight: 40, padding: '10px 14px', borderRadius: 12, background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', fontSize: 13, color: '#1E3A5F', fontFamily: "'Exo 2',sans-serif", textAlign: 'center', fontStyle: voiceTranscript ? 'normal' : 'italic' }}>
                  {voiceTranscript || '…'}
                </div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button onClick={stopListening} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 16px', borderRadius: 20, background: '#ef4444', border: 'none', color: '#fff', fontSize: 12, fontWeight: 700, fontFamily: "'Exo 2',sans-serif", cursor: 'pointer', boxShadow: '0 4px 12px rgba(239,68,68,0.35)' }}>
                    <MicOff size={13} /> {s.stopSend}
                  </button>
                  <button onClick={() => { recognizerRef.current?.abort(); setListening(false); setVoiceTranscript(''); setInput('') }} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 12px', borderRadius: 20, background: 'rgba(100,116,139,0.10)', border: '1px solid rgba(100,116,139,0.22)', color: '#475569', fontSize: 12, fontWeight: 600, fontFamily: "'Exo 2',sans-serif", cursor: 'pointer' }}>
                    {s.cancel}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Mic error */}
          {micError && (
            <div style={{ margin: '8px 14px 0', padding: '9px 13px', borderRadius: 10, background: 'rgba(239,68,68,0.09)', border: '1px solid rgba(239,68,68,0.22)', fontSize: 12, color: '#b91c1c', fontFamily: "'Exo 2',sans-serif", animation: 'slideUp 0.2s ease', flexShrink: 0 }}>
              {micError}
            </div>
          )}

          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', padding: '16px 14px 10px', display: 'flex', flexDirection: 'column', gap: 12 }}>
            {messages.map(m => (
              <div key={m.id} style={{ display: 'flex', flexDirection: m.role === 'user' ? 'row-reverse' : 'row', alignItems: 'flex-end', gap: 8 }}>
                {m.role === 'bot' && (
                  <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'linear-gradient(135deg,#1565C0,#7c3aed)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginBottom: 2 }}>
                    <Sparkles size={13} color="#fff" />
                  </div>
                )}
                <div style={{ maxWidth: '80%' }}>
                  <div style={{ padding: m.role === 'user' ? '9px 14px' : '11px 14px', borderRadius: m.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px', background: m.role === 'user' ? (m.isVoice ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : 'linear-gradient(135deg,#1565C0,#1976D2)') : 'rgba(21,101,192,0.07)', color: m.role === 'user' ? '#fff' : '#0D2B5E', fontSize: 13, fontFamily: "'Exo 2',sans-serif", lineHeight: 1.55, border: m.role === 'bot' ? '1px solid rgba(21,101,192,0.12)' : 'none' }}>
                    {m.role === 'bot' ? <BotMsg text={m.text} /> : m.text}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4, justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
                    {m.isVoice && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3, fontSize: 10, color: '#94A3B8', fontFamily: "'Exo 2',sans-serif" }}><Mic size={9} /> voice</span>}
                    <span style={{ fontSize: 10, color: '#94A3B8', fontFamily: "'Exo 2',sans-serif" }}>{m.time}</span>
                    {m.role === 'bot' && hasSS() && (
                      <button onClick={() => speakingId === m.id ? stopSpeaking() : speak(m.text, m.id, locale)}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '1px 3px', borderRadius: 4, display: 'flex', alignItems: 'center', color: speakingId === m.id ? '#1565C0' : '#CBD5E1' }}>
                        <Volume2 size={12} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {typing && (
              <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8 }}>
                <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'linear-gradient(135deg,#1565C0,#7c3aed)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Sparkles size={13} color="#fff" /></div>
                <TypingDots />
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick prompts */}
          {messages.length <= 1 && !typing && !listening && (
            <div style={{ padding: '0 14px 10px', flexShrink: 0 }}>
              <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', color: '#94A3B8', fontFamily: "'Exo 2',sans-serif", marginBottom: 6 }}>
                {locale === 'en-IN' ? 'Quick questions' : locale === 'hi-IN' ? 'त्वरित प्रश्न' : locale === 'mr-IN' ? 'त्वरित प्रश्न' : 'Quick questions'}
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {s.quickPrompts.map(q => (
                  <button key={q} onClick={() => sendMessage(q)}
                    style={{ fontSize: 11, fontFamily: "'Exo 2',sans-serif", padding: '5px 11px', borderRadius: 20, background: 'rgba(21,101,192,0.07)', border: '1px solid rgba(21,101,192,0.20)', color: '#1565C0', cursor: 'pointer', fontWeight: 600 }}
                    onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(21,101,192,0.14)' }}
                    onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(21,101,192,0.07)' }}>
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div style={{ height: 1, background: 'rgba(21,101,192,0.10)', flexShrink: 0 }} />

          {/* Input */}
          <div style={{ padding: '12px 14px', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, background: listening ? 'rgba(239,68,68,0.05)' : 'rgba(21,101,192,0.06)', border: `1.5px solid ${listening ? 'rgba(239,68,68,0.35)' : 'rgba(21,101,192,0.20)'}`, borderRadius: 14, padding: '8px 8px 8px 14px', animation: shake ? 'chatShake 0.4s ease' : 'none', transition: 'border-color 0.3s,background 0.3s' }}>
              <input ref={inputRef} value={voiceTranscript || input} onChange={e => { setInput(e.target.value); setVoiceTranscript('') }} onKeyDown={handleKey}
                placeholder={listening ? s.listenHint : s.placeholder}
                readOnly={listening}
                style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontSize: 13, color: listening ? '#b91c1c' : '#0D2B5E', fontFamily: "'Exo 2',sans-serif", cursor: listening ? 'default' : 'text' }}
              />
              {hasSR() && (
                <button onClick={() => listening ? stopListening() : startListening()}
                  style={{ width: 32, height: 32, borderRadius: 10, border: 'none', background: listening ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : 'rgba(21,101,192,0.10)', color: listening ? '#fff' : '#1565C0', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0, animation: listening ? 'micGlow 1s infinite' : 'none', transition: 'all 0.2s', boxShadow: listening ? '0 3px 10px rgba(239,68,68,0.40)' : 'none' }}>
                  {listening ? <MicOff size={14} /> : <Mic size={14} />}
                </button>
              )}
              <button onClick={() => sendMessage(voiceTranscript || input)} disabled={listening}
                style={{ width: 32, height: 32, borderRadius: 10, border: 'none', background: (voiceTranscript || input).trim() && !listening ? 'linear-gradient(135deg,#1565C0,#7c3aed)' : 'rgba(21,101,192,0.08)', color: (voiceTranscript || input).trim() && !listening ? '#fff' : '#94A3B8', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: (voiceTranscript || input).trim() && !listening ? 'pointer' : 'default', transition: 'all 0.15s', flexShrink: 0, boxShadow: (voiceTranscript || input).trim() && !listening ? '0 3px 10px rgba(21,101,192,0.30)' : 'none' }}>
                <Send size={14} />
              </button>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginTop: 7 }}>
              {hasSR() && <span style={{ fontSize: 10, color: '#94A3B8', fontFamily: "'Exo 2',sans-serif", display: 'flex', alignItems: 'center', gap: 3 }}><Mic size={9} /> {s.voiceEnabled}</span>}
              {hasSS() && (
                <button onClick={() => setAutoSpeak(v => !v)} style={{ fontSize: 10, color: autoSpeak ? '#1565C0' : '#CBD5E1', fontFamily: "'Exo 2',sans-serif", background: 'none', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 3, padding: 0 }}>
                  <Volume2 size={9} /> {autoSpeak ? s.autoSpeakOn : s.autoSpeakOff}
                </button>
              )}
              <span style={{ fontSize: 10, color: '#CBD5E1', fontFamily: "'Exo 2',sans-serif" }}>SES Knowledge Base</span>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

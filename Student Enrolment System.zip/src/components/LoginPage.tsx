import { useState } from 'react'
import { User, Building2, Briefcase, ClipboardList, CheckCircle, Lock, Eye, EyeOff, AlertCircle, Loader2 } from 'lucide-react'
import logoYsf from '@/imports/logo-ysf-1.png'
import { TRAINEES } from '@/data/trainees'

interface LoginPageProps {
  onLogin: (role: 'branch' | 'management') => void
}

const CREDENTIALS = {
  branch: [
    { username: 'branch_hyd01', password: 'Hyd@2024', label: 'Hyderabad Branch', code: 'BR-HYD-01' },
    { username: 'branch_mum02', password: 'Mum@2024', label: 'Mumbai Branch', code: 'BR-MUM-02' },
    { username: 'branch_del03', password: 'Del@2024', label: 'Delhi Branch', code: 'BR-DEL-03' },
  ],
  management: [
    { username: 'mgmt_admin', password: 'Mgmt@2024', label: 'Senior Manager', role: 'Senior Manager' },
    { username: 'gm_south', password: 'GM@South24', label: 'GM – South Region', role: 'General Manager' },
    { username: 'ceo_ops', password: 'CEO@Ops24', label: 'Chief Operations Officer', role: 'COO' },
  ],
}

const _total      = TRAINEES.length
const _industries = new Set(TRAINEES.map(t => t.company)).size
const _schemes    = new Set(TRAINEES.map(t => t.scheme)).size
const _placements = TRAINEES.filter(t => t.status === 'Approved').length

const STATS = [
  { Icon: User,          label: 'Registered Trainees', value: _total.toLocaleString('en-IN'),      varColor: 'var(--ysf-blue)'   },
  { Icon: Building2,     label: 'Industries',           value: _industries.toLocaleString('en-IN'), varColor: 'var(--ysf-orange)' },
  { Icon: ClipboardList, label: 'Schemes',              value: _schemes.toLocaleString('en-IN'),    varColor: 'var(--success)'    },
  { Icon: CheckCircle,   label: 'Placements',           value: _placements.toLocaleString('en-IN'), varColor: 'var(--ysf-red)'    },
]

/* Tab config — only warm/neutral colors, no raw hex for identity colors */
const TAB_CONFIG = {
  branch: {
    label      : 'Branch',
    sub        : 'Training center portal',
    Icon       : Building2,
    /* active gradient — orange → yellow (YSF S + Y letters) */
    activeGrad : 'linear-gradient(135deg, var(--ysf-orange) 0%, var(--ysf-yellow) 100%)',
    activeText : '#ffffff',
    activeShadow: '0 6px 20px rgba(249,115,22,0.32), 0 2px 6px rgba(0,0,0,0.08)',
    chipBg     : 'var(--ysf-orange)',
    chipText   : '#fff',
    badgeColor : 'var(--ysf-orange)',
    badgeBg    : 'rgba(249,115,22,0.08)',
    badgeBorder: 'rgba(249,115,22,0.20)',
    focusRing  : 'rgba(249,115,22,0.18)',
    focusBorder: 'var(--ysf-orange)',
  },
  management: {
    label      : 'Management',
    sub        : 'Executive portal',
    Icon       : Briefcase,
    /* active — YSF blue gradient */
    activeGrad : 'linear-gradient(135deg, var(--ysf-blue) 0%, #1976D2 100%)',
    activeText : '#ffffff',
    activeShadow: '0 6px 20px rgba(21,101,192,0.34), 0 2px 6px rgba(0,0,0,0.08)',
    chipBg     : 'var(--ysf-blue)',
    chipText   : '#ffffff',
    badgeColor : 'var(--ysf-blue)',
    badgeBg    : 'var(--ysf-blue-light)',
    badgeBorder: 'rgba(21,101,192,0.22)',
    focusRing  : 'rgba(21,101,192,0.18)',
    focusBorder: 'var(--ysf-blue)',
  },
}

export default function LoginPage({ onLogin }: LoginPageProps) {
  const [tab,       setTab      ] = useState<'branch' | 'management'>('branch')
  const [username,  setUsername ] = useState('')
  const [password,  setPassword ] = useState('')
  const [showPass,  setShowPass ] = useState(false)
  const [error,     setError    ] = useState('')
  const [loading,   setLoading  ] = useState(false)
  const [showCreds, setShowCreds] = useState(false)

  const handleLogin = () => {
    setError('')
    const match = CREDENTIALS[tab].find(c => c.username === username && c.password === password)
    if (!match) { setError('Invalid credentials. Please check your username and password.'); return }
    setLoading(true)
    setTimeout(() => { setLoading(false); onLogin(tab) }, 1200)
  }

  const cfg = TAB_CONFIG[tab]

  return (
    /* page bg uses --background from design system */
    <div style={{ height: '100vh', minHeight: 600, display: 'flex', flexDirection: 'column', overflow: 'auto', background: 'transparent', fontFamily: "'Exo 2', sans-serif" }}>

      {/* ── Top header ──────────────────────────────────── */}
      <header style={{
        background: 'rgba(255,255,255,0.82)',
        backdropFilter: 'blur(20px) saturate(140%)',
        WebkitBackdropFilter: 'blur(20px) saturate(140%)',
        borderBottom: '1px solid rgba(255,255,255,0.72)',
        boxShadow: '0 1px 0 rgba(255,255,255,0.90), 0 4px 20px rgba(21,101,192,0.08)',
        position: 'relative', zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <img src={logoYsf} alt="Yuvashakti Foundation" style={{ height: 46, objectFit: 'contain' }} />
            <div style={{ width: 1, height: 32, background: 'var(--border)' }} className="hidden sm:block" />
            <div className="hidden sm:block">
              <div style={{ fontFamily: "'Rajdhani', sans-serif", fontWeight: 700, fontSize: 13, color: 'var(--foreground)' }}>
                Student Enrollment System
              </div>
              <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 2 }}>National Skill Development Portal</div>
            </div>
          </div>
          <div className="hidden md:flex" style={{ alignItems: 'center', gap: 16, fontSize: 11, color: 'var(--muted-foreground)' }}>
            <span>Helpdesk: 1800-XXX-XXXX</span>
            <span style={{ opacity: 0.3 }}>|</span>
            <span>support@ses.ysf.in</span>
          </div>
        </div>
        {/* YSF tri-color accent line */}
        <div className="ysf-gradient-bar" style={{ height: 3, opacity: 0.8 }} />
      </header>

      {/* ── Two-column layout ────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 16px' }}>
        <div style={{ width: '100%', maxWidth: 980, display: 'flex', gap: 40, alignItems: 'center' }}>

          {/* ══ LEFT — info panel ══════════════════════════ */}
          <div className="hidden md:flex" style={{ flex: 1, flexDirection: 'column', gap: 20 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--ysf-blue)' }}>
                Government Skilling Initiative
              </span>
              <span style={{ width: 24, height: 3, borderRadius: 99, background: 'var(--ysf-orange)', display: 'inline-block' }} />
            </div>
            <h1 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 36, fontWeight: 800, color: 'var(--foreground)', lineHeight: 1.2, letterSpacing: '-0.02em', margin: 0 }}>
              Empowering Youth<br />
              <span style={{ color: 'var(--ysf-blue)' }}>Through </span>
              <span style={{ color: 'var(--ysf-orange)' }}>Skills</span>
            </h1>
            <p style={{ fontSize: 14, color: 'var(--muted-foreground)', lineHeight: 1.7, margin: 0 }}>
              A unified digital platform for trainee registration, batch management, document verification, and placement tracking across all YSF training centers.
            </p>

            {/* Stats 2×2 */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              {STATS.map(s => (
                <div
                  key={s.label}
                  className="glass-card glass-card-hover"
                  style={{ padding: '18px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}
                >
                  <div style={{
                    width: 38, height: 38, borderRadius: 10,
                    background: s.varColor === 'var(--ysf-blue)' ? 'var(--ysf-blue-light)' : s.varColor === 'var(--ysf-orange)' ? 'rgba(249,115,22,0.10)' : 'var(--muted)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: s.varColor,
                  }}><s.Icon size={18} /></div>
                  <div>
                    <div style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 800, color: s.varColor, lineHeight: 1 }}>
                      {s.value}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 4 }}>{s.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ══ RIGHT — login card ═════════════════════════ */}
          <div style={{
            width: '100%', maxWidth: 420, flexShrink: 0,
            background: 'rgba(255,255,255,0.78)',
            backdropFilter: 'blur(28px) saturate(160%)',
            WebkitBackdropFilter: 'blur(28px) saturate(160%)',
            borderRadius: 24,
            border: '1px solid rgba(255,255,255,0.85)',
            boxShadow: 'var(--glass-shadow-colored-blue)',
            overflow: 'hidden',
          }}>

            {/* Top warm accent stripe */}
            <div className="ysf-gradient-bar" style={{ height: 4 }} />

            {/* ── Tab switcher — Branch vs Management ────── */}
            <div style={{ padding: '16px 18px 0' }}>
              <div style={{
                display: 'flex', gap: 8, padding: 6,
                background: 'var(--muted)',
                borderRadius: 16,
                border: '1px solid var(--border)',
              }}>
                {(['branch', 'management'] as const).map(t => {
                  const c = TAB_CONFIG[t]
                  const active = tab === t
                  return (
                    /* using raw <button>: kit "hardcoded-astra-ui" has no npm metadata and cannot be installed */
                    <button
                      key={t}
                      onClick={() => { setTab(t); setError(''); setUsername(''); setPassword('') }}
                      style={{
                        flex: 1,
                        display: 'flex', alignItems: 'center', gap: 10,
                        padding: '11px 12px', borderRadius: 12, cursor: 'pointer',
                        fontFamily: "'Rajdhani', sans-serif",
                        transition: 'all 0.22s cubic-bezier(0.34,1.56,0.64,1)',
                        /* ACTIVE: branded gradient */
                        /* INACTIVE: solid white with clear border — sharp, not blurred */
                        background: active ? c.activeGrad : '#ffffff',
                        color      : active ? c.activeText : 'var(--foreground)',
                        border     : active ? 'none' : '1.5px solid #CBD5E1',
                        boxShadow  : active ? c.activeShadow : '0 1px 4px rgba(0,0,0,0.07)',
                        transform  : active ? 'translateY(-1px)' : 'none',
                      }}
                    >
                      <span style={{
                        width: 32, height: 32, borderRadius: 9, flexShrink: 0,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        background: active ? 'rgba(255,255,255,0.22)' : 'var(--muted)',
                        color: active ? c.activeText : 'var(--foreground)',
                      }}>
                        <c.Icon size={15} />
                      </span>
                      <div style={{ textAlign: 'left' }}>
                        <div style={{ fontSize: 12, fontWeight: 700, lineHeight: 1.2 }}>{c.label}</div>
                        <div style={{
                          fontSize: 10, fontWeight: 400, marginTop: 2,
                          opacity: active ? 1 : 0.65,
                        }}>
                          {c.sub}
                        </div>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>

            {/* ── Form body ─────────────────────────────── */}
            <div style={{ padding: '18px 20px 20px' }}>

              {/* Role badge + welcome */}
              <div style={{ marginBottom: 18 }}>
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 7,
                  padding: '4px 12px', borderRadius: 99, marginBottom: 10,
                  background: cfg.badgeBg,
                  border: `1.5px solid ${cfg.badgeBorder}`,
                  transition: 'all 0.3s',
                }}>
                  <span style={{ width: 7, height: 7, borderRadius: '50%', background: cfg.badgeColor, flexShrink: 0 }} />
                  <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: cfg.badgeColor }}>
                    {tab === 'branch' ? 'Branch User' : 'Senior Management User'}
                  </span>
                </div>
                <h2 style={{ fontFamily: "'Rajdhani', sans-serif", fontSize: 20, fontWeight: 800, color: 'var(--foreground)', margin: '0 0 6px' }}>
                  Welcome back
                </h2>
                <p style={{ fontSize: 13, color: 'var(--muted-foreground)', margin: 0, lineHeight: 1.55 }}>
                  {tab === 'branch'
                    ? 'Manage trainee enrollments at your center.'
                    : 'View analytics & profiles across all centers.'}
                </p>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

                {/* Username field */}
                <div>
                  <label style={{ display: 'block', fontSize: 10, fontWeight: 700, color: 'var(--muted-foreground)', marginBottom: 6, letterSpacing: '0.10em', textTransform: 'uppercase' }}>
                    Username
                  </label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, opacity: 0.4, pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--foreground)' }}><User size={14} /></span>
                    {/* using raw <input>: kit cannot be installed */}
                    <input
                      style={{
                        width: '100%', padding: '11px 14px 11px 40px',
                        borderRadius: 12, fontSize: 13, outline: 'none', boxSizing: 'border-box',
                        border: '1.5px solid var(--border)',
                        background: 'var(--muted)',
                        fontFamily: "'JetBrains Mono', monospace",
                        color: 'var(--foreground)',
                        transition: 'border-color 0.18s, box-shadow 0.18s, background 0.18s',
                      }}
                      placeholder={tab === 'branch' ? 'e.g. branch_hyd01' : 'e.g. mgmt_admin'}
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                      onFocus={e => {
                        e.target.style.borderColor = cfg.focusBorder
                        e.target.style.boxShadow = `0 0 0 3px ${cfg.focusRing}`
                        e.target.style.background = '#fff'
                      }}
                      onBlur={e => {
                        e.target.style.borderColor = 'rgba(15,23,42,0.08)'
                        e.target.style.boxShadow = 'none'
                        e.target.style.background = 'var(--muted)'
                      }}
                    />
                  </div>
                </div>

                {/* Password field */}
                <div>
                  <label style={{ display: 'block', fontSize: 10, fontWeight: 700, color: 'var(--muted-foreground)', marginBottom: 6, letterSpacing: '0.10em', textTransform: 'uppercase' }}>
                    Password
                  </label>
                  <div style={{ position: 'relative' }}>
                    <span style={{ position: 'absolute', left: 13, top: '50%', transform: 'translateY(-50%)', width: 14, height: 14, opacity: 0.4, pointerEvents: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--foreground)' }}><Lock size={14} /></span>
                    {/* using raw <input>: kit cannot be installed */}
                    <input
                      type={showPass ? 'text' : 'password'}
                      style={{
                        width: '100%', padding: '11px 44px 11px 40px',
                        borderRadius: 12, fontSize: 13, outline: 'none', boxSizing: 'border-box',
                        border: '1.5px solid var(--border)',
                        background: 'var(--muted)',
                        fontFamily: "'JetBrains Mono', monospace",
                        color: 'var(--foreground)',
                        transition: 'border-color 0.18s, box-shadow 0.18s, background 0.18s',
                      }}
                      placeholder="Enter your password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      onFocus={e => {
                        e.target.style.borderColor = cfg.focusBorder
                        e.target.style.boxShadow = `0 0 0 3px ${cfg.focusRing}`
                        e.target.style.background = '#fff'
                      }}
                      onBlur={e => {
                        e.target.style.borderColor = 'rgba(15,23,42,0.08)'
                        e.target.style.boxShadow = 'none'
                        e.target.style.background = 'var(--muted)'
                      }}
                      onKeyDown={e => e.key === 'Enter' && handleLogin()}
                    />
                    {/* using raw <button>: icon-only visibility toggle, kit cannot be installed */}
                    <button
                      tabIndex={-1}
                      onClick={() => setShowPass(v => !v)}
                      style={{ position: 'absolute', right: 13, top: '50%', transform: 'translateY(-50%)', width: 20, height: 20, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted-foreground)' }}
                    >
                      {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                    </button>
                  </div>
                </div>

                {/* Error message */}
                {error && (
                  <div style={{
                    padding: '11px 14px', borderRadius: 12, fontSize: 13,
                    background: 'rgba(229,57,53,0.07)',
                    border: '1px solid rgba(229,57,53,0.22)',
                    color: 'var(--danger)',
                    display: 'flex', alignItems: 'center', gap: 8,
                  }}>
                    <AlertCircle size={15} style={{ flexShrink: 0 }} /> {error}
                  </div>
                )}

                {/* Sign In CTA — uses tab-specific gradient */}
                {/* using raw <button>: kit cannot be installed */}
                <button
                  onClick={handleLogin}
                  disabled={loading}
                  style={{
                    width: '100%', padding: '14px',
                    borderRadius: 14, border: 'none', cursor: loading ? 'not-allowed' : 'pointer',
                    fontFamily: "'Rajdhani', sans-serif",
                    fontWeight: 800, fontSize: 14, letterSpacing: '0.04em',
                    background: loading ? '#CBD5E1' : cfg.activeGrad,
                    color: loading ? '#94a3b8' : cfg.activeText,
                    boxShadow: loading ? 'none' : cfg.activeShadow,
                    transition: 'transform 0.15s, box-shadow 0.15s',
                  }}
                  onMouseEnter={e => !loading && (e.currentTarget.style.transform = 'translateY(-2px)')}
                  onMouseLeave={e => (e.currentTarget.style.transform = 'none')}
                >
                  {loading
                    ? <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}><Loader2 size={16} style={{ animation: 'spin 1s linear infinite' }} /> Authenticating...</span>
                    : 'Sign In  →'}
                </button>
              </div>

              {/* ── Demo credentials ─────────────────────── */}
              <div style={{ marginTop: 16 }}>
                {/* using raw <button>: kit cannot be installed */}
                <button
                  onClick={() => setShowCreds(v => !v)}
                  style={{
                    width: '100%', padding: '10px',
                    borderRadius: 12, border: '1.5px dashed #CBD5E1',
                    background: 'transparent', cursor: 'pointer',
                    fontFamily: "'Rajdhani', sans-serif",
                    fontSize: 12, fontWeight: 600, color: 'var(--muted-foreground)',
                    transition: 'background 0.15s',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'var(--muted)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  {showCreds ? '▲ Hide' : '▼ Show'} Demo Credentials (Prototype)
                </button>

                {showCreds && (
                  <div style={{
                    marginTop: 10, borderRadius: 16, overflow: 'hidden',
                    border: '1px solid var(--border)',
                    boxShadow: 'var(--glass-shadow)',
                  }}>
                    <div style={{
                      padding: '8px 16px',
                      background: 'var(--muted)',
                      borderBottom: '1px solid var(--border)',
                      fontSize: 10, fontWeight: 700, color: 'var(--muted-foreground)',
                      letterSpacing: '0.10em', textTransform: 'uppercase',
                    }}>
                      {tab === 'branch' ? 'Branch Users' : 'Management Users'}
                    </div>

                    {CREDENTIALS[tab].map((c, i) => (
                      /* using raw <button>: kit cannot be installed */
                      <button
                        key={c.username}
                        onClick={() => { setUsername(c.username); setPassword(c.password) }}
                        style={{
                          width: '100%', padding: '11px 16px',
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          background: 'transparent', border: 'none',
                          borderTop: i === 0 ? 'none' : '1px solid var(--border)',
                          cursor: 'pointer',
                          fontFamily: "'Exo 2', sans-serif",
                          transition: 'background 0.12s',
                        }}
                        onMouseEnter={e => (e.currentTarget.style.background = 'var(--muted)')}
                        onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                      >
                        <div style={{ textAlign: 'left' }}>
                          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--foreground)' }}>{c.label}</div>
                          <div style={{ fontSize: 11, color: 'var(--muted-foreground)', marginTop: 3, fontFamily: "'JetBrains Mono', monospace" }}>
                            {c.username} / {c.password}
                          </div>
                        </div>
                        {/* "Use →" pill — solid, clearly visible */}
                        <span style={{
                          padding: '6px 14px', borderRadius: 99, flexShrink: 0,
                          background: cfg.chipBg,
                          color: cfg.chipText,
                          fontSize: 11, fontWeight: 700, letterSpacing: '0.02em',
                          fontFamily: "'Rajdhani', sans-serif",
                          boxShadow: '0 2px 8px rgba(0,0,0,0.12)',
                        }}>
                          Use →
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <p style={{ textAlign: 'center', fontSize: 11, color: 'var(--muted-foreground)', margin: '14px 0 0', fontFamily: "'Exo 2', sans-serif" }}>
                Forgot password? Contact your system administrator.
              </p>
            </div>

            {/* Bottom warm accent stripe */}
            <div className="ysf-gradient-bar" style={{ height: 4 }} />
          </div>

        </div>
      </div>

      <footer style={{ padding: '12px 0', textAlign: 'center', fontSize: 11, color: 'var(--muted-foreground)', borderTop: '1px solid var(--border)', fontFamily: "'Exo 2', sans-serif" }}>
        © 2026 Yuvashakti Foundation · Student Enrollment System v3.2.1 · All rights reserved
      </footer>
    </div>
  )
}

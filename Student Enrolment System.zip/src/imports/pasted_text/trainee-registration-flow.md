Information Architecture
Login

↓

Dashboard

├── Trainee Registration
├── Trainee Search
├── Batch Management
├── Verification
├── Documents
├── Reports
├── Analytics
├── Administration
└── Profile
________________________________________
Registration Flow (Modern UX)
Dashboard

↓

Register New Trainee

↓

Personal Information

↓

Education

↓

Documents

↓

Review

↓

Submit

↓

Verification

↓

Batch Allocation

↓

Enrollment Complete
Instead of exposing multiple pages immediately, the system uses a 5-step wizard with auto-save and progress indicators, simplifying the three logical sections described in the Student Enrollment manual. 
________________________________________
Screen 1 — Dashboard
KPIs
•	Total Trainees 
•	Today's Registrations 
•	Pending Verification 
•	Batch Allocation Pending 
•	Completed Enrollment 
•	Rejected Applications 
Quick Actions
•	Register Trainee 
•	Search Trainee 
•	Verify Documents 
•	Assign Batch 
________________________________________
Screen 2 — Trainee Registration Wizard
Progress Bar
Personal
↓

Education
↓

Documents
↓

Review
↓

Submit
________________________________________
Step 1 — Personal Information
Sections
Basic
•	Full Name 
•	Aadhaar 
•	Mobile 
•	Email 
Family
•	Father 
•	Mother 
•	Guardian 
Address
•	State 
•	District 
•	City 
•	Pincode 
Bank
•	Account Number 
•	IFSC 
Course
•	Scheme 
•	NSQF 
•	Job Role 
Smart Validation
•	Aadhaar validation 
•	Duplicate mobile detection 
•	Email validation 
•	Age eligibility 
•	Mandatory field highlighting 
These validations align with the enrollment manual's requirements for Aadhaar, email, mandatory fields, and scheme eligibility. 
________________________________________
Step 2 — Education
Cards
10th
12th
ITI
Diploma
Graduation
Each card
Board
Marks
Year
Percentage
Upload Marksheet
________________________________________
Step 3 — Documents
Upload Cards
•	Aadhaar 
•	PAN 
•	Photo 
•	Signature 
•	10th Certificate 
•	12th Certificate 
•	Bank Passbook 
•	Agreement 
•	Offer Letter 
•	Other Documents 
Drag-and-drop upload
Preview
OCR-ready metadata
Document requirements are based on the Student Enrollment manual. 
________________________________________
Step 4 — Review
Complete Summary
Personal
Education
Documents
Buttons
Edit
Submit
________________________________________
Step 5 — Success
Registration Completed

Trainee Code

TRN000451

Proceed to Batch Allocation
________________________________________
Batch Allocation
Filters
Branch
Trainer
Course
Batch
Start Date
Capacity
Assign
↓
Success
________________________________________
Senior Management Dashboard
Designed specifically for leadership.
KPIs
Total Trainees
Pending
Completed
Rejected
Branch-wise
Course-wise
Gender Ratio
Daily Registration
Monthly Growth
Charts
Registration Trend
Completion Trend
Placement %
Branch Performance
________________________________________
Trainee 360° Profile
When management clicks on any trainee:
Photo

TRN000451

Rahul Sharma

--------------------------------

Personal Details

Education

Course

Batch

Trainer

Attendance

Documents

Agreement

Verification

Placement

Timeline

Audit Log
Documents Tab
•	Aadhaar 
•	PAN 
•	Agreement 
•	Offer Letter 
•	Bank 
•	Certificates 
Agreement
PDF Viewer
Download
Print
Version History
________________________________________
Verification Workflow
Submitted

↓

Document Verification

↓

Approved

↓

Batch Allocation

↓

Training Started

↓

Completed

↓

Placement
________________________________________
Search (Global)
Search by
•	Name 
•	Mobile 
•	Aadhaar 
•	Trainee Code 
•	Branch 
•	Batch 
•	Course 
AI Suggestions
Recent Searches
________________________________________
Notifications
Registration Submitted
Document Missing
Batch Assigned
Course Started
Certificate Ready
Placement Offer
________________________________________
Reports
•	Registration Report 
•	Branch Report 
•	Batch Report 
•	Document Status 
•	Gender Report 
•	Age Report 
•	Trainer Report 
•	Placement Report 
________________________________________
Mobile Experience
The registration wizard should also work on mobile:
•	One question per screen 
•	Large buttons 
•	Sticky Next/Back actions 
•	Camera upload for documents 
•	Auto-save after each step 
________________________________________
Deliverables for the 40+ Page Documentation
1.	Product Overview 
2.	UX Goals 
3.	User Roles 
4.	Information Architecture 
5.	Navigation Map 
6.	User Journey 
7.	Registration Flow 
8.	Validation Rules 
9.	Error Handling 
10.	Success States 
11.	Low-Fidelity Wireframes 
12.	Dashboard Wireframes 
13.	Trainee 360° Profile 
14.	Document Management 
15.	Verification Workflow 
16.	Batch Allocation 
17.	Reports 
18.	Analytics 
19.	Mobile UX 
20.	Design System 
21.	Accessibility Guidelines 
22.	Prototype Navigation 
23.	Screen Specifications 
24.	Future Enhancements

